import { useEffect, useRef } from 'react'
import aiNativeUrl from '../asset/AI-Native.svg'

/* ------------------------------------------------------------------
   AI-Native / Minsky Architecture — in-place SVG animation.
   CRITICAL: no redraw, no viewBox change, no 3x3 rebuild.
   Only stroke / opacity / transform on existing IDs.

   Timeline: 5.6s infinite compounding loop.
   Size locked to 280px tall (matches static fallback).
------------------------------------------------------------------- */

const ACTIVE = '#00D46B'
const IDLE = '#2D2D2D'
const ON = '1'
const OFF = '0.43'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const REDUCED = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
const FINE = typeof window !== 'undefined' && window.matchMedia('(pointer: fine)').matches

export default function AINativeLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0
    const removers = []
    const anims = []
    const tilt = { x: 0, y: 0, tx: 0, ty: 0 }

    fetch(aiNativeUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        // 280px to match the approved static size. viewBox untouched.
        svg.style.height = '280px'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.style.perspective = '900px'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => svg.querySelector('[id="' + id + '"]')
        const aura = byId('Tile')
        const wheel = byId('Ellipse 3376')
        const outer = byId('AI-Native')
        const centerRing = byId('Tile Background_4')

        const borders = {
          intel: byId('Tile Background_2'),
          work: byId('Tile Background_5'),
          dec: byId('Tile Background_6'),
          feed: byId('Tile Background_3'),
        }
        const labels = {
          intel: byId('Label'),
          work: byId('Label_3'),
          dec: byId('Label_4'),
          feed: byId('Label_2'),
        }
        // Stage-driven OPACITY groups (never transform-animated).
        const fade = {
          intel: ['Symbol', 'Symbol_2', 'Symbol_3', 'Symbol_4', 'Symbol_5', 'Symbol_6'].map(byId).filter(Boolean),
          work: ['Grid', 'Grid Point', 'Grid Point_2', 'Grid Point_3', 'Grid Point_4'].map(byId).filter(Boolean),
          dec: ['User-Circle-Single--Streamline-Flex'].map(byId).filter(Boolean),
          feed: ['Symbol_7', 'Symbol_8'].map(byId).filter(Boolean),
        }
        // Ambient TRANSFORM-only elements (opacity untouched → no fighting).
        const intelBreath = [byId('Symbol_2'), byId('Symbol_3')].filter(Boolean)
        const intelSlow = [byId('Symbol'), byId('Symbol_4')].filter(Boolean)
        const intelSlowRev = [byId('Symbol_5')].filter(Boolean)
        const gridDots = [byId('Grid Point'), byId('Grid Point_2'), byId('Grid Point_3'), byId('Grid Point_4')].filter(Boolean)
        const decBody = byId('User-Circle-Single--Streamline-Flex')
        const feedOuter = byId('Symbol_7')
        const feedCore = byId('Symbol_8')
        const decParts = [byId('Vector_2'), byId('Intersect')].filter(Boolean)

        const box = (el) => { if (el) { el.style.transformBox = 'fill-box'; el.style.transformOrigin = 'center' } }
        ;[...intelBreath, ...intelSlow, ...intelSlowRev, ...gridDots].forEach(box)
        box(decBody); box(feedOuter); box(feedCore)

        Object.values(borders).forEach((el) => {
          if (el) el.style.transition = 'stroke .45s ease, stroke-opacity .25s ease'
        })
        ;[...Object.values(labels), ...Object.values(fade).flat()].forEach((el) => {
          if (el) el.style.transition = 'opacity .45s ease'
        })
        if (aura) {
          // rAF drives transform every frame (continuous path) —
          // CSS must NOT transition transform or it re-introduces stepping.
          aura.style.transition = 'opacity .4s ease'
          aura.style.transformBox = 'fill-box'
          aura.style.transformOrigin = 'center'
          aura.style.opacity = '0.9'
        }
        if (outer) outer.style.transformStyle = 'preserve-3d'
        if (wheel) {
          wheel.style.transformBox = 'view-box'
          wheel.style.transformOrigin = '195.465px 195.463px'
          wheel.style.willChange = 'transform, filter'
          wheel.style.filter = 'drop-shadow(0 0 6px rgba(0,212,107,0.55))'
        }
        if (centerRing) {
          centerRing.style.transition = 'stroke .3s ease'
          centerRing.style.transformBox = 'view-box'
          centerRing.style.transformOrigin = '195.465px 195.463px'
        }

        if (REDUCED) {
          if (borders.intel) borders.intel.setAttribute('stroke', ACTIVE)
          if (labels.intel) labels.intel.style.opacity = ON
          return
        }

        /* ---- ambient (transform-only, hero-background ref) ---- */
        // Spec: Symbol_2/3 breathing rotation ±10° + brightness feel via scale.
        intelBreath.forEach((el, i) => {
          try { anims.push(el.animate(
            [{ transform: 'rotate(-10deg) scale(1)' }, { transform: 'rotate(10deg) scale(1.15)' }, { transform: 'rotate(-10deg) scale(1)' }],
            { duration: 1400, delay: i * 200, iterations: Infinity, easing: 'ease-in-out' }
          )) } catch (e) {}
        })
        intelSlow.forEach((el) => {
          try { anims.push(el.animate(
            [{ transform: 'rotate(0deg)' }, { transform: 'rotate(360deg)' }],
            { duration: 16000, iterations: Infinity, easing: 'linear' }
          )) } catch (e) {}
        })
        intelSlowRev.forEach((el) => {
          try { anims.push(el.animate(
            [{ transform: 'rotate(360deg)' }, { transform: 'rotate(0deg)' }],
            { duration: 20000, iterations: Infinity, easing: 'linear' }
          )) } catch (e) {}
        })
        // Workflow: neon chase across grid points (scale-only; opacity is staged).
        gridDots.forEach((el, i) => {
          try { anims.push(el.animate(
            [{ transform: 'scale(1)' }, { transform: 'scale(1.6)' }, { transform: 'scale(1)' }],
            { duration: 1400, delay: i * 350, iterations: Infinity, easing: 'ease-in-out' }
          )) } catch (e) {}
        })
        if (decBody) {
          try { anims.push(decBody.animate(
            [{ transform: 'scale(1)' }, { transform: 'scale(1.04)' }, { transform: 'scale(1)' }],
            { duration: 3200, iterations: Infinity, easing: 'ease-in-out' }
          )) } catch (e) {}
        }
        if (feedOuter) {
          try { anims.push(feedOuter.animate(
            [{ transform: 'rotate(0deg)' }, { transform: 'rotate(360deg)' }],
            { duration: 22000, iterations: Infinity, easing: 'linear' }
          )) } catch (e) {}
        }
        if (feedCore) {
          try { anims.push(feedCore.animate(
            [{ transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }],
            { duration: 2000, iterations: Infinity, easing: 'ease-in-out' }
          )) } catch (e) {}
        }

        /* ---- tilt on #AI-Native ---- */
        const host = ref.current
        const onMove = (e) => {
          const r = host.getBoundingClientRect()
          tilt.tx = -((e.clientY - r.top) / r.height - 0.5) * 8
          tilt.ty = ((e.clientX - r.left) / r.width - 0.5) * 8
        }
        const onLeave = () => { tilt.tx = 0; tilt.ty = 0 }
        if (FINE && host) {
          host.addEventListener('pointermove', onMove)
          host.addEventListener('pointerleave', onLeave)
          removers.push(() => {
            host.removeEventListener('pointermove', onMove)
            host.removeEventListener('pointerleave', onLeave)
          })
        }

        /* ---- single-clock director: one free-running 5.6s clock owns
           wheel angle, aura orbit AND stage. No sleep-chain vs rAF
           drift, so no hitch at the loop seam.
           Stage windows (spec): intel 0–1.4 · work 1.4–2.8 ·
           dec 2.8–4.2 · feed 4.2–5.2 · climax 5.2–5.6. */
        let angle = 0
        let pulse = 0
        let pop = 0
        let last = performance.now()
        const t0 = last + 400 // small lead-in so first paint is settled
        const BASE = 360 / 5600
        const LOOP = 5600
        const auraScale = { v: 1, t: 1 }
        const auraOp = { v: 0.9, t: 0.9 }
        let stage = ''
        let climaxSnapDone = false

        const WHEEL_GLOW = 'drop-shadow(0 0 6px rgba(0,212,107,0.55))'
        const WHEEL_HOT = 'drop-shadow(0 0 11px rgba(0,212,107,0.95)) brightness(1.22)'

        const applyStage = (key) => {
          const cfg = {
            intel: { b: borders.intel, l: labels.intel, f: fade.intel },
            work: { b: borders.work, l: labels.work, f: fade.work },
            dec: { b: borders.dec, l: labels.dec, f: fade.dec },
            feed: { b: borders.feed, l: labels.feed, f: fade.feed },
          }
          Object.entries(cfg).forEach(([k, v]) => {
            const on = k === key
            if (v.b) {
              v.b.setAttribute('stroke', on ? ACTIVE : IDLE)
              v.b.style.strokeOpacity = '1'
            }
            if (v.l) v.l.style.opacity = on ? ON : OFF
            v.f.forEach((el) => { el.style.opacity = on ? ON : OFF })
          })
          if (key === 'dec') decParts.forEach((el) => { if (el) el.style.opacity = '0.95' })
          if (key === 'feed' && feedCore) {
            try {
              feedCore.animate(
                [{ transform: 'scale(1.15)' }, { transform: 'scale(1)' }],
                { duration: 400, easing: 'cubic-bezier(.2,1.4,.4,1)' }
              ).finished.catch(() => {})
            } catch (e) {}
          }
          // glow is set discretely per stage — never rebuilt per frame
          if (wheel) wheel.style.filter = key === 'climax' ? WHEEL_HOT : WHEEL_GLOW
          pulse = Math.min(pulse + (key === 'climax' ? 1.5 : 0.8), 1.5)
          pop = Math.min(pop + (key === 'climax' ? 0.12 : 0.05), 0.2)
          auraScale.t = key === 'intel' ? 1 : key === 'climax' ? 0.85 : 1.04
          auraOp.t = key === 'intel' ? 0.9 : key === 'climax' ? 1 : 0.95
        }

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min(now - last, 50)
          last = now
          const t = now / 1000
          // free-running loop phase — never reset, so the seam is seamless
          const tau = (((now - t0) % LOOP) + LOOP) % LOOP / LOOP
          const ms = tau * LOOP
          const ph = tau * Math.PI * 2

          // stage from the SAME clock (no drift possible)
          const next = ms < 1400 ? 'intel' : ms < 2800 ? 'work' : ms < 4200 ? 'dec' : ms < 5200 ? 'feed' : 'climax'
          if (next !== stage) {
            if (next === 'climax') {
              Object.values(borders).forEach((b) => {
                if (!b) return
                b.setAttribute('stroke', ACTIVE)
                b.style.strokeOpacity = '0.8'
              })
              if (centerRing) centerRing.setAttribute('stroke', ACTIVE)
              climaxSnapDone = false
            } else {
              if (stage === 'climax') {
                Object.values(borders).forEach((b) => { if (b) b.style.strokeOpacity = '1' })
                if (centerRing) centerRing.setAttribute('stroke', IDLE)
              }
              // decision wobble on activation (hero ref, lands on identity)
              if (next === 'dec' && decBody) {
                try {
                  decBody.animate(
                    [{ transform: 'rotate(0deg)' }, { transform: 'rotate(-8deg)' }, { transform: 'rotate(8deg)' }, { transform: 'rotate(0deg)' }],
                    { duration: 720, easing: 'ease-in-out' }
                  ).finished.catch(() => {})
                } catch (e) {}
              }
            }
            stage = next
            applyStage(next)
          }
          // mid-climax snap: swell back out (replaces the old 200ms sleep)
          if (stage === 'climax' && !climaxSnapDone && ms > 5400) {
            climaxSnapDone = true
            auraScale.t = 1.0
            auraOp.t = 0.9
          }

          pulse *= Math.pow(0.22, dt / 1000)
          pop *= Math.pow(0.12, dt / 1000)
          const harmonic = 0.32 * Math.sin(ph * 2 + Math.PI / 4) + 0.18
          angle = (angle + BASE * (1 + pulse * 2.0 + harmonic) * dt) % 360
          if (wheel) {
            const breathe = 1 + Math.sin(t * 3.1) * 0.012 + pop
            wheel.style.transform = 'rotate(' + angle.toFixed(2) + 'deg) scale(' + breathe.toFixed(3) + ')'
          }
          if (centerRing) {
            centerRing.style.transform = 'scale(' + (1 + Math.sin(t * 3.1 + 0.6) * 0.008).toFixed(3) + ')'
          }
          const ax = 129 * Math.sin(ph)
          const ay = 64.5 * (1 - Math.cos(ph))
          const ks = 1 - Math.pow(0.002, dt / 1000)
          auraScale.v += (auraScale.t - auraScale.v) * ks
          auraOp.v += (auraOp.t - auraOp.v) * ks
          if (aura) {
            aura.style.transform =
              'translate(' + ax.toFixed(1) + 'px,' + ay.toFixed(1) + 'px) scale(' + auraScale.v.toFixed(3) + ')'
            aura.style.opacity = auraOp.v.toFixed(3)
          }
          tilt.x += (tilt.tx - tilt.x) * 0.12
          tilt.y += (tilt.ty - tilt.y) * 0.12
          if (outer) outer.style.transform =
            'rotateX(' + tilt.x.toFixed(2) + 'deg) rotateY(' + tilt.y.toFixed(2) + 'deg)'
          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {})

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      anims.forEach((a) => { try { a.cancel() } catch (e) {} })
      removers.forEach((fn) => fn())
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" style={{ height: 280 }} aria-hidden />
}
