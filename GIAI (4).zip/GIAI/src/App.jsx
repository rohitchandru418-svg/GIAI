import { useEffect, useRef, useState } from 'react'
import Lenis from 'lenis'
import HeroAccents from './HeroAccents.jsx'
import BadgeScramble from './BadgeScramble.jsx'
import BoltedOnLoop from './BoltedOnLoop.jsx'
import AINativeLoop from './AINativeLoop.jsx'
import HowWeBuildScroll from './HowWeBuildScroll.jsx'
import Typography from './Typography.jsx'
import brandLogo from '../asset/Brand Logo.png'
import HeroAccentsMobile from './HeroAccentsMobile.jsx'
import startupLogo from '../asset/StartupTN Logo.png'
import fameLogo from '../asset/FameTN Logo.png'
import boltIcon from '../asset/Icon.svg'
import iconNoLockin from '../asset/no loc-in.svg'
import iconCloud from '../asset/Runs in your cloud.svg'
import iconTrace from '../asset/Every action traceable.svg'
import iconConfidence from '../asset/Confidence thresholds.svg'
import iconRoles from '../asset/Role-based access.svg'
import iconEncrypted from '../asset/Encrypted end to end.svg'

const GREEN = '#00D46B'

/* Pixel-exact pill nav: 350x48, bg #222020, r8, active black r4 + shadow.
   Desktop only — mobile gets a hamburger (below). */
function PillNav() {
  return (
    <nav className="hidden lg:flex w-[clamp(280px,18.23vw,350px)] h-[clamp(38px,2.5vw,48px)] max-w-[70vw] bg-[#222020] rounded-[8px] overflow-hidden items-center justify-center border border-white/5">
      <div className="w-[clamp(264px,17.2vw,330px)] h-[clamp(28px,1.82vw,35px)] flex items-center justify-center gap-[clamp(14px,1.04vw,20px)]">
        <a href="#top" className="h-full px-[clamp(14px,1.1vw,21px)] flex items-center bg-black rounded-[4px] text-white text-[clamp(15px,1.04vw,20px)] leading-[1.2]"
          style={{ boxShadow: '13px 6px 13px rgba(103,103,103,0.25)' }}>Home</a>
        <span className="w-[clamp(14px,1vw,19px)] h-px rotate-90 bg-[#8E8E8E] shrink-0" />
        <a href="#portfolio" className="text-[rgba(255,255,255,0.4)] hover:text-white text-[clamp(15px,1.04vw,20px)] leading-[1.2]">Portfolio</a>
        <span className="w-[clamp(14px,1vw,19px)] h-px rotate-90 bg-[#8E8E8E] shrink-0" />
        <a href="#blog" className="text-[rgba(255,255,255,0.4)] hover:text-white text-[clamp(15px,1.04vw,20px)] leading-[1.2]">Blog</a>
      </div>
    </nav>
  )
}

/* Mobile hamburger: same three destinations in a dropdown panel. */
function MobileNav() {
  const [open, setOpen] = useState(false)
  const links = [['Home', '#top'], ['Portfolio', '#portfolio'], ['Blog', '#blog']]
  return (
    <div className="lg:hidden relative">
      <button type="button" onClick={() => setOpen((v) => !v)} aria-label="Menu" aria-expanded={open}
        className="w-11 h-11 flex flex-col items-center justify-center gap-[7px]">
        <span className={`block h-[4px] w-[36px] rounded-full bg-white transition-transform duration-300 ${open ? 'translate-y-[11px] rotate-45' : ''}`} />
        <span className={`block h-[4px] w-[36px] rounded-full bg-white transition-opacity duration-300 ${open ? 'opacity-0' : ''}`} />
        <span className={`block h-[4px] w-[36px] rounded-full bg-white transition-transform duration-300 ${open ? '-translate-y-[11px] -rotate-45' : ''}`} />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 w-[200px] bg-[#222020] border border-white/10 rounded-[8px] p-2 flex flex-col">
          {links.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setOpen(false)}
              className="px-4 py-3 rounded-[4px] text-white/70 hover:text-white hover:bg-white/5 text-[15px] leading-[1.2]">{label}</a>
          ))}
        </div>
      )}
    </div>
  )
}

function CTAButton({ children = 'Book a 30-min call', small }) {
  return (
    <a href="#contact" className={`btn-metal ${small ? 'small' : ''}`}>
      <span>{children}</span>
    </a>
  )
}

function SectionLabel({ children }) {
  return <div className="sec-label">{children}</div>
}

/* ---------------- HERO : pixel-perfect, full viewport ---------------- */
function Hero() {
  return (
    <header id="top" className="hero-section portrait:min-h-[100svh] bg-black">
      {/* AFI animated hero background: page.svg at natural size, pinned top-center */}
      {/* desktop: animated page.svg loop · mobile: same cinematic loop on the mobile artwork */}
      <div className="absolute inset-x-0 top-0 bottom-0 flex justify-center pointer-events-none">
        <div className="hidden lg:flex lg:justify-center lg:self-start w-full">
          <HeroAccents />
        </div>
        <div className="lg:hidden absolute inset-0 w-full">
          <HeroAccentsMobile />
        </div>
      </div>
      <div className="absolute inset-0 hero-fade max-lg:hidden pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-[22%] max-lg:hidden bg-gradient-to-b from-transparent to-black pointer-events-none" />

      {/* nav row: 1720 / 32px top — exact Figma */}
      <div className="relative w-full max-w-[1720px] mx-auto px-[clamp(16px,3vw,48px)] pt-[32px] flex items-center justify-between shrink-0">
        <img src={brandLogo} alt="Minsky" className="w-[clamp(64px,4.74vw,91px)] max-md:w-[52px] h-auto object-contain opacity-95" />
        <PillNav />
        <MobileNav />
      </div>

      {/* center stack: gap 50 — exact Figma */}
      <div className="relative w-full flex-1 flex items-center justify-center">
        <div className="w-[880px] max-w-[94vw] flex flex-col items-center gap-[50px] max-lg:gap-8 text-center pt-[90px] pb-[110px]">
          <div className="flex flex-col items-center gap-[20px]">
            <div className="hero-badge hero-rise flex items-center justify-center flex-wrap gap-[12px] max-w-[92vw]" style={{ '--d': '.05s' }}>
              <span className="live-dot" aria-label="live" />
              <span style={{ color: GREEN }}>Minsky</span>
              <span className="text-[16px] font-medium" style={{ color: GREEN }}>.</span>
              <span className="text-white flex items-center gap-[2px]"><BadgeScramble />
                <span className="cursor-blink inline-block w-[8px] h-[20px] bg-white ml-[6px]" />
              </span>
            </div>
            <h1 className="hero-h1" data-split data-split-load style={{ '--d': '.1s' }}>
              <span className="text-white">AI systems built </span><br className="lg:hidden" />
              <span className="text-[rgba(255,255,255,0.5)]">to move</span><br className="max-lg:hidden" />{' '}
              <span className="text-[rgba(255,255,255,0.5)]">your </span><br className="lg:hidden" />
              <span className="max-lg:whitespace-nowrap"><span style={{ color: GREEN }}>business forward</span><span className="text-white">.</span></span>
            </h1>
            <p className="hero-rise w-[clamp(480px,33.7vw,647px)] max-w-[90vw] text-[var(--grey-1)] text-[clamp(13px,1.04vw,20px)] leading-[1.2]" style={{ '--d': '.28s' }}>
              Minsky builds AI-native systems that connect data, knowledge, and workflows to understand, execute, and continuously improve.
            </p>
          </div>
          <div className="hero-rise flex flex-col items-center gap-[12px]" style={{ '--d': '.4s' }}>
            <CTAButton />
            <p className="text-[rgba(255,255,255,0.3)] text-[clamp(12px,0.83vw,16px)] font-medium leading-[1.2]">
              No pitch. An honest fit check,<br className="lg:hidden" /> and a fixed-price 2-week sprint if it fits.
            </p>
          </div>
        </div>
      </div>
    </header>
  )
}

/* ---------------- STATS ---------------- */
/* plus-tick markers pinned on every box corner, like the Figma frame */
function CornerTicks({ green } = {}) {
  // Unified 4px filled diamonds (Figma) for both tones.
  const c = green ? 'bg-[var(--minsky-green)] opacity-80' : 'bg-[#D9D9D9] opacity-30'
  const s = `absolute w-[4px] h-[4px] rotate-45 ${c} pointer-events-none`
  return (
    <span aria-hidden className="absolute inset-0 pointer-events-none">
      <span className={`${s} left-[-2px] top-[-2px]`} />
      <span className={`${s} right-[-2px] top-[-2px]`} />
      <span className={`${s} left-[-2px] bottom-[-2px]`} />
      <span className={`${s} right-[-2px] bottom-[-2px]`} />
    </span>
  )
}

/* plus-tick corner marks (How-we-engage / Trust / Fit frames in Figma):
   9px hairline cross, pinned half-outside the frame edge. */
function PlusMark({ className = '', style, green } = {}) {
  const tone = green ? 'bg-[var(--minsky-green)]' : 'bg-white/25'
  return (
    <span aria-hidden className={`absolute pointer-events-none ${className}`} style={style}>
      <span className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 block h-px w-[9px] ${tone}`} />
      <span className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 block h-[9px] w-px ${tone}`} />
    </span>
  )
}

function CornerPluses({ green } = {}) {
  return (
    <span aria-hidden className="absolute inset-0 pointer-events-none">
      <PlusMark className="left-0 top-0" green={green} />
      <PlusMark className="right-0 top-0" green={green} />
      <PlusMark className="left-0 bottom-0" green={green} />
      <PlusMark className="right-0 bottom-0" green={green} />
    </span>
  )
}

const BRAND_STATS = {
  StartupTN: [
    { v: 80, suffix: '%', label: 'LESS MANUAL SCREENING' },
    { v: 30, suffix: ' days', label: 'FASTER TURNAROUND' },
    { v: 10000, suffix: '+', label: 'APPLICATIONS PROCESSED', comma: true },
    { v: 4, suffix: '', label: 'AI AGENTS LIVE' },
  ],
  FaMeTN: [
    { v: 10000, suffix: '+', label: 'BUYER-SELLER MATCHES', comma: true },
    { v: 50000, suffix: '', label: 'MSMEs IN NETWORK', comma: true },
    { v: 2, suffix: '', label: 'MESSAGING CHANNELS' },
    { v: 0, suffix: '', label: 'SCHEDULING CONFLICTS' },
  ],
}
const ROTATE_MS = 5000
const REDUCED = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

/* rolling digit counter: eased count morph + motion-blur while rolling */
function RollingNumber({ value, suffix, comma }) {
  const [display, setDisplay] = useState(0)
  const [rolling, setRolling] = useState(false)
  const prev = useRef(0)
  const fmt = (n) => (comma ? n.toLocaleString('en-US') : String(n)) + (suffix || '')
  useEffect(() => {
    if (REDUCED || prev.current === value) {
      setDisplay(value)
      prev.current = value
      return
    }
    setRolling(true)
    let raf = 0
    const from = prev.current
    const start = performance.now()
    const dur = 750
    const step = (now) => {
      const p = Math.min((now - start) / dur, 1)
      const e = 1 - Math.pow(1 - p, 3)
      setDisplay(Math.round(from + (value - from) * e))
      if (p < 1) raf = requestAnimationFrame(step)
      else {
        prev.current = value
        setRolling(false)
      }
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [value])
  return <span className={rolling ? 'metric-rolling' : undefined}>{fmt(display)}</span>
}

/* circular 5s progress ring shown on the active brand card */
function ProgressRing({ progress }) {
  const C = 2 * Math.PI * 9
  return (
    <span className="absolute top-3 right-3 h-[22px] w-[22px]" aria-hidden>
      <svg viewBox="0 0 22 22" className="h-full w-full">
        <circle cx="11" cy="11" r="9" fill="none" stroke="#2D2D2D" strokeWidth="2" />
        <circle cx="11" cy="11" r="9" fill="none" stroke="#00D46B" strokeWidth="2" strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={C * (1 - progress)} transform="rotate(-90 11 11)" />
      </svg>
    </span>
  )
}

function Stats() {
  const [active, setActive] = useState('StartupTN')
  const [progress, setProgress] = useState(0)
  const startRef = useRef(0)

  /* auto-rotate every 5s; any manual pick restarts the timer */
  useEffect(() => {
    if (REDUCED) return
    let raf = 0
    startRef.current = performance.now()
    const tick = (now) => {
      const p = (now - startRef.current) / ROTATE_MS
      if (p >= 1) {
        setActive((a) => (a === 'StartupTN' ? 'FaMeTN' : 'StartupTN'))
        startRef.current = now
        setProgress(0)
      } else {
        setProgress((prev) => {
          const n = Math.round(p * 100)
          return n === prev ? prev : n
        })
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  const pick = (b) => {
    if (b !== active) setActive(b)
    startRef.current = performance.now()
    setProgress(0)
  }

  const brandBtn = (name, logo, alt, logoCls, onCls) => {
    const on = active === name
    return (
      <button key={name} onClick={() => pick(name)} aria-pressed={on} aria-label={`Show ${name} metrics`}
        className={`relative flex items-center justify-center px-4 md:px-10 border border-[var(--line-1)] border-b-0 last:border-l-0 w-full h-[clamp(96px,6.875vw,132px)] transition-colors duration-500 ${on ? 'bg-[#0d0d0d]' : 'bg-black hover:bg-[var(--ink-1)]'}`}>
        <CornerTicks />
        {on && !REDUCED && <ProgressRing progress={progress / 100} />}
        <img src={logo} alt={alt} className={`${logoCls} transition-all duration-500 ${on ? `opacity-100 ${onCls || ''}` : 'opacity-30 grayscale mix-blend-luminosity'}`} />
      </button>
    )
  }

  const stats = BRAND_STATS[active]
  return (
    <section className="section">
      <div className="wrap flex flex-col">
        <div className="grid grid-cols-2 lg:grid-cols-4">
          <div className="col-span-2 flex items-center py-8 rise">
            <SectionLabel>/ LIVE IN PRODUCTION FOR</SectionLabel>
          </div>
          {brandBtn('StartupTN', startupLogo, 'StartupTN', 'h-[clamp(32px,2.29vw,44px)] object-contain')}
          {brandBtn('FaMeTN', fameLogo, 'FaMeTN', 'h-[clamp(56px,4.17vw,80px)] object-contain', 'brightness-110 contrast-125 drop-shadow-[0_0_16px_rgba(255,255,255,0.10)]')}
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-[var(--line-1)] border border-[var(--line-1)]">
          {stats.map((s, i) => (
            <div key={i} className="rise relative bg-black px-3 md:px-6 py-[40px] flex flex-col items-center gap-5" style={{ '--d': `${i * 0.07}s` }}>
              <CornerTicks />
              <div className="text-white font-medium text-[var(--text-stat)] leading-[1.2]">
                <RollingNumber value={s.v} suffix={s.suffix} comma={s.comma} />
              </div>
              <div key={active + s.label} className="metric-fade text-[var(--grey-2)] text-[clamp(13px,1.04vw,20px)] leading-[120%] text-center">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------------- 01 WHY PILOTS STALL ---------------- */
function WhyStall() {
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-[70px]">
        <div className="rise flex flex-col gap-6">
          <SectionLabel>// 01 WHY PILOTS STALL</SectionLabel>
          <div className="grid lg:grid-cols-[1.08fr_0.92fr] gap-10 items-start">
            <h2 className="h2" data-split style={{ lineHeight: 1 }}>
              <span className="text-white/50">Access to AI isn&rsquo;t the problem.</span>
              <span className="text-white"> Making it work in daily operations is.</span>
            </h2>
            <div className="flex flex-col gap-4">
              <p className="lead" data-split style={{ lineHeight: '120%' }}>Claude, GPT and Gemini are available to everyone. Most teams add a chatbot or an AI feature to software built for people to operate. The workflow stays the same, so do the bottlenecks, and the pilot quietly stalls.</p>
              <p className="text-white text-[var(--tt-s)] leading-[120%]">See what that looks like →</p>
            </div>
          </div>
        </div>
        <div className="grid lg:grid-cols-[1fr_auto_1fr] items-stretch gap-10">
          <div className="rise relative border border-[var(--line-1)] px-6 md:px-10 pt-[30px] pb-[44px] flex flex-col items-center gap-10" style={{ '--d': '.1s' }}>
            <CornerTicks />
            <div className="w-full flex justify-between text-[var(--tt-s)] leading-[120%]">
              <span className="text-[var(--grey-2)]">TRADITIONAL APPROACH</span>
              <span className="text-[var(--minsky-red)]">[ BOLTED-ON ]</span>
            </div>
            <div className="w-full max-w-[431px]">
              <BoltedOnLoop />
            </div>
            <p className="text-white/40 text-center text-[15px]">Nothing learns. Results stay flat, and the pilot quietly stalls.</p>
          </div>
          <div className="text-white font-medium text-[var(--tt-s)] text-center self-center">VS</div>
          <div className="rise relative border px-6 md:px-10 pt-[30px] pb-[44px] flex flex-col items-center gap-10" style={{ borderColor: 'rgba(0,212,107,0.28)', '--d': '.2s' }}>
            <CornerTicks />
            <div className="w-full flex justify-between text-[var(--tt-s)] leading-[120%]">
              <span style={{ color: GREEN }}>THE MINSKY ARCHITECTURE</span>
              <span style={{ color: GREEN }}>[ AI-NATIVE ]</span>
            </div>
            <div className="w-full flex items-center justify-center">
              <AINativeLoop />
            </div>
            <p className="text-white/40 text-center text-[15px]">Every cycle feeds the next. The system gets sharper the longer it runs.</p>
          </div>
        </div>
        <div className="rise relative flex flex-col lg:flex-row lg:items-start gap-5 lg:gap-12 px-6 md:px-12 py-5 md:py-6 border" style={{ background: 'var(--minsky-green-wash)', borderColor: 'var(--minsky-green-wire)', '--d': '.28s' }}>
          <CornerTicks green />
          <div className="flex items-center gap-[0.9em] font-medium text-[clamp(20px,1.67vw,32px)] leading-[1.1] md:whitespace-nowrap shrink-0" style={{ color: GREEN }} aria-label="AI models are not reliable systems">
            <span>AI MODELS</span><span aria-hidden="true">≠</span><span>RELIABLE SYSTEMS</span>
          </div>
          <div className="flex flex-col gap-2 text-white/80 text-[var(--tt-s)] leading-[120%]">
            <span>Minsky restructures your data, integrates with your infrastructure and redesigns the workflow, so AI works the way your organisation does.</span>
            <span style={{ color: GREEN }}>See what that looks like →</span>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ---------------- 02 IN PRODUCTION ---------------- */
const CASES = {
  'StartupTN': {
    sub: 'Funding evaluation & grant routing',
    desc: 'Four AI agents support the Tamil Nadu government\u2019s premier startup funds.',
    before: ['Every application read manually', 'Applications passed by email', 'Scores in spreadsheets', 'Long written forms', 'Depended on who you knew'],
    after: ['80% less manual screening work', '30 days faster turnaround', 'Ranked cohort, evidence for every score', 'Guided interview in their language', 'Ranked matches, tracked outreach'],
    eng: ['AI buyer-seller matchmaking matrix', 'Automatic conflict-free meeting scheduler', 'Instant WhatsApp & Email automated follow-ups', 'Live MoU signed & commercial deal tracking dashboard']
  },
  'FaMeTN': {
    sub: 'MSME buyer-seller matchmaking',
    desc: 'Matching 50,000 MSMEs by capability, capacity, certifications & geography.',
    before: ['Manual excel matching', 'Phone-based outreach', 'No tracking', 'One-time event lists', 'No deal visibility'],
    after: ['Ranked matches, tracked outreach', 'Auto scheduler, no conflicts', 'WhatsApp + Email follow-ups', 'Live MoU dashboard', '10,000+ matches logged'],
    eng: ['AI matchmaking matrix', 'Conflict-free scheduler', 'Automated follow-ups', 'Deal tracking dashboard']
  },
  'Citizen Petitions': {
    sub: 'High-volume intake & routing',
    desc: 'Multilingual petitions triaged to the right department in seconds.',
    before: ['Paper + inbox pileups', 'Manual categorisation', 'Lost follow-ups', 'No language support', 'No audit trail'],
    after: ['Auto intake & routing', 'Tamil + English + voice notes', 'Department-level queues', 'SLA tracking', 'Full audit log'],
    eng: ['Multilingual text + voice triage', 'Department router', 'SLA & escalation engine', 'Audit & citation log']
  },
  'TNGSS Summit App': {
    sub: 'Tamil Nadu Global Startup Summit',
    desc: 'Summit app for 1000s of attendees with 1-on-1 matchmaking.',
    before: ['Static agenda PDFs', 'Random networking', 'Manual meeting setup', 'No-shows', 'No follow-up'],
    after: ['Dynamic agendas', 'Personalised matchmaking', 'Scheduled 1-on-1 tables', 'QR check-in + reminders', 'Post-event deal tracking'],
    eng: ['Dynamic agenda engine', 'Attendee matchmaking', '1-on-1 table scheduler', 'Live engagement analytics']
  }
}

function InProduction() {
  const [active, setActive] = useState('StartupTN')
  const c = CASES[active]
  const order = Object.keys(CASES)
  const hovering = useRef(false)
  const loopId = useRef(0)
  const rearm = useRef(null)

  /* auto-loop tabs every 6s; manual pick restarts the clock; hover pauses */
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const arm = () => {
      clearInterval(loopId.current)
      loopId.current = setInterval(() => {
        if (!hovering.current) {
          setActive((a) => order[(order.indexOf(a) + 1) % order.length])
        }
      }, 6000)
    }
    rearm.current = arm
    arm()
    return () => clearInterval(loopId.current)
  }, [])
  const pick = (k) => {
    setActive(k)
    if (rearm.current) rearm.current()
  }

  return (
    <section id="portfolio" className="section"
      onMouseEnter={() => { hovering.current = true }}
      onMouseLeave={() => { hovering.current = false }}>
      <div className="wrap flex flex-col gap-10 lg:gap-12">
        <div className="rise flex flex-col gap-4">
          <SectionLabel>// 02 IN PRODUCTION</SectionLabel>
          <h2 className="h2" data-split>Real workflows. Measured results.</h2>
        </div>
        <div className="grid lg:grid-cols-[400px_1fr] gap-x-6 gap-y-8 lg:gap-x-6 items-start">
          <div className="rise grid grid-cols-2 lg:flex lg:flex-col gap-3 lg:sticky lg:top-8 self-start w-full" style={{ '--d': '.1s' }}>
            {Object.keys(CASES).map((k) => (
              <button key={k} onClick={() => pick(k)}
                className={`w-full text-left p-5 border ${active === k ? 'bg-white text-black border-white' : 'bg-black border-[var(--line-1)] hover:bg-white/5'}`}>
                <div className={`font-medium text-[18px] leading-[120%] ${active === k ? 'text-black' : 'text-white'}`}>{k}</div>
                <div className={`text-[14px] leading-[120%] mt-1 ${active === k ? 'text-black/60' : 'text-white/40'}`}>{CASES[k].sub}</div>
              </button>
            ))}
          </div>
          <div key={active} className="panel-in rise relative border border-[var(--line-1)] p-6 md:p-8" style={{ '--d': '.14s' }}>
            <CornerTicks />
            <div className="flex justify-center"><img src={startupLogo} alt="" className="h-[38px] object-contain" /></div>
            <h3 className="text-center text-[26px] font-medium leading-[1.15] mt-4">{c.sub}</h3>
            <Typography variant="s5" className="text-center text-white/40 mt-2">{c.desc}</Typography>
            <div className="grid grid-cols-2 md:grid-cols-[1.12fr_1fr] mt-6 border border-[var(--line-1)]">
              <div className="px-6 pt-4 pb-3 border-r border-[var(--line-1)]">
                <div className="text-white/40 tracking-[0.14em] text-[13px] font-medium -mx-6 -mt-4 px-6 pt-4 pb-3 border-b border-[var(--line-1)] bg-[var(--white-wash)]">BEFORE</div>
                {c.before.map((b) => <div key={b} className="text-white/50 border-b border-[var(--line-1)] last:border-0 py-[12px] -mx-6 px-6 text-[13px] md:text-[16px] leading-[120%]">{b}</div>)}
              </div>
              <div className="px-6 pt-4 pb-3">
                <div className="tracking-[0.14em] text-[13px] font-medium -mx-6 -mt-4 px-6 pt-4 pb-3 border-b border-[var(--line-1)] bg-[var(--white-wash)]" style={{ color: GREEN }}>WITH MINSKY</div>
                {c.after.map((b) => <div key={b} className="text-white border-b border-[var(--line-1)] last:border-0 py-[12px] -mx-6 px-6 text-[13px] md:text-[16px] leading-[120%]">{b}</div>)}
              </div>
            </div>
            <div className="mt-6 text-white/40 tracking-[0.14em] text-[13px] font-medium">WHAT WE ENGINEERED:</div>
            <div className="grid md:grid-cols-2 gap-x-8 gap-y-2 mt-3">
              {c.eng.map((e) => <div key={e} className="flex items-start gap-3 text-white text-[16px] leading-[120%]"><span style={{ color: GREEN }}>✓</span><span>{e}</span></div>)}
            </div>
            <div className="relative mt-6 px-5 py-4 border flex flex-col md:flex-row md:items-start gap-4 md:gap-6" style={{ background: 'var(--minsky-green-wash)', borderColor: 'var(--minsky-green-wire)' }}>
              <CornerTicks green />
              <span className="text-[13px] font-medium tracking-wide md:whitespace-nowrap" style={{ color: GREEN }}>AI RANKS. PEOPLE DECIDE</span>
              <span className="text-white/70 text-[16px] leading-[120%]">Committees set cutoffs and can override any ranking. Every single inference and decision is logged with verifiable citations.</span>
            </div>
          </div>
          <div className="rise bg-[var(--ink-3)] px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 lg:col-start-2" style={{ '--d': '.2s' }}>
            <span className="text-white text-[var(--tt-s)] leading-[120%]">Want this operational leverage for your organization?</span>
            <CTAButton>Book a 30-min call</CTAButton>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ---------------- 03 BEYOND GOVT ---------------- */
function BeyondGovt() {
  const tableRef = useRef(null)

  /* converging entrance: each row glides to center + flashes green once */
  useEffect(() => {
    const table = tableRef.current
    if (!table) return
    const rows = Array.from(table.querySelectorAll('.conv-row'))
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      rows.forEach((r) => {
        r.classList.add('in')
        const b = r.querySelector('.conv-bolt')
        if (b) b.classList.add('on')
      })
      return
    }
    let alive = true
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return
        const row = e.target
        io.unobserve(row)
        row.classList.add('in')
        const bolt = row.querySelector('.conv-bolt')
        if (bolt) setTimeout(() => { if (alive) bolt.classList.add('on') }, 350)
      })
    }, { threshold: 0.2, rootMargin: '0px 0px -8% 0px' })
    rows.forEach((r) => io.observe(r))
    return () => { alive = false; io.disconnect() }
  }, [])

  const rows = [
    ['Funding application screening', 'Pitch decks, balance sheets & tax proofs evaluated against cohort rubrics', ['Loan underwriting', 'Vendor onboarding', 'Technical hiring screens']],
    ['Buyer-seller matchmaking', 'Matching 50,000 MSMEs by capability, capacity, certifications & geography', ['B2B marketplaces', 'Lead routing', 'Supplier & sub-contractor matching']],
    ['Citizen petition triage', 'Multilingual unstructured text, voice notes and photos categorized to departments', ['Support ticket triage', 'Compliance complaints', 'Insurance claims intake']],
    ['No-code approval workflows', 'Multi-officer committees with configurable cutoffs, comments, and audit trails', ['Enterprise procurement', 'Employee onboarding', 'Credit risk approvals']],
    ['Summit app for 1000s of attendees', 'Dynamic agendas, personalized matchmaking and scheduled 1-on-1 meeting tables', ['Industry conferences', 'High-value communities', 'Key customer events']],
  ]
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-8">
        <SectionLabel>// 03 BEYOND GOVERNMENT</SectionLabel>
        <div className="rise grid lg:grid-cols-2 gap-8 items-end" style={{ '--d': '.08s' }}>
          <h2 className="h2" data-split>Same engine. Your business.</h2>
          <p className="lead" data-split>Government is the hardest place to ship AI: high volume, public scrutiny, statutory audits. If it holds up there, it holds up for your business.</p>
        </div>
        <div ref={tableRef} className="rise border border-[var(--line-1)] overflow-hidden" style={{ '--d': '.16s' }}>
          <div className="conv-row no-flash grid grid-cols-2 md:grid-cols-[1fr_72px_1fr] text-[13px] tracking-[0.1em] text-white/40 border-b border-[var(--line-1)] bg-[var(--white-wash)] divide-x divide-[var(--line-1)]">
            <div className="conv-l px-6 py-5">GOVERNMENT</div><div className="hidden md:block" /><div className="conv-r px-6 py-5" style={{ color: GREEN }}>ENTERPRISE APPLICATION</div>
          </div>
          {rows.map(([t, d, tags]) => (
            <div key={t} className="conv-row group grid md:grid-cols-[1fr_72px_1fr] border-b border-[var(--line-1)] last:border-0 md:divide-x md:divide-[var(--line-1)] transition-colors duration-300 hover:bg-[var(--minsky-green-wash)]">
              <div className="conv-l px-6 py-5"><div className="text-white text-[16px] leading-[120%]">{t}</div><div className="text-white/40 text-[15px] leading-[140%] mt-1">{d}</div></div>
              <div className="hidden md:flex items-center justify-center"><img src={boltIcon} alt="" className="conv-bolt w-9 h-9 object-contain" /></div>
              <div className="conv-r px-6 py-5 text-white/80 text-[15px] leading-[140%] flex flex-wrap gap-x-2 gap-y-1 items-center content-center">
                {tags.map((g, gi) => (
                  <span key={g} className="md:whitespace-nowrap"><span className="text-white/25 group-hover:text-[var(--minsky-green)] transition-colors duration-300">[</span> {g} <span className="text-white/25 group-hover:text-[var(--minsky-green)] transition-colors duration-300">]</span>{gi < tags.length - 1 ? ' ' : ''}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------------- 04 HOW WE BUILD — scroll-driven stepper ---------------- */
function HowWeBuild() {
  return <HowWeBuildScroll />
}

/* ---------------- 06 ENGAGE ---------------- */
function Engage() {
  const cols = [
    ['01', '2 WEEKS', 'Discovery sprint', 'We map one workflow, its data and every decision point.', 'You get: workflow map, ROI estimate, pilot plan. Fixed price.'],
    ['02', '6–8 WEEKS', 'Pilot', 'One workflow live with real users, a person reviewing every AI decision.', 'You get: measured before and after.'],
    ['03', '8–12 WEEKS', 'Production', 'Scale across teams, connect your systems, add monitoring and governance.', 'You get: a system your teams run on.'],
    ['04', 'ONGOING', 'Operate & improve', 'Evaluations, monitoring and retraining from your team\u2019s feedback.', 'You get: a monthly performance report.'],
  ]
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-8">
        <div className="rise flex flex-col gap-3">
          <SectionLabel>// 05 HOW WE ENGAGE</SectionLabel>
          <h2 className="h2" data-split>Start small. Scale on results.</h2>
          <p className="lead" data-split>Each stage ends with a decision. You continue only when the numbers justify it.</p>
        </div>
        <div className="rise relative grid md:grid-cols-4 border border-[var(--line-1)]" style={{ '--d': '.1s' }}>
          <CornerPluses />
          {[25, 50, 75].map((p) => (
            <span key={p} aria-hidden className="absolute inset-y-0 pointer-events-none hidden md:block" style={{ left: `${p}%` }}>
              <PlusMark className="top-0" />
              <PlusMark className="bottom-0" />
            </span>
          ))}
          {cols.map(([n, t, h, d, g], ci) => (
            <div key={n} className="p-6 md:p-8 border-b md:border-b-0 md:border-r last:border-0 border-[var(--line-1)] flex flex-col gap-3 min-h-[220px] md:min-h-[300px]">
              <div className="flex justify-between text-[13px] tracking-[0.14em] font-medium"><span className="text-white/40">{n}</span><span style={ci === cols.length - 1 ? { color: GREEN } : undefined} className={ci === cols.length - 1 ? undefined : 'text-orange-300/80'}>[ {t} ]</span></div>
              <div className="text-white text-[clamp(17px,1.15vw,20px)] font-medium">{h}</div>
              <div className="text-white/50 text-[var(--tt-s)] leading-[120%]">{d}</div>
              <div className="mt-auto text-white/40 text-[14px] border-t border-[var(--line-1)] pt-4">{g}</div>
            </div>
          ))}
        </div>
        <div className="rise bg-[var(--ink-3)] border border-[var(--line-1)] px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4" style={{ '--d': '.18s' }}>
          <span className="text-white/80 text-[var(--tt-s)] leading-[120%]">Low risk first step. Zero software migration required upfront.</span>
          <a href="#contact" className="btn-metal small"><span>Start with the 2-week sprint</span></a>
        </div>
      </div>
    </section>
  )
}

/* ---------------- 07 TRUST ---------------- */
function Trust() {
  const cards = [
    [iconNoLockin, 'No lock-in', 'Open-source and self-hosted where possible. The right model for each task.'],
    [iconCloud, 'Runs in your cloud', 'FaMeTN\u2019s CRM runs in its own AWS account in Mumbai.'],
    [iconTrace, 'Every action traceable', 'Audit logs keep a before-and-after snapshot of every change.'],
    [iconConfidence, 'Confidence thresholds', 'AI acts alone only when it is sure. You set where a person must approve.'],
    [iconRoles, 'Role-based access', 'Permissions by role, organisation and project. People see only what they need.'],
    [iconEncrypted, 'Encrypted end to end', 'Encrypted in transit and at rest. ', 'Built for DPDP Act and GDPR needs.'],
  ]
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-8">
        <div className="rise flex flex-col gap-3">
          <SectionLabel>// 06 TRUST &amp; SECURITY</SectionLabel>
          <h2 className="h2" data-split>Your data. Your rules. Your control.</h2>
          <p className="lead max-w-[900px]" data-split>Engineered from day zero to satisfy statutory state government compliance, public audits, and stringent data sovereignty laws.</p>
        </div>
        <div className="rise grid md:grid-cols-3 gap-6" style={{ '--d': '.1s' }}>
          {cards.map(([img, h, d, hot]) => (
            <div key={h} className="relative bg-black border border-[var(--line-1)] p-6 md:p-8 transition-colors duration-300 hover:bg-white/[0.02]">
              <CornerTicks />
              <img src={img} alt="" className="w-8 h-8 object-contain" />
              <div className="text-white font-medium mt-8 text-[clamp(17px,1.15vw,20px)]">{h}</div>
              <div className="text-white/40 text-[var(--tt-s)] leading-[140%] mt-3">{d}{hot ? <span className="text-orange-300/90">{hot}</span> : null}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------------- 08 CHANGES + FIT + FAQ ---------------- */
function Changes() {
  const rows = [
    ['01', 'Users get there faster', 'Intelligence meets people where they already are, so cognitive friction drops to zero across customer channels.'],
    ['02', 'Software gets proactive', 'Less manual searching, repetitive status updating, routing emails, and chasing approvals by hand.'],
    ['03', 'Workflows adapt', 'The next operational action dynamically responds to context, changing rules and past historical outcomes.'],
    ['04', 'Improvement compounds', 'Every interaction, correction and real-world outcome makes the entire operational system sharper over time.'],
  ]
  const [open, setOpen] = useState(0)
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-8">
        <div className="rise flex flex-col gap-3">
          <SectionLabel>// 07 WHAT CHANGES</SectionLabel>
          <h2 className="h2" data-split>From traditional software to AI-native.</h2>
        </div>
        <div className="rise border border-[var(--line-1)] divide-y divide-[var(--line-1)]" style={{ '--d': '.1s' }}>
          {rows.map(([n, h, d], i) => (
            <button key={n} onClick={() => setOpen(i)} className={`w-full grid md:grid-cols-[80px_1fr_1fr] gap-4 px-6 md:px-8 py-6 md:py-7 text-left hover:bg-white/[0.02] ${open === i ? 'bg-white/[0.03]' : ''}`}>
              <span className="text-white/20 text-[clamp(20px,1.3vw,24px)]">{n}</span>
              <span className="text-[clamp(20px,1.3vw,24px)] font-medium" style={open === i ? { color: GREEN } : { color: 'rgba(255,255,255,.7)' }}>{h}</span>
              <span className="text-white/50 text-[var(--tt-s)] leading-[140%]">{d}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}

function Fit() {
  const yes = [
    'Key workflows still rely on people collecting, reviewing and routing work by hand',
    'Knowledge is scattered across teams, documents, ERPs and legacy systems',
    'You need AI inside real workflows, far beyond a toy chatbot or stalled pilot',
    'Decisions require strict oversight, verifiable traceability and government-grade governance',
  ]
  const no = [
    'You only need a simple customer chatbot or a thin single-prompt feature',
    'There is no clear repetitive operational workflow or business pain yet',
    'You expect AI to completely eliminate accountable human judgment',
    'You want a novelty demo for PR, not a resilient system that runs in production',
  ]
  const [show, setShow] = useState([false, true, false, true])
  const [struck, setStruck] = useState([false, false, true, false])
  return (
    <section className="section">
      <div className="wrap flex flex-col gap-8">
        <div className="rise flex flex-col gap-3">
          <SectionLabel>/ 08 FIT, STATED PLAINLY</SectionLabel>
          <h2 className="h2" data-split>Is this right for you?</h2>
        </div>
          <div className="rise grid md:grid-cols-[1fr_auto_1fr] gap-6 items-stretch" style={{ '--d': '.1s' }}>
          <div className="relative border border-[var(--line-1)] p-6 md:p-8" style={{ borderColor: 'rgba(0,212,107,.4)' }}>
            <CornerTicks green />
            <div className="flex justify-between text-[13px] tracking-[0.14em] font-medium mb-6"><span style={{ color: GREEN }}>MAKES SENSE IF</span><span className="text-white/30">[ CLICK TO QUALIFY ]</span></div>
            {yes.map((t, i) => (
              <button key={t} onClick={() => setShow((s) => s.map((v, j) => (j === i ? !v : v)))}
                className="w-full flex gap-4 text-left py-3 text-[var(--tt-s)] leading-[140%]">
                <span className="shrink-0 min-w-[2.8em] font-medium" style={show[i] ? { color: GREEN } : { color: 'rgba(255,255,255,.35)' }}>{show[i] ? '[ ✓ ]' : '[ ]'}</span>
                <span style={show[i] ? { color: GREEN } : { color: 'rgba(255,255,255,.7)' }}>{t}</span>
              </button>
            ))}
            <div className="mt-6 border-t border-[var(--line-1)] pt-4 flex justify-between items-center text-[13px] tracking-[0.14em] font-medium">
              <span className="text-white/30">FIT SCORE</span>
              <span><span style={{ color: GREEN }}>[ {show.filter(Boolean).length}/4 ]</span><span aria-hidden className="text-white/20"> //</span></span>
            </div>
          </div>
          <div className="hidden md:flex items-center justify-center text-[32px] font-medium px-2" style={{ color: GREEN }} aria-hidden>?</div>
          <div className="relative border border-[var(--line-1)] p-6 md:p-8">
            <CornerTicks />
            <div className="flex justify-between text-[13px] tracking-[0.14em] font-medium mb-6"><span className="text-white">PROBABLY NOT IF</span><span className="text-white/30">[ NON-GOALS ]</span></div>
            {no.map((t, i) => (
              <button key={t} onClick={() => setStruck((s) => s.map((v, j) => (j === i ? !v : v)))}
                className="w-full flex gap-4 text-left py-3 text-[var(--tt-s)] leading-[140%]">
                <span className="shrink-0 min-w-[2.8em] font-medium" style={struck[i] ? { color: 'rgba(248,113,113,.9)' } : { color: 'rgba(255,255,255,.35)' }}>{struck[i] ? '[ ! ]' : '[ ]'}</span>
                <span className={struck[i] ? 'text-white/40 line-through' : 'text-white/50'}>{t}</span>
              </button>
            ))}
            <div className="mt-6 border-t border-[var(--line-1)] pt-4 flex justify-between items-center text-[13px] tracking-[0.14em] font-medium">
              <span className="text-white/30">DISMISSED</span>
              <span className="text-white/60">[ {struck.filter(Boolean).length}/4 ]</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Faq() {
  const faqs = [
    ['Do we have to replace our existing software?', 'No. We build around and across what you already have. Minsky integrates with your ERP, CRM, databases, cloud storage, WhatsApp Business APIs, and legacy portals through secure APIs and event connectors.'],
    ['Which AI models do you use?', 'The right model for each task — open-source and hosted where possible, frontier models where they earn it. The architecture is model-agnostic so you are never locked in.'],
    ['Will AI make decisions without us?', 'Only where you allow it. You set confidence thresholds. Below the threshold a person must approve. Every inference and override is logged with citations.'],
    ['How fast will we see results?', 'Discovery sprint is 2 weeks. Pilot goes live in 6–8 weeks with real users and before/after measurement. Production scale follows in 8–12 weeks.'],
    ['What does it cost?', 'Fixed-price 2-week discovery sprint first. Pilot and production are scoped on measured ROI — you continue only when the numbers justify it.'],
    ['Is our data safe?', 'Yes. Runs in your cloud (e.g. FaMeTN\u2019s CRM in its own AWS Mumbai account), encrypted in transit and at rest, role-based access, full audit trails. Built for DPDP Act and GDPR needs.'],
  ]
  const [open, setOpen] = useState(0)
  return (
    <section id="blog" className="section">
      <div className="wrap flex flex-col gap-10 items-center">
        <div className="rise flex flex-col gap-4 items-center text-center" style={{ '--d': '.05s' }}>
          <SectionLabel>// 09 QUESTIONS, ANSWERED</SectionLabel>
          <h2 className="h2" data-split>Questions, answered.</h2>
        </div>
        <div className="rise w-full max-w-[1100px] border border-[var(--line-1)] divide-y divide-[var(--line-1)]" style={{ '--d': '.12s' }}>
          {faqs.map(([q, a], i) => (
            <div key={q}>
              <button onClick={() => setOpen(open === i ? -1 : i)} className="w-full flex justify-between items-center gap-6 px-6 md:px-10 py-7 text-left hover:bg-white/[0.02]">
                <span className="text-white text-[clamp(17px,1.1vw,19px)] font-medium">{q}</span><span className="text-white/40 text-[20px] shrink-0">{open === i ? '−' : '+'}</span>
              </button>
              {open === i && <Typography variant="s5" className="faq-a px-6 md:px-10 pb-7 text-white/50 max-w-[1000px]">{a}</Typography>}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------------- CONTACT / FOOTER ---------------- */
function Contact() {
  const [sent, setSent] = useState(false)
  return (
    <footer id="contact" className="section bg-[#111] border-t border-[var(--line-1)]">
      <div className="wrap flex flex-col gap-12">
        <div className="rise bg-[var(--ink-3)] border border-[var(--line-1)] px-6 md:px-8 py-12 flex flex-col items-center text-center gap-5">
          <h2 className="font-outfit text-[clamp(26px,2.2vw,36px)] font-medium leading-tight" data-split>Ready to see it running?</h2>
          <p className="text-white/50 max-w-[620px] text-[var(--tt-s)] leading-[120%]">We will walk you through a live demo using a real event scenario close to your use case. No slides. If it fits, we scope the customisation together.</p>
          <div className="flex flex-wrap justify-center gap-4 mt-2">
            <a href="mailto:info@minsky.in" className="btn-metal small"><span>Book a Demo</span></a>
            <a href="mailto:info@minsky.in" className="inline-block rounded-[10px] border border-[var(--line-2)] bg-black px-6 py-2 text-white/80 text-[16px] hover:border-white/40">✉ info@minsky.in</a>
          </div>
        </div>
        <div className="rise border border-[var(--line-1)] px-6 md:px-8 py-8 flex flex-col md:flex-row md:items-center justify-between gap-5" style={{ '--d': '.06s' }}>
          <div>
            <div className="text-white text-[19px] font-medium">Not sure where to start?</div>
            <p className="text-white/50 text-[var(--tt-s)] leading-[140%] mt-2 max-w-[640px]">Tell us what you are working on. We will point you to the right module — or tell you honestly if none of them are a fit yet.</p>
          </div>
          <div className="flex flex-wrap gap-3 shrink-0">
            <a href="mailto:info@minsky.in" className="btn-metal small"><span>Talks to us</span></a>
            <a href="#portfolio" className="inline-block rounded-[10px] border border-[var(--line-2)] bg-black px-6 py-2 text-white/80 text-[16px] hover:border-white/40">See our Services</a>
          </div>
        </div>
        <div className="rise grid lg:grid-cols-[1fr_1fr] gap-12 items-start" style={{ '--d': '.12s' }}>
          <div>
            <div className="font-outfit text-white text-[clamp(28px,2.6vw,44px)] font-medium tracking-normal" data-split>Let&rsquo;s Collaborate!</div>
            <div className="grid grid-cols-2 gap-8 mt-6 text-[14px] max-w-[420px]">
              <div><div className="text-white/40 mb-2">Quick Links</div><div className="flex flex-col gap-1 text-white/70"><a href="#top">Home</a><a href="#portfolio">Portfolio</a><a href="#blog">Blog</a></div></div>
              <div><div className="text-white/40 mb-2">Services</div><div className="flex flex-col gap-1 text-white/70"><span>Design</span><span>Development</span><span>Deployment</span></div></div>
            </div>
            <div className="mt-6 text-[13px] flex flex-col gap-1">
              <span style={{ color: GREEN }}>■ LinkedIn</span><span className="text-white/60">Info@minsky.in</span><span className="text-white/60">+91 89251 96011</span>
            </div>
          </div>
          <form onSubmit={(e) => { e.preventDefault(); setSent(true) }}
            className="bg-black/40 border border-[var(--line-1)] rounded-lg p-6 flex flex-col gap-4">
            {[['Full Name', 'Enter Name'], ['Email ID', 'xyz@gmail.com'], ['Phone Number', '+91']].map(([l, ph]) => (
              <label key={l} className="flex flex-col gap-2 text-[14px]">
                <span className="text-white/70">{l}</span>
                <input required placeholder={ph} className="bg-transparent border border-[var(--line-1)] rounded px-4 py-3 text-white placeholder:text-white/25 outline-none focus:border-[var(--minsky-green)]" />
              </label>
            ))}
            <label className="flex flex-col gap-2 text-[14px]">
              <span className="text-white/70">Message</span>
              <textarea required rows={5} placeholder="Write a message" className="bg-transparent border border-[var(--line-1)] rounded px-4 py-3 text-white placeholder:text-white/25 outline-none focus:border-[var(--minsky-green)]" />
            </label>
            <div className="flex justify-end">
              <button type="submit" className="btn-metal small"><span>CONTACT</span></button>
            </div>
            {sent && <div className="text-[14px]" style={{ color: GREEN }}>Thanks — we&rsquo;ll get back within one business day.</div>}
          </form>
        </div>
        <div className="border-t border-[var(--line-1)] pt-4 text-center text-white/30 text-[12px]">© 2026 Minsky. AI-native &amp; reliable.</div>
      </div>
    </footer>
  )
}

export default function App() {
  /* Lenis smooth wheel scroll (skipped for reduced-motion);
     instance shared on window for anchor + stepper jumps. */
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let raf = 0
    let lenis = null
    try {
      lenis = new Lenis({
        duration: 1.25,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
      })
      window.__lenis = lenis
    } catch (e) {
      lenis = null
    }
    const onClick = (e) => {
      if (!lenis) return
      const a = e.target && e.target.closest ? e.target.closest('a[href^="#"]') : null
      if (!a) return
      const hash = a.getAttribute('href')
      if (!hash || hash.length < 2) return
      const el = document.querySelector(hash)
      if (!el) return
      e.preventDefault()
      try {
        lenis.scrollTo(el)
      } catch (err) {}
    }
    document.addEventListener('click', onClick)
    const loop = (time) => {
      if (lenis) {
        try {
          lenis.raf(time)
        } catch (e) {}
      }
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      document.removeEventListener('click', onClick)
      if (lenis) {
        try {
          lenis.destroy()
        } catch (e) {}
        if (window.__lenis === lenis) window.__lenis = null
      }
    }
  }, [])

  /* scroll reveal: sections toggle .in as they enter AND leave, so
     blocks rise on the way in and settle back out on the way out;
     CSS animates .wrap (transform cleared after, so sticky keeps working) */
  useEffect(() => {
    /* masked word-split for tagged headings (runs before observing,
       so words are wrapped ahead of the first .in toggle) */
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const splitEl = (el) => {
        let idx = 0
        const walk = (node) => {
          Array.from(node.childNodes).forEach((child) => {
            if (child.nodeType === 3) {
              const frag = document.createDocumentFragment()
              child.textContent.split(/(\s+)/).forEach((part) => {
                if (!part) return
                if (/^\s+$/.test(part)) {
                  frag.appendChild(document.createTextNode(' '))
                } else {
                  const mask = document.createElement('span')
                  mask.className = 'wmask'
                  const w = document.createElement('span')
                  w.className = 'wword'
                  w.style.setProperty('--wd', idx)
                  idx += 1
                  w.textContent = part
                  mask.appendChild(w)
                  frag.appendChild(mask)
                }
              })
              node.replaceChild(frag, child)
            } else if (child.nodeType === 1 && child.tagName !== 'BR') {
              walk(child)
            }
          })
        }
        walk(el)
      }
      document.querySelectorAll('[data-split]').forEach((el) => {
        if (el.dataset && !el.dataset.splitDone) {
          el.dataset.splitDone = '1'
          try {
            splitEl(el)
          } catch (e) {}
        }
      })
      requestAnimationFrame(() => requestAnimationFrame(() => {
        document.body.classList.add('is-loaded')
      }))
    }
    const els = Array.from(document.querySelectorAll('section.section, footer.section'))
    if (!els.length) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      els.forEach((el) => el.classList.add('in'))
      return
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        e.target.classList.toggle('in', e.isIntersecting)
      })
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' })
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  return (
    <div className="bg-black text-white font-grotesk min-h-screen">
      <Hero />
      <Stats />
      <WhyStall />
      <InProduction />
      <BeyondGovt />
      <HowWeBuild />
      <Engage />
      <Trust />
      <Changes />
      <Fit />
      <Faq />
      <Contact />
    </div>
  )
}
