import { useEffect, useState } from 'react'

/* Eyebrow phrase rotator — decode-scramble loop with a left-anchored,
   fluid-width container: no sizer, no absolute overlay, text-left.
   The span before it ("Minsky .") never moves; the phrase grows/shrinks
   toward the right only.
   Sequence (identity → what → proof, all strings from site copy):
     1. AI-NATIVE & RELIABLE          (badge identity, Figma/PDF)
     2. AI-NATIVE & RELIABLE SYSTEM   (what Minsky builds — hero H1)
     3. LIVE IN PRODUCTION            (proof — stats section idle) */
const PHRASES = ['AI-NATIVE & RELIABLE', 'AI-NATIVE & RELIABLE SYSTEM', 'LIVE IN PRODUCTION']
const SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#/-.'
const SCRAMBLE_MS = 850
const HOLD_MS = 2600

export default function BadgeScramble() {
  const [text, setText] = useState(PHRASES[0])

  useEffect(() => {
    let alive = true
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined
    let idx = 0
    let raf = 0
    let timeout = 0

    const scrambleTo = (str) =>
      new Promise((resolve) => {
        const start = performance.now()
        const tick = (now) => {
          if (!alive) return resolve()
          const p = Math.min((now - start) / SCRAMBLE_MS, 1)
          const lock = Math.floor(p * str.length)
          let s = ''
          for (let i = 0; i < str.length; i++) {
            const ch = str[i]
            s += i < lock || ch === ' ' || ch === '&' ? ch : SCRAMBLE_CHARS[(Math.random() * SCRAMBLE_CHARS.length) | 0]
          }
          setText(s)
          if (p < 1) raf = requestAnimationFrame(tick)
          else {
            setText(str)
            resolve()
          }
        }
        raf = requestAnimationFrame(tick)
      })

    const loop = async () => {
      // hold the identity phrase first so the hero reads clean on load
      await new Promise((r) => { timeout = setTimeout(r, HOLD_MS) })
      while (alive) {
        idx = (idx + 1) % PHRASES.length
        await scrambleTo(PHRASES[idx])
        if (!alive) return
        await new Promise((r) => { timeout = setTimeout(r, HOLD_MS) })
      }
    }
    loop()

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      clearTimeout(timeout)
    }
  }, [])

  return (
    <span className="inline-block whitespace-nowrap text-left" aria-live="off">
      {text}
    </span>
  )
}
