import { useEffect, useRef } from 'react'
import boltedUrl from '../asset/Bolted-On.svg'

/* ------------------------------------------------------------------
   Animates the EXISTING Bolted-On.svg artwork in place — no redraws,
   no replaced structure, no dynamically created SVG overlays. The SVG
   is injected inline (same-origin fetch of the bundled asset) and a
   single rAF director drives a 7s loop using ONLY plain transforms,
   opacities and stop-colors on EXISTING nodes:

      0.0-1.6s  reveal (card fades/scales in flush, neutral gradient)
      1.6-3.2s  thermal overload (line 2 types on, card stop heats
                 #222->#AD0101, 12Hz micro-jitter, slot glow)
      3.2-4.8s  sticker peel (card lifts toward top-left:
                 translate(-44,-66) rotate(25deg) scale(1.08) with a
                 -16deg rotateX curl lean, shadow deepens, line 3
                 types on, arrow draws in, lines 1-2 dim)
      4.8-6.2s  float (peeled card bobs gently over the revealed slot)
      6.2-7.0s  crossfade reset (lifted card fades out, seated card
                 fades back in, gradient cools — no snap, no rewind)

   Interactions: pointer-tracked ±5° tilt on #Grid (card gets 1.5x),
   click on #Featured Card presses flush, holds 250ms, restarts heat.
   A static <img> fallback sits underneath and is only faded out once
   the animated layer is proven live — the card never goes blank.
------------------------------------------------------------------- */

const LOOP = 7000
const REDUCED = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
const FINE = typeof window !== 'undefined' && window.matchMedia('(pointer: fine)').matches

const easeOutCubic = (p) => 1 - Math.pow(1 - p, 3)
const easeInOut = (p) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2)
const JITTER = [[1, -1], [-1, 1], [-0.5, 0.5], [0.5, -0.5], [0, 0]]
const hexRgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]
const STOP_COOL = hexRgb('#222222')
const STOP_HOT = hexRgb('#AD0101')

// Peeled (fully lifted) card pose — sticker pulled toward top-left,
// leaning back toward the viewer like a curling sticker.
const PEEL_R = 25
const PEEL_X = -44
const PEEL_Y = -66
const PEEL_S = 1.08
const PEEL_LEAN = -16 // rotateX lean while peeled (curl toward viewer)

export default function BoltedOnLoop() {
  const ref = useRef(null)
  const imgRef = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0
    const removers = []
    const tilt = { x: 0, y: 0, tx: 0, ty: 0 }
    let click = null // { t0 } while a click re-stick override runs
    let lastShadow = ''
    let lastR = 0, lastX = 0, lastY = 0, lastS = 1 // card pose cache for click-resume
    const die = (why) => {
      // leave the static fallback image visible so the card never goes blank
      try { console.warn('[BoltedOnLoop] static fallback: ' + why) } catch (e) {}
    }

    fetch(boltedUrl)
      .then((r) => {
        if (!r.ok) throw new Error('fetch ' + r.status)
        return r.text()
      })
      .then((text) => {
        if (!alive || !ref.current) return
        let svg
        try {
          const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
          svg = doc.documentElement
          if (!svg || svg.tagName.toLowerCase() !== 'svg') throw new Error('not an svg')
        } catch (e) {
          die('parse failed (' + (e && e.message) + ')')
          return
        }
        svg.style.width = '100%'
        svg.style.height = 'auto'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.style.perspective = '1000px'
        svg.setAttribute('aria-hidden', 'true')
        ref.current.appendChild(svg)

        // NOTE: query the live (adopted) tree — doc.getElementById breaks
        // after appendChild adopts nodes into the host document.
        const byId = (id) => {
          try { return svg.querySelector('[id="' + id + '"]') } catch (e) { return null }
        }
        const card = byId('Featured Card')
        const slot = byId('Tile_6')
        const grid = byId('Grid')
        if (!card || !slot || !grid) {
          die('missing node (card=' + !!card + ' slot=' + !!slot + ' grid=' + !!grid + ')')
          svg.remove()
          return
        }
        // animated layer is live — fade the static fallback out
        if (imgRef.current) imgRef.current.style.opacity = '0'

        const line1 = byId('Feature Description')
        const line2 = byId('Overload Description')
        const line3 = byId('Peel Off Description')
        const caret = byId('Caret')
        const arrow = byId('Vector_4')
        const dashed = slot.querySelector('rect[stroke-dasharray]')
        const target = dashed || slot
        // user + product blocks: ambient life (existing nodes only)
        const userIcon = byId('User-Circle-Single--Streamline-Flex')
        const productIcon = byId('Product Icon')
        const productSymbol = byId('Product Symbol')
        ;[userIcon, productIcon, productSymbol].forEach((el) => {
          if (el) { el.style.transformBox = 'fill-box'; el.style.transformOrigin = 'center' }
        })
        const stops = svg.querySelectorAll('#paint2_linear_9_252 stop')
        const stop1 = stops[0] || null
        const stop2 = stops[1] || null
        let arrowLen = 0
        try {
          if (arrow && arrow.getTotalLength) arrowLen = arrow.getTotalLength()
        } catch (e) { arrowLen = 0 }
        if (stop1) {
          try { stop1.style.stopColor = '#161616' } catch (e) {}
        }
        // caret home x + per-line end offsets (traveling terminal cursor)
        let caretDx1 = 0
        let caretDx2 = 0
        try {
          if (caret) {
            const cb = caret.getBBox()
            if (line1) {
              const b1 = line1.getBBox()
              caretDx1 = b1.x + b1.width - cb.x + 5
            }
            if (line2) {
              const b2 = line2.getBBox()
              caretDx2 = b2.x + b2.width - cb.x + 5
            }
          }
        } catch (e) { caretDx1 = 0; caretDx2 = 0 }
        ;[line1, line2, line3].forEach((el) => {
          if (el) el.style.transition = 'opacity .3s ease'
        })
        if (arrow) {
          arrow.style.transition = 'opacity .3s ease, transform .4s cubic-bezier(0.16, 1, 0.3, 1)'
          arrow.style.transformBox = 'fill-box'
          arrow.style.transformOrigin = 'center'
          if (arrowLen > 0) {
            arrow.style.strokeDasharray = String(arrowLen)
            arrow.style.strokeDashoffset = String(arrowLen)
          }
        }
        if (grid) grid.style.transformStyle = 'preserve-3d'
        // The card rect carries a baked rotate(10.6696 about its top-left).
        // Group transforms compose ON TOP of it, so true flat needs a
        // counter-rotation about the same pivot, plus a -32px shift that
        // centers the card inside #Tile_6 (rect x154 vs slot x122).
        const BAKED_ROT = 10.6696
        const SLOT_DX = -32
        const PIVOT = '154.078px 161.543px'
        const poseTf = (r, x, y, s, brx, bry) =>
          `translate(${(x + SLOT_DX).toFixed(2)}px, ${y.toFixed(2)}px) rotate(${(r - BAKED_ROT).toFixed(2)}deg) ` +
          `rotateX(${(brx || 0).toFixed(3)}deg) rotateY(${(bry || 0).toFixed(3)}deg) scale(${s.toFixed(3)})`
        if (card) {
          card.style.transformOrigin = PIVOT
          card.style.transition = 'filter .5s ease'
          card.style.cursor = 'pointer'
        }

        if (REDUCED) {
          if (card) card.style.transform = poseTf(0, 0, 0, 1, 0, 0)
          if (line1) line1.style.opacity = '1'
          return
        }

        const onMove = (e) => {
          if (!ref.current) return
          const r = ref.current.getBoundingClientRect()
          const nx = (e.clientX - r.left) / r.width - 0.5
          const ny = (e.clientY - r.top) / r.height - 0.5
          tilt.tx = -ny * 10
          tilt.ty = nx * 10
        }
        const onLeave = () => { tilt.tx = 0; tilt.ty = 0 }
        const onCardClick = () => {
          if (!card) return
          click = { t0: performance.now(), r0: lastR, x0: lastX, y0: lastY, s0: lastS }
        }
        const host = ref.current
        if (FINE) {
          host.addEventListener('pointermove', onMove)
          host.addEventListener('pointerleave', onLeave)
          removers.push(() => {
            host.removeEventListener('pointermove', onMove)
            host.removeEventListener('pointerleave', onLeave)
          })
        }
        if (card) {
          card.addEventListener('click', onCardClick)
          removers.push(() => card.removeEventListener('click', onCardClick))
        }

        const t0 = { v: performance.now() }
        // gradient heat follower: chases the phase target smoothly
        const heat = { c: STOP_COOL.slice() }

        const frame = (now) => {
          if (!alive) return
          tilt.x += (tilt.tx - tilt.x) * 0.12
          tilt.y += (tilt.ty - tilt.y) * 0.12
          if (grid) grid.style.transform = `rotateX(${tilt.x.toFixed(3)}deg) rotateY(${tilt.y.toFixed(3)}deg)`

          // user + product ambient: breathing icons, dimmed while peeled
          // (spotlight follows the card — same treatment as the lines)
          const lt = (now - t0.v) % LOOP
          const dim = (lt >= 3200 && lt < 6200) ? 0.55 : 1
          const up = (lt / 4200) * Math.PI * 2
          const pp = up + Math.PI
          if (userIcon) {
            userIcon.style.opacity = ((0.55 + 0.25 * Math.sin(up)) * dim).toFixed(3)
            userIcon.style.transform = `scale(${(1 + 0.03 * Math.sin(up)).toFixed(3)})`
          }
          if (productIcon) {
            productIcon.style.opacity = ((0.6 + 0.25 * Math.sin(pp)) * dim).toFixed(3)
            productIcon.style.transform = `scale(${(1 + 0.04 * Math.sin(pp)).toFixed(3)})`
          }
          if (productSymbol) {
            productSymbol.style.opacity = ((0.1 + 0.05 * Math.sin(pp + 1)).toFixed(3))
            productSymbol.style.transform = `rotate(${(Math.sin(pp) * 6).toFixed(2)}deg)`
          }

          if (click && card) {
            // click override: overshoot flat (~250ms), hold to 500ms, resume at heat
            const e = now - click.t0
            if (e < 250) {
              const k = 1 - easeOutCubic(Math.min(e / 250, 1))
              const r = click.r0 * k
              const x = click.x0 * k
              const y = click.y0 * k
              const s = 1 + (click.s0 - 1) * k
              lastR = r; lastX = x; lastY = y; lastS = s
              card.style.transform = poseTf(r, x, y, s, 0, 0)
              card.style.filter = 'drop-shadow(0 4px 10px rgba(0,0,0,0.5))'
              lastShadow = 'flush'
            } else if (e < 500) {
              lastR = 0; lastX = 0; lastY = 0; lastS = 1
              card.style.transform = poseTf(0, 0, 0, 1, 0, 0)
            } else {
              t0.v = now - 1600
              click = null
            }
          } else if (card) {
            const t = (now - t0.v) % LOOP
            let r; let x; let y; let s; let op; let lean = 0
            if (t < 400) {
              // reveal: fade + settle in flush
              const q = easeOutCubic(t / 400)
              r = 0; x = 0; y = 0; s = 0.92 + 0.08 * q; op = q
            } else if (t < 1600) {
              r = 0; x = 0; y = 0; s = 1; op = 1
            } else if (t < 3200) {
              // 12Hz micro-vibration (card still seated — peel starts at 3200)
              const j = JITTER[Math.floor((t * 12) / 1000) % 5]
              r = 0; x = j[0]; y = j[1]; s = 1; op = 1
            } else if (t < 4800) {
              // sticker peel: eased lift toward top-left + curl lean
              const k = easeInOut((t - 3200) / 1600)
              r = PEEL_R * k; x = PEEL_X * k; y = PEEL_Y * k
              s = 1 + (PEEL_S - 1) * k; op = 1; lean = PEEL_LEAN * k
            } else if (t < 6200) {
              // float: gentle bob over the revealed slot
              const bt = ((t - 4800) / 1400) * Math.PI * 2
              r = PEEL_R + Math.sin(bt + 0.7) * 1.5
              x = PEEL_X; y = PEEL_Y + Math.sin(bt) * 6
              s = PEEL_S; op = 1; lean = PEEL_LEAN
            } else if (t < 6500) {
              // crossfade out (lifted pose, fading)
              r = PEEL_R; x = PEEL_X; y = PEEL_Y; s = PEEL_S
              op = 1 - (t - 6200) / 300; lean = PEEL_LEAN
            } else {
              // crossfade in (seated pose, fading back)
              r = 0; x = 0; y = 0; s = 1
              op = (t - 6500) / 500; lean = 0
            }
            lastR = r; lastX = x; lastY = y; lastS = s
            // card carries 1.5x tilt (1x inherited from #Grid + 0.5x own) + peel lean
            const brx = tilt.x * 0.5 + lean
            const bry = tilt.y * 0.5
            card.style.transform = poseTf(r, x, y, s, brx, bry)
            card.style.opacity = String(Math.min(Math.max(op, 0), 1))
            const hot = t >= 3200 && t < 6500
            const wantShadow = hot
              ? 'drop-shadow(18px 24px 28px rgba(0,0,0,0.85))'
              : 'drop-shadow(0 4px 10px rgba(0,0,0,0.5))'
            if (wantShadow !== lastShadow) {
              card.style.filter = wantShadow
              lastShadow = wantShadow
            }
            // gradient heat: cool neutral <-> glowing red (follower = gentle sweep)
            const heatTarget = t >= 1600 && t < 6200 ? STOP_HOT : STOP_COOL
            heat.c[0] += (heatTarget[0] - heat.c[0]) * 0.12
            heat.c[1] += (heatTarget[1] - heat.c[1]) * 0.12
            heat.c[2] += (heatTarget[2] - heat.c[2]) * 0.12
            if (stop2) {
              try { stop2.style.stopColor = `rgb(${Math.round(heat.c[0])}, ${Math.round(heat.c[1])}, ${Math.round(heat.c[2])})` } catch (e) {}
              // red saturation rises from the bottom edge, recedes on reset
              let off = 1
              if (t >= 1600 && t < 3200) off = 1 - 0.55 * easeOutCubic((t - 1600) / 1600)
              else if (t >= 3200 && t < 6200) off = 0.45
              else if (t >= 6200) off = 0.45 + 0.55 * easeInOut(Math.min((t - 6200) / 800, 1))
              try { stop2.setAttribute('offset', off.toFixed(3)) } catch (e) {}
            }
            // slot glow
            if (target) {
              try {
                target.style.strokeOpacity =
                  t >= 1600 && t < 3200 ? String(0.45 + 0.15 * Math.sin(t / 120)) : '0.15'
              } catch (e) {}
            }
            // terminal: type-on wipes + spotlight dimming (peeled = line 3 in focus)
            if (line1) {
              if (t < 200) line1.style.opacity = '0'
              else {
                line1.style.opacity = (t >= 3200 && t < 6200) ? '0.35' : '1'
                line1.style.clipPath = t < 800
                  ? `inset(0 ${(100 * (1 - (t - 200) / 600)).toFixed(1)}% 0 0)`
                  : 'none'
              }
            }
            if (line2) {
              if (t < 1600) line2.style.opacity = '0'
              else if (t < 6200) {
                line2.style.opacity = (t >= 3200) ? '0.35' : '1'
                line2.style.clipPath = t < 2100
                  ? `inset(0 ${(100 * (1 - (t - 1600) / 500)).toFixed(1)}% 0 0)`
                  : 'none'
              } else line2.style.opacity = '0'
            }
            if (line3) {
              if (t < 3200) line3.style.opacity = '0'
              else if (t < 6200) {
                line3.style.opacity = '1'
                line3.style.clipPath = t < 3600
                  ? `inset(0 ${(100 * (1 - (t - 3200) / 400)).toFixed(1)}% 0 0)`
                  : 'none'
              } else line3.style.opacity = '0'
            }
            // traveling caret: line ends while typing, home while peeled
            if (caret) {
              let dx = 0
              let show = false
              let fast = false
              if (t >= 100 && t < 900) { dx = caretDx1; show = true; fast = true }
              else if (t >= 1600 && t < 2200) { dx = caretDx2; show = true; fast = true }
              else if (t >= 3200 && t < 6200) { dx = 0; show = true; fast = false }
              caret.style.transform = `translate(${dx}px, 0px)`
              caret.style.opacity = !show ? '0' : ((t % (fast ? 500 : 1000)) < (fast ? 250 : 500) ? '1' : '0')
            }
            // connector arrow: dash-draw from the terminal, fade out on reset
            if (arrow) {
              if (t < 3200) {
                arrow.style.opacity = '0'
                if (arrowLen > 0) arrow.style.strokeDashoffset = String(arrowLen)
              } else if (t < 3700 && arrowLen > 0) {
                arrow.style.opacity = '1'
                arrow.style.strokeDashoffset = String(arrowLen * (1 - easeOutCubic((t - 3200) / 500)))
              } else if (t < 6200) {
                arrow.style.opacity = '1'
                if (arrowLen > 0) arrow.style.strokeDashoffset = '0'
              } else {
                arrow.style.opacity = '0'
              }
              const sc = t < 3200 ? 0.95 : 1
              arrow.style.transform = `scale(${sc})`
            }
          }
          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch((err) => {
        die('load failed (' + ((err && err.stack) || (err && err.message) || err) + ')')
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      removers.forEach((fn) => fn())
      if (ref.current) ref.current.innerHTML = ''
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Static fallback sits underneath; the animated inline SVG overlays it
  // and fades it out once live — the card is never a blank box.
  return (
    <div className="relative w-full" style={{ aspectRatio: '620 / 403' }} aria-hidden>
      <img
        ref={imgRef}
        src={boltedUrl}
        alt=""
        draggable={false}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', transition: 'opacity .4s ease' }}
      />
      <div ref={ref} className="absolute inset-0 w-full" />
    </div>
  )
}
