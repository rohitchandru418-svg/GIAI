import { useEffect, useRef } from 'react'
import chooseUrl from '../asset/Choose the right approach for each problem.svg'

/* ------------------------------------------------------------------
   Choose the right approach — continuous routing loop, in place.
   No redraw, no viewBox change. Only transforms / opacity / stroke
   on EXISTING nodes (+ clones of existing diamonds for continuity).

   Loop story (all seamless, free-running single clock):
     1. Green diamonds (Decoration_2..6) rain from the top tile down
        into the ROUTE card, staggered, fading as absorbed.
     2. ROUTE card pulses each time a diamond lands (stroke flash +
        scale pop); its share icon breathes/floats and flares on
        landing while the ROUTE text brightens as if receiving.
     3. Blue diamonds travel Vector 91 (ROUTE -> left -> down) into
        the INTELLIGENCE tile. Green diamonds travel Vector 92
        (ROUTE -> right -> down) into the RULES tile. Clones keep
        both lanes continuously populated.
     4. INTELLIGENCE / RULES tiles flash on each arrival; their icon
        clusters (slow rotate + staggered detail pulse) and text
        labels brighten with the arrival pulse.
     5. Faint dashed flow overlays on both connectors drift toward
        the destinations so direction reads even between diamonds.
------------------------------------------------------------------- */

const FALL_PERIOD = 2.4
const LEFT_PERIOD = 3.2
const RIGHT_PERIOD = 2.8
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

// L-shaped connector geometry (matches authored d attributes)
const LEFT = { x0: 242, y0: 182, x1: 61, y1: 182, x2: 61, y2: 364 }
const RIGHT = { x0: 363, y0: 182, x1: 424, y1: 182, x2: 424, y2: 364 }
const LEFT_H = Math.abs(LEFT.x1 - LEFT.x0)
const LEFT_V = Math.abs(LEFT.y2 - LEFT.y1)
const LEFT_LEN = LEFT_H + LEFT_V
const RIGHT_H = Math.abs(RIGHT.x1 - RIGHT.x0)
const RIGHT_V = Math.abs(RIGHT.y2 - RIGHT.y1)
const RIGHT_LEN = RIGHT_H + RIGHT_V

function leftPos(t) {
  const d = t * LEFT_LEN
  if (d < LEFT_H) {
    const k = d / LEFT_LEN
    void k
    return { x: LEFT.x0 + (LEFT.x1 - LEFT.x0) * (d / LEFT_H), y: LEFT.y0 }
  }
  return { x: LEFT.x1, y: LEFT.y1 + (d - LEFT_H) }
}

function rightPos(t) {
  const d = t * RIGHT_LEN
  if (d < RIGHT_H) {
    return { x: RIGHT.x0 + (RIGHT.x1 - RIGHT.x0) * (d / RIGHT_H), y: RIGHT.y0 }
  }
  return { x: RIGHT.x1, y: RIGHT.y1 + (d - RIGHT_H) }
}

export default function ChooseApproachLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(chooseUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const NS = 'http://www.w3.org/2000/svg'

        const routeCard = byId('Capability Card')
        const routeBg = byId('Card Background')
        const routeIcon = byId('Share-Link--Streamline-Flex')
        const routeIconInner = byId('share-link--share-transmit')
        const routeLabel = byId('Capability Name')
        const intelTile = byId('Intelligence Tile')
        const intelBg = byId('Tile')
        const intelIcon = byId('Icon')
        const intelLabel = byId('Label')
        const rulesCard = byId('Capability Card_2')
        const rulesBg = byId('Card Background_2')
        const rulesIcon = byId('Capability Icon')
        const rulesIconCore = byId('Capability Icon_2')
        const rulesLabel = byId('Capability Name_2')
        const intelDetails = ['Icon Detail', 'Icon Detail_2', 'Icon Detail_3', 'Icon Detail_4', 'Icon Detail_5']
          .map(byId)
          .filter(Boolean)
          .map((el, i) => {
            const v = parseFloat(el.getAttribute('opacity'))
            return { el, base: Number.isFinite(v) ? v : 1, i }
          })
        const wireL = byId('Vector 91')
        const wireR = byId('Vector 92')

        ;[routeCard, intelTile, rulesCard].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        ;[routeIcon, routeIconInner, intelIcon, rulesIcon, rulesIconCore].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        intelDetails.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        const routeLabelBase = routeLabel ? parseFloat(routeLabel.getAttribute('opacity')) || 0.56 : 0.56
        const intelLabelBase = intelLabel ? parseFloat(intelLabel.getAttribute('opacity')) || 0.56 : 0.56
        const rulesLabelBase = rulesLabel ? parseFloat(rulesLabel.getAttribute('opacity')) || 0.56 : 0.56
        const routeIconBase = 0.6
        /* ---- icon tint targets: landing flash colors the icons, not the borders ---- */
        const routeIconPaths = routeIconInner ? Array.from(routeIconInner.querySelectorAll('path')) : []
        const intelIconRect = intelIcon ? intelIcon.querySelector('rect') : null
        const intelDetailRects = intelDetails.flatMap(({ el }) => Array.from(el.querySelectorAll('rect')))
        const rulesIconRect = rulesIcon ? rulesIcon.querySelector('rect') : null
        const rulesCoreRect = rulesIconCore ? rulesIconCore.querySelector('rect') : null
        const mixWhite = (target, k) => {
          const c = Math.max(0, Math.min(1, k))
          const r = Math.round(255 + (target[0] - 255) * c)
          const g = Math.round(255 + (target[1] - 255) * c)
          const b = Math.round(255 + (target[2] - 255) * c)
          return 'rgb(' + r + ',' + g + ',' + b + ')'
        }
        const GREEN = [0, 212, 107]
        const BLUE = [59, 130, 246]

        if (REDUCED) return

        /* ---- 1. falling greens: lift out of the clipped top tile ---- */
        const fallIds = ['Decoration_2', 'Decoration_3', 'Decoration_4', 'Decoration_5', 'Decoration_6']
        const overlay = document.createElementNS(NS, 'g')
        overlay.setAttribute('id', 'choose-loop-overlay')
        svg.appendChild(overlay)

        const fallers = []
        fallIds.forEach((id, i) => {
          const el = byId(id)
          if (!el) return
          const wrap = document.createElementNS(NS, 'g')
          const parent = el.parentNode
          if (parent) parent.insertBefore(wrap, el)
          wrap.appendChild(el)
          overlay.appendChild(wrap)
          let baseOp = parseFloat(el.getAttribute('opacity'))
          if (!Number.isFinite(baseOp)) baseOp = 1
          fallers.push({ wrap, el, baseOp, off: i / fallIds.length, prev: 0 })
        })

        /* ---- 2 + 3. lane travellers: reuse + clone authored diamonds ---- */
        const blueA = byId('Decoration_8')
        const blueB = byId('Decoration_9')
        const greenA = byId('Decoration_10')

        const travellersL = []
        const travellersR = []

        const prepDiamond = (el) => {
          if (!el) return null
          el.removeAttribute('transform')
          return el
        }

        // Left lane: 3 blues circulating (2 authored + 1 clone)
        ;[blueA, blueB].forEach((el, i) => {
          const n = prepDiamond(el)
          if (!n) return
          if (n.parentNode !== overlay) {
            try {
              overlay.appendChild(n)
            } catch (e) {}
          }
          travellersL.push({ el: n, off: i / 3 })
        })
        if (blueA) {
          const c = blueA.cloneNode(true)
          c.removeAttribute('id')
          overlay.appendChild(c)
          travellersL.push({ el: c, off: 2 / 3 })
        }
        // Right lane: 3 greens circulating (1 authored + 2 clones)
        if (greenA) {
          const n = prepDiamond(greenA)
          if (n && n.parentNode !== overlay) {
            try {
              overlay.appendChild(n)
            } catch (e) {}
          }
          if (n) travellersR.push({ el: n, off: 0 })
          for (let k = 1; k < 3; k++) {
            const c = greenA.cloneNode(true)
            c.removeAttribute('id')
            overlay.appendChild(c)
            travellersR.push({ el: c, off: k / 3 })
          }
        }
        travellersL.forEach((o) => {
          o.el.setAttribute('fill', '#3B82F6')
          o.el.setAttribute('width', '6')
          o.el.setAttribute('height', '6')
          o.prev = 0
        })
        travellersR.forEach((o) => {
          o.el.setAttribute('fill', '#00D46B')
          o.el.setAttribute('width', '6')
          o.el.setAttribute('height', '6')
          o.prev = 0
        })

        /* ---- flow overlays so direction reads between diamonds ---- */
        const mkFlow = (src, color) => {
          if (!src) return null
          try {
            const p = document.createElementNS(NS, 'path')
            p.setAttribute('d', src.getAttribute('d') || '')
            p.setAttribute('fill', 'none')
            p.setAttribute('stroke', color)
            p.setAttribute('stroke-width', '1.4')
            p.setAttribute('stroke-dasharray', '5 9')
            p.setAttribute('stroke-linecap', 'round')
            p.setAttribute('opacity', '0.4')
            p.setAttribute('pointer-events', 'none')
            overlay.appendChild(p)
            return p
          } catch (e) {
            return null
          }
        }
        const flowL = mkFlow(wireL, '#3B82F6')
        const flowR = mkFlow(wireR, '#00D46B')

        let routePulse = 0
        let intelPulse = 0
        let rulesPulse = 0
        let dashL = 0
        let dashR = 0
        let last = performance.now()
        const t0 = last

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const t = (now - t0) / 1000

          /* falling greens -> ROUTE */
          fallers.forEach((f) => {
            const ph = ((t / FALL_PERIOD + f.off) % 1 + 1) % 1
            if (ph < f.prev && f.prev - ph > 0.5) routePulse = Math.min(routePulse + 0.9, 1.5)
            f.prev = ph
            const dy = -70 + ph * 175
            f.wrap.setAttribute('transform', 'translate(0 ' + dy.toFixed(1) + ')')
            let op = f.baseOp
            if (ph < 0.14) op *= ph / 0.14
            else if (ph > 0.72) op *= Math.max(0, 1 - (ph - 0.72) / 0.28)
            f.el.setAttribute('opacity', op.toFixed(3))
          })

          /* left lane blues -> INTELLIGENCE */
          travellersL.forEach((o) => {
            const ph = ((t / LEFT_PERIOD + o.off) % 1 + 1) % 1
            if (ph < o.prev && o.prev - ph > 0.5) intelPulse = Math.min(intelPulse + 1, 1.5)
            o.prev = ph
            const p = leftPos(ph)
            o.el.setAttribute('x', p.x.toFixed(1))
            o.el.setAttribute('y', p.y.toFixed(1))
            o.el.setAttribute('transform', 'rotate(45 ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ')')
            let op = 1
            if (ph < 0.08) op = ph / 0.08
            else if (ph > 0.86) op = Math.max(0, 1 - (ph - 0.86) / 0.14)
            o.el.setAttribute('opacity', (0.35 + 0.65 * op).toFixed(3))
          })

          /* right lane greens -> RULES */
          travellersR.forEach((o) => {
            const ph = ((t / RIGHT_PERIOD + o.off) % 1 + 1) % 1
            if (ph < o.prev && o.prev - ph > 0.5) rulesPulse = Math.min(rulesPulse + 1, 1.5)
            o.prev = ph
            const p = rightPos(ph)
            o.el.setAttribute('x', p.x.toFixed(1))
            o.el.setAttribute('y', p.y.toFixed(1))
            o.el.setAttribute('transform', 'rotate(45 ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ')')
            let op = 1
            if (ph < 0.08) op = ph / 0.08
            else if (ph > 0.86) op = Math.max(0, 1 - (ph - 0.86) / 0.14)
            o.el.setAttribute('opacity', (0.35 + 0.65 * op).toFixed(3))
          })

          /* connector drift */
          dashL -= dt * 26
          dashR -= dt * 26
          if (flowL) flowL.setAttribute('stroke-dashoffset', dashL.toFixed(1))
          if (flowR) flowR.setAttribute('stroke-dashoffset', dashR.toFixed(1))
          if (wireL) wireL.setAttribute('opacity', (0.2 + 0.1 * (0.5 + 0.5 * Math.sin(t * 2.2))).toFixed(3))
          if (wireR) wireR.setAttribute('opacity', (0.2 + 0.1 * (0.5 + 0.5 * Math.sin(t * 2.2 + 1.4))).toFixed(3))

          /* pulses decay */
          routePulse *= Math.pow(0.06, dt)
          intelPulse *= Math.pow(0.06, dt)
          rulesPulse *= Math.pow(0.06, dt)

          /* soft tile breathing — borders stay untouched */
          if (routeCard) {
            const s = 1 + Math.min(routePulse, 1) * 0.012 + Math.sin(t * 2.4) * 0.003
            routeCard.style.transform = 'scale(' + s.toFixed(4) + ')'
          }
          if (routeIcon) {
            // breathing float + soft landing lift; inner group counter-rotates gently
            const breathe = Math.sin(t * 2.1) * 0.02
            const pop = Math.min(routePulse, 1) * 0.05
            routeIcon.style.transform =
              'scale(' + (1 + breathe + pop).toFixed(3) + ') rotate(' + (Math.sin(t * 1.4) * 3).toFixed(2) + 'deg)'
            routeIcon.setAttribute('opacity', Math.min(1, routeIconBase + breathe * 0.6 + Math.min(routePulse, 1) * 0.18).toFixed(3))
          }
          if (routeIconInner) {
            routeIconInner.style.transform = 'rotate(' + (Math.sin(t * 1.7 + 0.6) * 5).toFixed(2) + 'deg)'
          }
          // landing tint: ROUTE share icon strokes white -> green
          if (routeIconPaths.length) {
            const col = mixWhite(GREEN, Math.min(routePulse, 1) * 0.9)
            routeIconPaths.forEach((p) => {
              try {
                p.setAttribute('stroke', col)
              } catch (e) {}
            })
          }
          if (routeLabel) {
            // text brightens softly as diamonds land, then settles — reads as "receiving"
            const glow = Math.min(routePulse, 1) * 0.18 + (0.5 + 0.5 * Math.sin(t * 2.1)) * 0.06
            routeLabel.setAttribute('opacity', Math.min(1, routeLabelBase + glow).toFixed(3))
          }
          /* ---- INTELLIGENCE icon cluster + label ---- */
          if (intelIcon) {
            intelIcon.style.transform =
              'rotate(' + (t * 12 % 360).toFixed(1) + 'deg) scale(' + (1 + Math.sin(t * 2.4) * 0.025 + Math.min(intelPulse, 1) * 0.04).toFixed(3) + ')'
            intelIcon.setAttribute('opacity', Math.min(1, 0.1 + Math.min(intelPulse, 1) * 0.25 + (0.5 + 0.5 * Math.sin(t * 2.4)) * 0.05).toFixed(3))
          }
          if (intelIconRect) {
            try {
              intelIconRect.setAttribute('stroke', mixWhite(BLUE, Math.min(intelPulse, 1) * 0.9))
            } catch (e) {}
          }
          intelDetails.forEach(({ el, base, i }) => {
            const w = 0.5 + 0.5 * Math.sin(t * 2.6 + i * 1.1)
            el.style.transform = 'scale(' + (1 + w * 0.1 + Math.min(intelPulse, 1) * 0.08).toFixed(3) + ')'
            el.setAttribute('opacity', Math.min(1, base * (0.85 + w * 0.3) + Math.min(intelPulse, 1) * 0.15).toFixed(3))
          })
          if (intelDetailRects.length) {
            const col = mixWhite(BLUE, Math.min(intelPulse, 1) * 0.9)
            intelDetailRects.forEach((r) => {
              try {
                r.setAttribute('fill', col)
              } catch (e) {}
            })
          }
          if (intelLabel) {
            const glow = (0.5 + 0.5 * Math.sin(t * 2.6 + 0.8)) * 0.07 + Math.min(intelPulse, 1) * 0.18
            intelLabel.setAttribute('opacity', Math.min(1, intelLabelBase + glow).toFixed(3))
          }
          /* ---- RULES icon cluster + label ---- */
          if (rulesIcon) {
            rulesIcon.style.transform =
              'rotate(' + (-(t * 10 % 360)).toFixed(1) + 'deg) scale(' + (1 + Math.sin(t * 2.2 + 1) * 0.025 + Math.min(rulesPulse, 1) * 0.04).toFixed(3) + ')'
            rulesIcon.setAttribute('opacity', Math.min(1, 0.1 + Math.min(rulesPulse, 1) * 0.25 + (0.5 + 0.5 * Math.sin(t * 2.2 + 1)) * 0.05).toFixed(3))
          }
          if (rulesIconRect) {
            try {
              rulesIconRect.setAttribute('stroke', mixWhite(GREEN, Math.min(rulesPulse, 1) * 0.9))
            } catch (e) {}
          }
          if (rulesIconCore) {
            const w = 0.5 + 0.5 * Math.sin(t * 2.8)
            rulesIconCore.style.transform = 'scale(' + (1 + w * 0.09 + Math.min(rulesPulse, 1) * 0.08).toFixed(3) + ')'
            rulesIconCore.setAttribute('opacity', Math.min(1, 0.32 * (0.85 + w * 0.3) + Math.min(rulesPulse, 1) * 0.18).toFixed(3))
          }
          if (rulesCoreRect) {
            try {
              rulesCoreRect.setAttribute('fill', mixWhite(GREEN, Math.min(rulesPulse, 1) * 0.9))
            } catch (e) {}
          }
          if (rulesLabel) {
            const glow = (0.5 + 0.5 * Math.sin(t * 2.6 + 2)) * 0.07 + Math.min(rulesPulse, 1) * 0.18
            rulesLabel.setAttribute('opacity', Math.min(1, rulesLabelBase + glow).toFixed(3))
          }
          if (intelTile) {
            const s = 1 + Math.min(intelPulse, 1) * 0.012
            intelTile.style.transform = 'scale(' + s.toFixed(4) + ')'
          }
          if (rulesCard) {
            const s = 1 + Math.min(rulesPulse, 1) * 0.012
            rulesCard.style.transform = 'scale(' + s.toFixed(4) + ')'
          }

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = chooseUrl
        img.alt = 'Choose the right approach for each problem'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
