import { useEffect, useRef } from 'react'
import governUrl from '../asset/Govern.svg'

/* ------------------------------------------------------------------
   Govern — oversight-to-trace flow, in place. No redraw, no viewBox
   change. Only transforms / opacity / stroke / fill on EXISTING nodes
   (+ clones of the authored audit check).

   Loop story (single clock — borders tint green here by request):
     1. The green featured tile flows diagonally bottom-left
        (OVERSIGHT) -> top-right (TRACE) on a 6s loop, fading out at
        the end and back in at the start to hide the wrap.
     2. The diagonal runs through the Feedback card centers, so each
        card lights up as green passes over it (border tints green —
        audit normalized to dark at idle — plus soft lift, label
        brighten, icon tints white->green).
     3. Each passed card earns its check badge, latched by proximity
        so even the last trace stop reads clearly: the audit tile's
        own check plus clones on the oversight, access and trace
        tiles pop in and stay on until the cycle resets.
------------------------------------------------------------------- */

const GREEN = [0, 212, 107]
const mixWhite = (target, k) => {
  const c = Math.max(0, Math.min(1, k))
  const r = Math.round(255 + (target[0] - 255) * c)
  const g = Math.round(255 + (target[1] - 255) * c)
  const b = Math.round(255 + (target[2] - 255) * c)
  return 'rgb(' + r + ',' + g + ',' + b + ')'
}
const FLOW_PERIOD = 6
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

// diagonal: green-center (60,425) -> (425,60), through every card center
const greenCenter = (t) => ({ x: 60 + 365 * t, y: 425 - 365 * t })

// stops in flow order: oversight -> audit -> access -> trace.
// The diagonal runs through every Feedback center.
const STOPS = [
  { tile: 'Feedback_4', bg: 'Tile Background_13', icon: 0, label: 4, cx: 61, cy: 424, badgeAt: [101.5, 383], latchAt: 0.5 },
  { tile: 'Feedback_3', bg: 'Tile Background_10', icon: 1, label: 3, cx: 182, cy: 303, badgeAt: null, latchAt: 0.5, normalizeBorder: true }, // uses authored Audit Status
  { tile: 'Feedback_2', bg: 'Tile Background_7', icon: 2, label: 2, cx: 303, cy: 182, badgeAt: [343.5, 141], latchAt: 0.5 },
  { tile: 'Feedback', bg: 'Tile Background_4', icon: 3, label: 0, cx: 424, cy: 61, badgeAt: [464.5, 20], latchAt: 0.5 },
]

export default function GovernLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(governUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const NS = 'http://www.w3.org/2000/svg'

        const featured = byId('Featured Capability')
        const audit = byId('Audit Status')
        const overlay = document.createElementNS(NS, 'g')
        overlay.setAttribute('id', 'govern-loop-overlay')
        svg.appendChild(overlay)

        const tiles = STOPS.map((s) => {
          const el = byId(s.tile)
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
          const bg = byId(s.bg)
          // audit tile is authored green — normalize it to the dark idle
          // border so it only lights green while the flow passes over it
          const bgStroke = s.normalizeBorder ? '#2D2D2D' : (bg ? bg.getAttribute('stroke') || '#2D2D2D' : '#2D2D2D')
          if (s.normalizeBorder && bg) {
            try {
              bg.setAttribute('stroke', bgStroke)
            } catch (e) {}
          }
          return { ...s, el, bg, bgStroke, prox: 0 }
        })

        const labelIds = ['Label', 'Label_2', 'Label_3', 'Label_4', 'Label_5']
        const labels = labelIds.map(byId).filter(Boolean).map((el) => {
          const v = parseFloat(el.getAttribute('opacity'))
          return { el, base: Number.isFinite(v) ? v : 0.56 }
        })

        const iconGroups = [
          byId('Visual-Blind-1--Streamline-Flex'),
          byId('Sound-Recognition-Search--Streamline-Flex'),
          byId('One-Finger-Tap--Streamline-Flex'),
          byId('Page-Setting--Streamline-Flex'),
        ]
        iconGroups.forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })

        if (REDUCED) return

        /* ---- check badges: one node each, position + pop composed ----
           Authored audit node is reused for its tile; clones serve the
           other three. Everything (position + pop scale) is composed in
           a single transform ATTRIBUTE around the badge home point —
           no CSS transforms, no fill-box, nothing to silently override. */
        const HOME = { x: 223, y: 262 } // authored Audit Status center
        const badges = []
        tiles.forEach((s) => {
          if (s.badgeAt === null && audit) {
            badges.push({ node: audit, bx: HOME.x, by: HOME.y })
          } else if (s.badgeAt && audit) {
            const holder = document.createElementNS(NS, 'g')
            const clone = audit.cloneNode(true)
            clone.removeAttribute('id')
            try {
              clone.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'))
            } catch (e) {}
            holder.appendChild(clone)
            overlay.appendChild(holder)
            badges.push({ node: holder, bx: s.badgeAt[0], by: s.badgeAt[1] })
          } else {
            badges.push({ node: null })
          }
        })
        const badgeTf = (b, k) =>
          'translate(' + b.bx.toFixed(1) + ',' + b.by.toFixed(1) + ') scale(' + Math.max(0.01, k).toFixed(3) + ') translate(' + (-HOME.x).toFixed(1) + ',' + (-HOME.y).toFixed(1) + ')'
        badges.forEach((b) => {
          if (!b.node) return
          try {
            b.node.setAttribute('transform', badgeTf(b, 0))
            b.node.setAttribute('opacity', '0')
          } catch (e) {}
        })

        let last = performance.now()
        const t0 = last
        let prevCyc = 0
        const latched = tiles.map(() => false)
        const latchT = tiles.map(() => 0)

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const t = (now - t0) / 1000
          const cyc = (((t / FLOW_PERIOD) % 1) + 1) % 1
          if (cyc < prevCyc - 0.5) {
            for (let li = 0; li < latched.length; li++) latched[li] = false
          }
          prevCyc = cyc

          /* green diagonal flow, fading at both ends to hide the wrap */
          const g = greenCenter(cyc)
          if (featured) {
            featured.setAttribute('x', (g.x - 50).toFixed(1))
            featured.setAttribute('y', (g.y - 50).toFixed(1))
            let fop = 1
            if (cyc > 0.9) fop = Math.max(0, 1 - (cyc - 0.9) / 0.1)
            else if (cyc < 0.08) fop = cyc / 0.08
            featured.setAttribute('opacity', (fop * 0.92).toFixed(3))
          }
          /* per-tile proximity glow as the green passes over (latches checks) */
          tiles.forEach((s, i) => {
            const d = Math.hypot(g.x - s.cx, g.y - s.cy)
            const prox = Math.max(0, 1 - d / 150)
            s.prox = prox
            if (!latched[i] && prox > s.latchAt) {
              latched[i] = true
              latchT[i] = t
            }
            if (s.el) s.el.style.transform = 'scale(' + (1 + prox * 0.012).toFixed(4) + ')'
            if (s.bg) {
              try {
                s.bg.setAttribute('stroke', prox > 0.4 ? '#00D46B' : s.bgStroke)
              } catch (e) {}
            }
            const icon = s.icon >= 0 ? iconGroups[s.icon] : null
            if (icon) {
              icon.style.transform = 'scale(' + (1 + Math.sin(t * 2.1 + i * 1.3) * 0.025 + prox * 0.05).toFixed(3) + ')'
              icon.setAttribute('opacity', Math.min(1, 0.6 + prox * 0.35).toFixed(3))
              try {
                icon.querySelectorAll('path').forEach((p) => p.setAttribute('stroke', mixWhite(GREEN, prox * 0.85)))
              } catch (e) {}
            }
          })
          labels.forEach(({ el, base }, i) => {
            const s = tiles.find((q) => q.label === i)
            const d = s ? Math.hypot(g.x - s.cx, g.y - s.cy) : 999
            const prox = Math.max(0, 1 - d / 150)
            el.setAttribute('opacity', Math.min(1, base + prox * 0.18 + (0.5 + 0.5 * Math.sin(t * 2.2 + i)) * 0.06).toFixed(3))
          })

          /* completion checks: pop in once latched, hold, reset at wrap */
          let resetFade = 1
          if (cyc > 0.95) resetFade = Math.max(0, 1 - (cyc - 0.95) / 0.05)
          tiles.forEach((s, i) => {
            const b = badges[i]
            if (!b || !b.node) return
            let k = 0
            if (latched[i]) {
              const q = Math.min((t - latchT[i]) / 0.35, 1)
              k = 1 - Math.pow(1 - q, 3)
            }
            try {
              b.node.setAttribute('transform', badgeTf(b, k))
              b.node.setAttribute('opacity', (k * resetFade).toFixed(3))
            } catch (e) {}
          })

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = governUrl
        img.alt = 'Govern'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
