import { useEffect, useRef } from 'react'

/* ------------------------------------------------------------------
   HarnessLoop — the How-We-Build intro visual, in the house tile-mosaic
   language (485 canvas, ghost tile field, capability cards, diamond
   packets, status checks). It stages the agentic retry-loop:

     CONTEXT -> MODEL REASONING -> SELF-CHECK -+-> OUTCOME (pass: the
                                                |  diamond turns green)
                                                +-> TOOLS -> CONTEXT (fail:
                                                resolve and try again)

   Pass/fail is drawn per attempt (~65% pass) so both branches read over
   time. Continuous loop, soft pulses (icons tint, borders stay authored
   except event flashes).

   Hand-authored inline SVG: structure is static JSX, motion runs on
   EXISTING nodes via one rAF clock + imperatively created packet
   diamonds in an overlay group.
------------------------------------------------------------------- */

const GREEN = '#00D46B'
const PASS_PROB = 0.65
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

// stage windows inside one attempt (seconds); fail attempts run longer
const FEED_END = 1.6
const REASON_END = 3.0
const PASS_END = 4.8
const FAIL_MID = 4.9
const FAIL_END = 5.7
const HOLD = 0.6

const CONTEXT = { x: 130, y: 25, w: 110, h: 100, cx: 185, cy: 75 }
const TOOLS = { x: 255, y: 25, w: 110, h: 100, cx: 310, cy: 75 }
const MODEL = { x: 30, y: 185, w: 120, h: 130, cx: 90, cy: 250 }
const SELF = { x: 130, y: 345, w: 110, h: 100, cx: 185, cy: 395 }
const OUTCOME = { x: 340, y: 185, w: 120, h: 130, cx: 400, cy: 250 }
const OUTCHECK = { x: 450, y: 195 }

const R1 = [[185, 125], [185, 185], [90, 185]] // context -> model
const R2 = [[150, 250], [165, 250], [165, 345], [185, 345]] // model -> self-check
const R3 = [[240, 395], [300, 395], [300, 250], [340, 250]] // self-check -> outcome (pass)
const R4 = [[240, 370], [285, 370], [285, 125], [310, 125]] // self-check -> tools (fail)
const R5 = [[240, 75], [255, 75]] // tools -> context (retry hop)
const ELBOWS = [
  { x: 185, y: 185, r3: false },
  { x: 165, y: 250, r3: false },
  { x: 165, y: 345, r3: false },
  { x: 300, y: 395, r3: true },
  { x: 300, y: 250, r3: true },
  { x: 285, y: 370, r3: false },
  { x: 285, y: 125, r3: false },
]

// arc-length follower over waypoint polyline
const follower = (pts) => {
  const segs = [0]
  let total = 0
  for (let i = 1; i < pts.length; i++) {
    total += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
    segs.push(total)
  }
  return (t) => {
    if (total <= 0) return { x: pts[0][0], y: pts[0][1] }
    let d = (((t % 1) + 1) % 1) * total
    for (let i = 1; i < pts.length; i++) {
      if (d <= segs[i]) {
        const span = segs[i] - segs[i - 1] || 1
        const k = (d - segs[i - 1]) / span
        return { x: pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * k, y: pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * k }
      }
    }
    const l = pts[pts.length - 1]
    return { x: l[0], y: l[1] }
  }
}

const mixWhite = (target, k) => {
  const c = Math.max(0, Math.min(1, k))
  const r = Math.round(255 + (target[0] - 255) * c)
  const g = Math.round(255 + (target[1] - 255) * c)
  const b = Math.round(255 + (target[2] - 255) * c)
  return 'rgb(' + r + ',' + g + ',' + b + ')'
}

export default function HarnessLoop() {
  const ref = useRef(null)

  useEffect(() => {
    if (!ref.current) return
    const svg = ref.current.querySelector('svg')
    if (!svg) return
    const byId = (id) => {
      try {
        return svg.querySelector('[id="' + id + '"]')
      } catch (e) {
        return null
      }
    }
    const NS = 'http://www.w3.org/2000/svg'

    const model = byId('h-model')
    const core = byId('h-core')
    const modelBg = byId('h-model-bg')
    const modelLabel = byId('h-model-label')
    const net = byId('h-net')
    const selfCard = byId('h-self')
    const selfBg = byId('h-self-bg')
    const selfLabel = byId('h-self-label')
    const toolsCard = byId('h-tools')
    const toolsBg = byId('h-tools-bg')
    const toolsLabel = byId('h-tools-label')
    const contextLabel = byId('h-context-label')
    const outcomeCard = byId('h-outcome')
    const outcomeBg = byId('h-outcome-bg')
    const outcomeLabel = byId('h-outcome-label')
    const seal = byId('h-seal')
    const outBadge = byId('h-outcheck')
    const lanes = [0, 1, 2, 3, 4].map((i) => byId('h-lane-' + i))
    const elbowEls = ELBOWS.map((_, i) => byId('h-elb-' + i))
    const elbows = ELBOWS.map((_, i) => byId('h-elb-' + i))

    ;[model, core, selfCard, outcomeCard, toolsCard].forEach((el) => {
      if (el) {
        el.style.transformBox = 'fill-box'
        el.style.transformOrigin = 'center'
      }
    })
    if (outBadge) {
      outBadge.style.transformBox = 'fill-box'
      outBadge.style.transformOrigin = 'center'
    }

    if (REDUCED) return
    let alive = true
    let raf = 0

    const overlay = document.createElementNS(NS, 'g')
    overlay.setAttribute('id', 'harness-packets')
    svg.appendChild(overlay)

    const mkPacket = (size) => {
      const r = document.createElementNS(NS, 'rect')
      r.setAttribute('width', String(size))
      r.setAttribute('height', String(size))
      r.setAttribute('fill', 'white')
      r.setAttribute('opacity', '0')
      overlay.appendChild(r)
      return r
    }
    const f1 = follower(R1)
    const f2 = follower(R2)
    const f3 = follower(R3)
    const f4 = follower(R4)
    const f5 = follower(R5)
    const pktA = mkPacket(5)
    const pktB = mkPacket(5)
    const pktC = mkPacket(6)

    const place = (el, p, op) => {
      el.setAttribute('x', p.x.toFixed(1))
      el.setAttribute('y', p.y.toFixed(1))
      el.setAttribute('transform', 'rotate(45 ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ')')
      el.setAttribute('opacity', op.toFixed(3))
    }
    const fadeEnds = (ph) => {
      if (ph < 0.08) return ph / 0.08
      if (ph > 0.86) return Math.max(0, 1 - (ph - 0.86) / 0.14)
      return 1
    }

    let cycleStart = 0
    let decided = false
    let verdict = true
    let arrivedA = false
    let arrivedC = false
    let arrivedT = false
    let wobbled = false
    let modelPulse = 0
    let toolsPulse = 0
    let outcomeHeat = 0
    let badgeS = 0.01
    let last = performance.now()
    const t0 = last

    const frame = (now) => {
      if (!alive) return
      const dt = Math.min((now - last) / 1000, 0.05)
      last = now
      const t = (now - t0) / 1000
      const ct = t - cycleStart
      const passLen = PASS_END + HOLD
      const failLen = FAIL_END + HOLD

      /* verdict lands at the end of reasoning */
      if (!decided && ct >= REASON_END) {
        decided = true
        verdict = Math.random() < PASS_PROB
        if (!verdict && !wobbled) {
          wobbled = true
          try {
            if (selfCard) {
              selfCard.animate(
                [{ transform: 'rotate(0deg)' }, { transform: 'rotate(-4deg)' }, { transform: 'rotate(4deg)' }, { transform: 'rotate(0deg)' }],
                { duration: 450, easing: 'ease-in-out' }
              ).finished.catch(() => {})
            }
          } catch (e) {}
        }
      }

      /* feeder packet: context -> model */
      if (ct >= 0 && ct < FEED_END) {
        const ph = ct / FEED_END
        place(pktA, f1(ph), 0.25 + 0.7 * fadeEnds(ph))
      } else {
        pktA.setAttribute('opacity', '0')
      }
      if (!arrivedA && ct >= FEED_END) {
        arrivedA = true
        modelPulse = Math.min(modelPulse + 1.2, 1.5)
      }

      /* reasoning packet: model -> self-check */
      const selfHot = ct >= FEED_END && ct < REASON_END
      if (selfHot) {
        const ph = (ct - FEED_END) / (REASON_END - FEED_END)
        place(pktB, f2(ph), 0.25 + 0.7 * fadeEnds(ph))
      } else {
        pktB.setAttribute('opacity', '0')
      }

      /* outcome packet: green on pass, white reroute on fail */
      let passActive = false
      if (decided && verdict && ct >= REASON_END && ct < PASS_END) {
        passActive = true
        const ph = (ct - REASON_END) / (PASS_END - REASON_END)
        pktC.setAttribute('fill', GREEN)
        place(pktC, f3(ph), 0.3 + 0.7 * fadeEnds(ph))
      } else if (decided && !verdict && ct >= REASON_END && ct < FAIL_MID) {
        const ph = (ct - REASON_END) / (FAIL_MID - REASON_END)
        pktC.setAttribute('fill', 'white')
        place(pktC, f4(ph), 0.3 + 0.7 * fadeEnds(ph))
      } else if (decided && !verdict && ct >= FAIL_MID && ct < FAIL_END) {
        const ph = (ct - FAIL_MID) / (FAIL_END - FAIL_MID)
        pktC.setAttribute('fill', 'white')
        place(pktC, f5(ph), 0.3 + 0.7 * fadeEnds(ph))
      } else {
        pktC.setAttribute('opacity', '0')
      }
      if (decided && verdict && !arrivedC && ct >= PASS_END) {
        arrivedC = true
        outcomeHeat = 1
      }
      if (decided && !verdict && !arrivedT && ct >= FAIL_END) {
        arrivedT = true
        toolsPulse = Math.min(toolsPulse + 1.2, 1.5)
      }

      /* cycle reset */
      const endLen = !decided ? failLen : verdict ? passLen : failLen
      if (ct >= endLen) {
        cycleStart = t
        decided = false
        arrivedA = false
        arrivedC = false
        arrivedT = false
        wobbled = false
      }

      /* pulses decay */
      modelPulse *= Math.pow(0.06, dt)
      toolsPulse *= Math.pow(0.06, dt)
      outcomeHeat *= Math.pow(0.45, dt)
      const mp = Math.min(modelPulse, 1)
      const tp = Math.min(toolsPulse, 1)
      const heat = Math.min(outcomeHeat, 1)

      if (model) {
        model.style.transform = 'scale(' + (1 + mp * 0.03 + Math.sin(t * 2.2) * 0.004).toFixed(4) + ')'
      }
      if (modelBg) {
        try {
          modelBg.setAttribute('stroke', mp > 0.25 ? GREEN : '#464646')
        } catch (e) {}
      }
      if (core) {
        core.style.transform = 'rotate(' + (45 + ((t * 18) % 360)).toFixed(1) + 'deg)'
      }
      if (net) {
        try {
          net.setAttribute('stroke', mixWhite(GREEN, 0.15 + mp * 0.7))
        } catch (e) {}
      }
      if (modelLabel) {
        modelLabel.setAttribute('opacity', (0.56 + mp * 0.3 + (0.5 + 0.5 * Math.sin(t * 2.2)) * 0.08).toFixed(3))
      }
      if (selfBg) {
        try {
          selfBg.setAttribute('stroke', selfHot ? '#d9d9e0' : '#2D2D2D')
        } catch (e) {}
      }
      if (selfLabel) {
        selfLabel.setAttribute('opacity', (0.56 + (selfHot ? 0.25 : 0) + (0.5 + 0.5 * Math.sin(t * 2.6)) * 0.06).toFixed(3))
      }
      if (toolsBg) {
        try {
          toolsBg.setAttribute('stroke', tp > 0.25 ? GREEN : '#2D2D2D')
        } catch (e) {}
      }
      if (toolsLabel) {
        toolsLabel.setAttribute('opacity', (0.56 + tp * 0.3).toFixed(3))
      }
      if (outcomeBg) {
        try {
          outcomeBg.setAttribute('stroke', heat > 0.3 ? GREEN : '#2D2D2D')
        } catch (e) {}
      }
      if (outcomeCard) {
        outcomeCard.style.filter = heat > 0.03 ? 'drop-shadow(0 0 ' + (18 * heat).toFixed(1) + 'px rgba(0,212,107,' + (0.35 * heat).toFixed(3) + '))' : ''
      }
      if (seal) {
        try {
          seal.setAttribute('stroke', mixWhite(GREEN, heat * 0.9))
        } catch (e) {}
      }
      if (outcomeLabel) {
        outcomeLabel.setAttribute('opacity', (0.56 + heat * 0.3).toFixed(3))
      }
      if (outBadge) {
        badgeS += ((heat > 0.35 ? 1 : 0.01) - badgeS) * Math.min(1, dt * 7)
        outBadge.style.transform = 'scale(' + badgeS.toFixed(3) + ')'
        outBadge.setAttribute('opacity', Math.min(1, badgeS).toFixed(3))
      }
      elbowEls.forEach((el, i) => {
        if (!el) return
        const isR3 = ELBOWS[i].r3
        try {
          el.setAttribute('fill', isR3 && passActive ? GREEN : 'white')
          el.setAttribute('opacity', isR3 && passActive ? '0.9' : '0.4')
        } catch (e) {}
      });
      (function labels() {
        if (contextLabel) contextLabel.setAttribute('opacity', (0.56 + (0.5 + 0.5 * Math.sin(t * 2.1)) * 0.06).toFixed(3))
      })()

      /* lane dash drift */
      dashRef.v -= dt * 22
      lanes.forEach((l) => {
        if (l) l.setAttribute('stroke-dashoffset', dashRef.v.toFixed(1))
      })

      raf = requestAnimationFrame(frame)
    }

    const dashRef = { v: 0 }
    raf = requestAnimationFrame(frame)

    return () => {
      alive = false
      cancelAnimationFrame(raf)
    }
  }, [])

  const label = { fontFamily: "'Space Grotesk',sans-serif", letterSpacing: 2 }
  return (
    <div ref={ref} className="flex items-center justify-center" aria-hidden>
      <svg viewBox="0 0 485 485" style={{ height: 330, width: 'auto', maxWidth: '100%', display: 'block', overflow: 'visible' }} aria-hidden="true">
        {/* ghost tile field */}
        {Array.from({ length: 16 }, (_, i) => {
          const gx = 2 + (i % 4) * 121
          const gy = 2 + Math.floor(i / 4) * 121
          return <rect key={i} x={gx} y={gy} width="117" height="117" rx="6" fill="black" stroke="#151515" />
        })}
        {/* intersection diamonds (two greens twinkle in the loop) */}
        {[[123, 123, 0], [244, 123, 0], [365, 123, 0], [123, 244, 0], [365, 200, 1], [60, 300, 1], [244, 365, 0], [365, 365, 0], [123, 365, 0], [244, 420, 0]].map(([x, y, g], i) => (
          <rect key={'tw' + i} id={'h-tw-' + i} x={x - 2} y={y - 2} width="4" height="4" transform={`rotate(45 ${x} ${y})`} fill={g ? GREEN : 'white'} opacity={g ? 0.4 : 0.14} />
        ))}
        {/* feeder + loop lanes */}
        {[[R1], [R2], [R3], [R4], [R5]].map((r, i) => (
          <path key={'lane' + i} id={'h-lane-' + i} d={'M' + r[0].map((p) => p.join(' ')).join(' L')} fill="none" stroke="white" strokeOpacity="0.2" strokeWidth="1.2" strokeDasharray="4 7" />
        ))}
        {/* elbow diamonds */}
        {ELBOWS.map((e, i) => (
          <rect key={'elb' + i} id={'h-elb-' + i} x={e.x - 2.5} y={e.y - 2.5} width="5" height="5" transform={`rotate(45 ${e.x} ${e.y})`} fill="white" opacity="0.4" />
        ))}
        {/* context card */}
        <g id="h-context">
          <rect x={CONTEXT.x} y={CONTEXT.y} width={CONTEXT.w} height={CONTEXT.h} rx="18" fill="black" stroke="#2D2D2D" />
          <g stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <rect x="177" y="53" width="16" height="20" rx="1.5" />
            <path d="M189 53 L193 57 H189 Z" />
            <path d="M180 61 H190 M180 65 H190 M180 69 H187" />
          </g>
          <text id="h-context-label" x={CONTEXT.cx} y={CONTEXT.y + CONTEXT.h - 12} textAnchor="middle" fontSize="10" fill="white" opacity="0.56" style={label}>CONTEXT</text>
        </g>
        {/* tools card */}
        <g id="h-tools">
          <rect id="h-tools-bg" x={TOOLS.x} y={TOOLS.y} width={TOOLS.w} height={TOOLS.h} rx="18" fill="black" stroke="#2D2D2D" />
          <g stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round">
            <path d="M300 62 H320 M300 68 H320 M300 74 H320" />
            <circle cx="306" cy="62" r="2.5" fill="black" />
            <circle cx="314" cy="68" r="2.5" fill="black" />
            <circle cx="309" cy="74" r="2.5" fill="black" />
          </g>
          <text id="h-tools-label" x={TOOLS.cx} y={TOOLS.y + TOOLS.h - 12} textAnchor="middle" fontSize="10" fill="white" opacity="0.56" style={label}>TOOLS</text>
        </g>
        {/* model reasoning card */}
        <g id="h-model">
          <rect id="h-model-bg" x={MODEL.x} y={MODEL.y} width={MODEL.w} height={MODEL.h} rx="20" fill="#2D2D2D" stroke="#464646" />
          <g id="h-net" stroke="white" strokeWidth="1.4" fill="none">
            <rect id="h-core" x={MODEL.cx - 5} y={MODEL.cy - 5} width="10" height="10" transform={`rotate(45 ${MODEL.cx} ${MODEL.cy})`} fill={GREEN} stroke="none" opacity="0.9" />
            <circle cx={MODEL.cx - 14} cy={MODEL.cy - 14} r="2" />
            <circle cx={MODEL.cx + 14} cy={MODEL.cy - 14} r="2" />
            <circle cx={MODEL.cx - 14} cy={MODEL.cy + 14} r="2" />
            <circle cx={MODEL.cx + 14} cy={MODEL.cy + 14} r="2" />
            <path d={`M${MODEL.cx - 14} ${MODEL.cy - 14} L${MODEL.cx} ${MODEL.cy} M${MODEL.cx + 14} ${MODEL.cy - 14} L${MODEL.cx} ${MODEL.cy} M${MODEL.cx - 14} ${MODEL.cy + 14} L${MODEL.cx} ${MODEL.cy} M${MODEL.cx + 14} ${MODEL.cy + 14} L${MODEL.cx} ${MODEL.cy}`} />
          </g>
          <text id="h-model-label" x={MODEL.cx} y={MODEL.y + MODEL.h - 14} textAnchor="middle" fontSize="10" fill="white" opacity="0.56" style={label}>MODEL REASONING</text>
        </g>
        {/* self-check card */}
        <g id="h-self">
          <rect id="h-self-bg" x={SELF.x} y={SELF.y} width={SELF.w} height={SELF.h} rx="18" fill="black" stroke="#2D2D2D" />
          <g stroke="white" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path d={`M${SELF.cx - 10} ${SELF.cy - 12} L${SELF.cx - 10} ${SELF.cy - 2} C${SELF.cx - 10} ${SELF.cy + 6} ${SELF.cx - 5} ${SELF.cy + 10} ${SELF.cx} ${SELF.cy + 12} C${SELF.cx + 5} ${SELF.cy + 10} ${SELF.cx + 10} ${SELF.cy + 6} ${SELF.cx + 10} ${SELF.cy - 2} L${SELF.cx + 10} ${SELF.cy - 12} Z`} />
            <path d={`M${SELF.cx - 5} ${SELF.cy - 1} L${SELF.cx - 1.5} ${SELF.cy + 2.5} L${SELF.cx + 5} ${SELF.cy - 5}`} />
          </g>
          <text id="h-self-label" x={SELF.cx} y={SELF.y + SELF.h - 12} textAnchor="middle" fontSize="10" fill="white" opacity="0.56" style={label}>SELF-CHECK</text>
        </g>
        {/* outcome card */}
        <g id="h-outcome">
          <rect id="h-outcome-bg" x={OUTCOME.x} y={OUTCOME.y} width={OUTCOME.w} height={OUTCOME.h} rx="20" fill="black" stroke="#2D2D2D" />
          <g id="h-seal" stroke="white" strokeWidth="1.6" fill="none">
            <circle cx={OUTCOME.cx} cy={OUTCOME.cy - 7} r="16" />
            <circle cx={OUTCOME.cx} cy={OUTCOME.cy - 7} r="11.5" />
            <path d={`M${OUTCOME.cx - 6} ${OUTCOME.cy - 7} L${OUTCOME.cx - 2} ${OUTCOME.cy - 3} L${OUTCOME.cx + 6} ${OUTCOME.cy - 11}`} strokeLinecap="round" strokeLinejoin="round" />
          </g>
          <text id="h-outcome-label" x={OUTCOME.cx} y={OUTCOME.y + OUTCOME.h - 14} textAnchor="middle" fontSize="10" fill="white" opacity="0.56" style={label}>OUTCOME</text>
          <g id="h-outcheck" opacity="0">
            <circle cx={OUTCHECK.x} cy={OUTCHECK.y} r="9" fill={GREEN} stroke={GREEN} />
            <path d={`M${OUTCHECK.x - 4.5} ${OUTCHECK.y} L${OUTCHECK.x - 1.5} ${OUTCHECK.y + 3} L${OUTCHECK.x + 4.5} ${OUTCHECK.y - 3.5}`} fill="none" stroke="black" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>
      </svg>
    </div>
  )
}
