import { useEffect, useRef } from 'react'

/* ------------------------------------------------------------------
   Ported from AFI/components/HeroAccents.tsx.
   Injects public/page.svg inline and runs two animation systems on the
   REAL elements by ID:
   1) Accent Circle / Accent Line roaming (straight grid steps only)
   2) Main-tile cinematic loop:
      INTAKE (elevate + icon x3 + "INTAKING..." + green gap dots)
        -> INTELLIGENCE (elevate + working spin + "WORKING..." + glow
          + blue #0074D9 dots)
        -> DECISION (elevate + thinking wobble + tick/cross morph +
          APPROVED/REJECTED + green/red dots)
        -> OUTCOME (elevate + circle pings + white dots back to INTAKE)
      Dots travel ONLY on the 1px seams between tiles.
------------------------------------------------------------------- */

const NS = 'http://www.w3.org/2000/svg'
const STEP = 121 // tile pitch in page.svg
const SPEED = 120 // accent roam px/s

const ACCENTS = [
  { id: 'Accent Circle', ox: 838, oy: 110, xMin: 500, xMax: 1400, yMin: 0, yMax: 480 },
  { id: 'Accent Circle_2', ox: 474, oy: 586, xMin: 200, xMax: 900, yMin: 350, yMax: 640 },
  { id: 'Accent Circle_3', ox: 464, oy: 95, xMin: 200, xMax: 900, yMin: 0, yMax: 350 },
  { id: 'Accent Line', ox: 1794, oy: 255, xMin: 1400, xMax: 1794, yMin: 100, yMax: 500 },
]

// gap-only routes (seam centerlines; tiles are 120px on a 121px pitch)
const GREEN_PATH = [
  [174, 352],
  [174, 362.5],
  [416, 362.5],
  [416, 417],
]
const BLUE_PATH = [
  [416, 429],
  [416, 483.5],
  [1323.5, 483.5],
  [1323.5, 181],
  [1378, 181],
]
const VERDICT_PATH = [
  [1390, 181],
  [1444.5, 181],
  [1444.5, 362.5],
  [1747, 362.5],
  [1747, 308],
]
const WHITE_PATH = [
  [1747, 308],
  [1747, 362.5],
  [174, 362.5],
  [174, 308],
]

// alternate approaches so packets arrive from different directions
const GREEN_ALT = [
  [174, 352],
  [174, 362.5],
  [234.5, 362.5],
  [234.5, 483.5],
  [355.5, 483.5],
  [355.5, 423],
  [372, 423],
]
const BLUE_ALT = [
  [410, 429],
  [410, 362.5],
  [355.5, 362.5],
  [355.5, 241.5],
  [1323.5, 241.5],
  [1323.5, 181],
  [1378, 181],
]
const VERDICT_ALT = [
  [1384, 172],
  [1384, 120.5],
  [1686.5, 120.5],
  [1686.5, 302],
  [1741, 302],
]
const WHITE_ALT = [
  [1753, 308],
  [1753, 362.5],
  [1686.5, 362.5],
  [1686.5, 483.5],
  [113.5, 483.5],
  [113.5, 302],
  [168, 302],
]

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

export default function HeroAccents() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let metricTimer = 0

    fetch('/page.svg')
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        svg.style.width = '100%'
        svg.style.height = 'auto'
        svg.style.display = 'block'
        svg.setAttribute('aria-hidden', 'true')
        ref.current.appendChild(svg)

        const q = (id) => svg.querySelector('[id="' + id + '"]')
        const mk = (tag) => document.createElementNS(NS, tag)

        const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
        if (reduced) return

        /* ============ 1) accent roaming (continuous, straight only) ============ */
        const movers = ACCENTS.map((a) => {
          const el = q(a.id)
          return el ? { el, cfg: a, dx: 0, dy: 0, tx: 0, ty: 0 } : null
        })
        const retarget = (m) => {
          const curX = m.cfg.ox + m.dx
          const curY = m.cfg.oy + m.dy
          if (Math.random() < 0.5) {
            const dir = Math.random() < 0.5 ? -1 : 1
            const steps = Math.random() < 0.75 ? 1 : 2
            let ny = curY + dir * STEP * steps
            ny = Math.max(m.cfg.yMin, Math.min(m.cfg.yMax, ny))
            if (ny === curY) ny = Math.max(m.cfg.yMin, Math.min(m.cfg.yMax, curY - dir * STEP))
            m.tx = m.dx
            m.ty = ny - m.cfg.oy
          } else {
            const dir = Math.random() < 0.5 ? -1 : 1
            const steps = Math.random() < 0.75 ? 1 : 2
            let nx = curX + dir * STEP * steps
            nx = Math.max(m.cfg.xMin, Math.min(m.cfg.xMax, nx))
            if (nx === curX) nx = Math.max(m.cfg.xMin, Math.min(m.cfg.xMax, curX - dir * STEP))
            m.tx = nx - m.cfg.ox
            m.ty = m.dy
          }
        }
        movers.forEach((m) => m && retarget(m))
        const rafBox = { id: 0 }
        let last = performance.now()
        const glide = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const move = SPEED * dt
          movers.forEach((m) => {
            if (!m) return
            const rx = m.tx - m.dx
            const ry = m.ty - m.dy
            const dist = Math.hypot(rx, ry)
            if (dist <= move) {
              m.dx = m.tx
              m.dy = m.ty
              retarget(m)
            } else {
              m.dx += (rx / dist) * move
              m.dy += (ry / dist) * move
            }
            m.el.style.transform = 'translate(' + m.dx + 'px,' + m.dy + 'px)'
          })
          rafBox.id = requestAnimationFrame(glide)
        }
        rafBox.id = requestAnimationFrame(glide)

        /* ============ 2) main-tile cinematic loop ============ */
        const tiles = {
          intake: q('Intake Tile'),
          intel: q('Intelligence Tile'),
          decision: q('Decision Tile'),
          outcome: q('Outcome Tile'),
        }
        Object.values(tiles).forEach((g) => {
          if (!g) return
          g.style.transition = 'transform .65s cubic-bezier(.22,1,.36,1), filter .65s ease'
          g.style.transformBox = 'fill-box'
          g.style.transformOrigin = 'center'
        })
        // track border elements ONCE (querying by color later fails
        // because the color was already changed — highlights got stuck)
        const borderEls = new Map()
        Object.values(tiles).forEach((g) => {
          if (!g) return
          const list = Array.from(g.querySelectorAll('[stroke="#2D2D2D"]'))
          list.forEach((el) => {
            el.style.transition = 'stroke .45s ease'
          })
          borderEls.set(g, list)
        })
        // monochrome elevation: straight lift + brightened border + whitish-grey shadow
        const setBorder = (tile, on) => {
          if (!tile) return
          const list = borderEls.get(tile)
          if (list) list.forEach((el) => el.setAttribute('stroke', on ? '#d9d9e0' : '#2D2D2D'))
        }
        const elevate = (g, on) => {
          if (!g) return
          g.style.transform = on ? 'translateY(-10px)' : ''
          g.style.filter = on ? 'drop-shadow(0 14px 28px rgba(235,235,245,0.22))' : ''
          setBorder(g, on)
        }

        // overlay status texts sized + colored EXACTLY like the original
        // labels (white) — revealed with a decode-scramble, never recolored
        const mkText = (x, y) => {
          const t = mk('text')
          t.setAttribute('x', String(x))
          t.setAttribute('y', String(y))
          t.setAttribute('text-anchor', 'middle')
          t.setAttribute('font-size', '12')
          t.setAttribute('letter-spacing', '2')
          t.setAttribute('font-weight', '500')
          t.setAttribute('font-family', "'Space Grotesk',sans-serif")
          t.setAttribute('fill', '#ffffff')
          t.textContent = ''
          t.style.transition = 'opacity .45s'
          t.style.opacity = '0'
          svg.appendChild(t)
          return t
        }
        const intakeText = mkText(174, 326)
        const intelText = mkText(416, 456)
        const verdictText = mkText(1384, 214)
        const SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/#'
        const scrambleTo = (el, str, dur) => {
          dur = dur || 850
          return new Promise((resolve) => {
            const start = performance.now()
            const tickScr = (now) => {
              if (!alive) return resolve()
              const p = Math.min((now - start) / dur, 1)
              const lock = Math.floor(p * str.length)
              let s = ''
              for (let i = 0; i < str.length; i++) {
                const ch = str[i]
                s += i < lock || ch === ' ' || ch === '…' || ch === '/'
                  ? ch
                  : SCRAMBLE_CHARS[(Math.random() * SCRAMBLE_CHARS.length) | 0]
              }
              el.textContent = s
              if (p < 1) requestAnimationFrame(tickScr)
              else {
                el.textContent = str
                resolve()
              }
            }
            requestAnimationFrame(tickScr)
          })
        }
        const showScramble = async (orig, overlay, str) => {
          if (orig) {
            orig.style.transition = 'opacity .45s'
            orig.style.opacity = '0'
          }
          overlay.style.opacity = '0.56'
          await scrambleTo(overlay, str)
        }
        const hideScramble = (orig, overlay) => {
          overlay.style.opacity = '0'
          if (orig) orig.style.opacity = ''
        }

        // INTELLIGENCE icons each spin in place (unambiguous rotation,
        // always lands back on identity so nothing drifts)
        const intelIconEls = ['Icon_2', 'Icon_3', 'Icon Detail_3', 'Icon Detail_4', 'Icon Detail_5', 'Icon Detail_6', 'Icon Detail_7']
          .map((id) => q(id))
          .filter(Boolean)
        intelIconEls.forEach((el) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        const spinIcons = () => {
          if (!alive) return Promise.resolve()
          const ds = [1050, 1250, 900, 1400, 1150, 1000]
          return Promise.all(
            intelIconEls.map((el, i) =>
              el
                .animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(1080deg)' }], {
                  duration: ds[i % ds.length],
                  iterations: 3,
                  easing: 'linear',
                })
                .finished.catch(() => {})
            )
          ).then(() => {})
        }

        // DECISION verdict symbol (tick / cross at the user icon)
        const verdict = mk('g')
        verdict.setAttribute('transform', 'translate(1384,178)')
        verdict.innerHTML =
          '<path d="M -7 1 L -2 6 L 8 -7" stroke="#00D46B" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>' +
          '<g stroke="#ff5a5a" stroke-width="4" stroke-linecap="round" style="display:none"><line x1="-6" y1="-6" x2="6" y2="6"/><line x1="6" y1="-6" x2="-6" y2="6"/></g>'
        verdict.firstElementChild.style.display = ''
        verdict.style.display = 'none'
        verdict.style.transformBox = 'fill-box'
        verdict.style.transformOrigin = 'center'
        svg.appendChild(verdict)

        // dots layer (always on top)
        const dots = mk('g')
        svg.appendChild(dots)

        const prepScale = (el) => {
          if (!el) return
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        }
        const pulse = (el, dur, delay) => {
          dur = dur || 420
          delay = delay || 0
          if (!el || !alive) return Promise.resolve()
          return el
            .animate(
              [
                { transform: 'scale(.35)', opacity: 0.45 },
                { transform: 'scale(1.1)', opacity: 1, offset: 0.7 },
                { transform: 'scale(1)', opacity: 1 },
              ],
              { duration: dur, delay, easing: 'ease-out' }
            )
            .finished.catch(() => {})
        }
        const wobble = (el) => {
          if (!el || !alive) return Promise.resolve()
          return el
            .animate(
              [
                { transform: 'rotate(0deg)' },
                { transform: 'rotate(-10deg)' },
                { transform: 'rotate(10deg)' },
                { transform: 'rotate(-8deg)' },
                { transform: 'rotate(8deg)' },
                { transform: 'rotate(0deg)' },
              ],
              { duration: 720, easing: 'ease-in-out' }
            )
            .finished.catch(() => {})
        }

        // fly muted diamond packets along gap-only waypoint paths.
        // packets alternate between two routes so they approach
        // each tile from different directions
        const fly = (paths, tint, speed, stagger, n) => {
          const jobs = []
          for (let k = 0; k < n; k++) {
            const wps = paths[k % paths.length]
            const segs = [0]
            let total = 0
            for (let i = 1; i < wps.length; i++) {
              total += Math.hypot(wps[i][0] - wps[i - 1][0], wps[i][1] - wps[i - 1][1])
              segs.push(total)
            }
            const dur = (total / speed) * 1000
            const g = mk('g')
            g.innerHTML =
              '<rect x="-3" y="-3" width="6" height="6" rx="1.5" fill="' + tint + '" opacity="0.9" transform="rotate(45)"/>' +
              '<circle r="1" fill="#e9eef3"/>'
            dots.appendChild(g)
            const kf = wps.map(([x, y], i) => ({
              transform: 'translate(' + x + 'px,' + y + 'px)',
              opacity: i === 0 ? 0 : 1,
              offset: segs[i] / total,
            }))
            kf.push({ transform: 'translate(' + wps[wps.length - 1][0] + 'px,' + wps[wps.length - 1][1] + 'px)', opacity: 0, offset: 1 })
            const a = g.animate(kf, { duration: dur, delay: k * stagger, easing: 'linear', fill: 'both' })
            jobs.push(
              a.finished
                .then(() => sleep(200))
                .then(() => g.remove())
                .catch(() => {})
            )
          }
          return Promise.all(jobs).then(() => sleep(150))
        }

        const ping = (cx, cy, delay) => {
          delay = delay || 0
          const c = mk('circle')
          c.setAttribute('cx', String(cx))
          c.setAttribute('cy', String(cy))
          c.setAttribute('r', '10')
          c.setAttribute('fill', 'none')
          c.setAttribute('stroke', '#ffffff')
          c.setAttribute('stroke-width', '1.5')
          c.style.transformBox = 'fill-box'
          c.style.transformOrigin = 'center'
          dots.appendChild(c)
          return c
            .animate(
              [
                { transform: 'scale(1)', opacity: 0.8 },
                { transform: 'scale(3.2)', opacity: 0 },
              ],
              { duration: 900, delay, easing: 'ease-out' }
            )
            .finished.then(() => c.remove())
            .catch(() => {})
        }

        const intakeIcon = q('Icon')
        const intakeDot = q('Icon Detail')
        const userIcon = q('User-Circle-Single--Streamline-Flex')
        const outcomeDot = q('Icon Detail_2')
        ;[intakeIcon, intakeDot, userIcon, outcomeDot].forEach(prepScale)

        /* ---- Metrics Tile live counter ----
           The "10,303" in the SVG is outlined paths, so swap in a live
           <text> twin: same x/baseline, Space Grotesk, white @ 0.44,
           left-anchored with tabular figures for steady digits.
           Counts continuously 500 -> 10,000 at +1/sec, then wraps.
           Direct DOM writes only — zero React re-renders. */
        const METRIC_START = 500
        const METRIC_TARGET = 10000
        const metricOrig = q('Metric')
        let metricText = null
        let metricValue = METRIC_START
        const fmtMetric = (n) => n.toLocaleString('en-US')
        if (metricOrig && metricOrig.parentNode) {
          try {
            const bb = metricOrig.getBBox()
            const t = mk('text')
            t.setAttribute('x', String(bb.x))
            t.setAttribute('y', String(bb.y + bb.height))
            t.setAttribute('font-family', "'Space Grotesk',sans-serif")
            t.setAttribute('font-size', String(bb.height / 0.7))
            t.setAttribute('fill', '#ffffff')
            t.style.opacity = '0.44'
            t.style.fontVariantNumeric = 'tabular-nums'
            t.textContent = fmtMetric(metricValue)
            metricOrig.parentNode.insertBefore(t, metricOrig.nextSibling)
            metricOrig.style.opacity = '0'
            metricText = t
          } catch (e) { metricText = null }
        }
        metricTimer = setInterval(() => {
          if (!alive) return
          if (metricText) {
            metricValue = metricValue >= METRIC_TARGET ? METRIC_START : metricValue + 1
            metricText.textContent = fmtMetric(metricValue)
          }
        }, 1000)

        const run = async () => {
          await sleep(1200)
          while (alive) {
            /* ---- INTAKE: elevate, icon x3, INTAKING..., green packets out ---- */
            elevate(tiles.intake, true)
            await showScramble(q('Label_4'), intakeText, 'INTAKING…')
            for (let k = 0; k < 3 && alive; k++) {
              await Promise.all([pulse(intakeDot, 380), pulse(intakeIcon, 380, 120)])
              await sleep(120)
            }
            await fly([GREEN_PATH, GREEN_ALT], '#5f8a6f', 260, 150, 7)
            elevate(tiles.intake, false)
            hideScramble(q('Label_4'), intakeText)
            if (!alive) return

            /* ---- INTELLIGENCE: elevate, WORKING..., icons rotate, packets ---- */
            elevate(tiles.intel, true)
            await showScramble(q('Label_6'), intelText, 'WORKING…')
            const spin = spinIcons()
            await sleep(1200)
            if (!alive) return
            await fly([BLUE_PATH, BLUE_ALT], '#5b7ea6', 340, 150, 7)
            await spin
            elevate(tiles.intel, false)
            hideScramble(q('Label_6'), intelText)
            if (!alive) return

            /* ---- DECISION: elevate, thinking, morph, verdict, colored dots ---- */
            elevate(tiles.decision, true)
            for (let k = 0; k < 2 && alive; k++) await wobble(userIcon)
            if (!alive) return
            const approved = Math.random() < 0.65
            if (userIcon) {
              userIcon.style.transition = 'opacity .4s'
              userIcon.style.opacity = '0.12'
            }
            const tick = verdict.firstElementChild
            const cross = verdict.lastElementChild
            tick.style.display = approved ? '' : 'none'
            cross.style.display = approved ? 'none' : ''
            verdict.style.display = ''
            verdict.animate(
              [
                { transform: 'scale(.3)', opacity: 0 },
                { transform: 'scale(1.15)', opacity: 1, offset: 0.6 },
                { transform: 'scale(1)', opacity: 1 },
              ],
              { duration: 500, easing: 'cubic-bezier(.2,1.4,.4,1)' }
            )
            await showScramble(q('Label_3'), verdictText, approved ? 'APPROVED' : 'REJECTED')
            await sleep(1000)
            if (!alive) return
            await fly([VERDICT_PATH, VERDICT_ALT], approved ? '#5f8a6d' : '#a05f5f', 300, 150, 7)
            verdict.style.display = 'none'
            if (userIcon) userIcon.style.opacity = ''
            elevate(tiles.decision, false)
            hideScramble(q('Label_3'), verdictText)
            if (!alive) return

            /* ---- OUTCOME: elevate, circle pings, white dots home ---- */
            elevate(tiles.outcome, true)
            await Promise.all([ping(1747, 292, 0), ping(1747, 292, 350), ping(1747, 292, 700)])
            if (!alive) return
            await pulse(outcomeDot, 420)
            await fly([WHITE_PATH, WHITE_ALT], '#9aa5b1', 430, 150, 7)
            elevate(tiles.outcome, false)
          }
        }
        run()
      })
      .catch(() => {})

    return () => {
      alive = false
      if (metricTimer) clearInterval(metricTimer)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="w-full max-w-[1920px] aspect-[1920/725] opacity-90" aria-hidden />
}
