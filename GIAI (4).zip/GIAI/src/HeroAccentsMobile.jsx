import { useEffect, useRef } from 'react'
import heroMobileUrl from '../asset/Hero background mobile.svg'

/* ------------------------------------------------------------------
   Mobile twin of HeroAccents: the SAME cinematic loop as the desktop
   hero background (accent roaming + INTAKE -> INTELLIGENCE ->
   DECISION -> OUTCOME tile theatre with scramble labels, flying
   packets, verdict morph and outcome pings), adapted to the mobile
   artwork's own IDs and geometry.

   Differences from desktop (all deliberate):
   - tile centers, label anchors and packet routes are measured at
     runtime via getBBox, so nothing hardcodes mobile coordinates;
   - the verdict tick/cross lives in an inner group so the WAAPI pop
     scale never overrides its placement (no jump-to-origin);
   - the svg keeps the mobile visibility treatment
     (brightness/contrast lift) in both animated and static modes.
------------------------------------------------------------------- */

const NS = 'http://www.w3.org/2000/svg'
const STEP = 65 // mobile grid pitch
const SPEED = 90 // accent roam px/s
const SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/#'

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const centerOf = (el) => {
  const b = el.getBBox()
  return { x: b.x + b.width / 2, y: b.y + b.height / 2, w: b.width, h: b.height }
}

export default function HeroAccentsMobile() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let rafBox = 0
    let metricTimer = 0

    fetch(heroMobileUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.width = '100%'
        svg.style.height = '100%'
        svg.style.display = 'block'
        svg.style.filter = 'brightness(1.6) contrast(1.05)'
        svg.setAttribute('aria-hidden', 'true')
        svg.setAttribute('preserveAspectRatio', 'xMidYMin slice')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const q = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const mk = (tag) => document.createElementNS(NS, tag)

        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

        /* ============ 1) accent roaming (continuous, straight only) ============ */
        const ACCENT_IDS = ['Accent Circle', 'Accent Circle_2', 'Accent Circle_3', 'Accent Line']
        const movers = ACCENT_IDS.map((id) => {
          const el = q(id)
          if (!el) return null
          // wrap when the node carries its own transform so CSS motion
          // never overrides authored placement
          let node = el
          if (el.hasAttribute && el.hasAttribute('transform')) {
            const wrap = mk('g')
            if (el.parentNode) el.parentNode.insertBefore(wrap, el)
            wrap.appendChild(el)
            node = wrap
          }
          let ax = 0
          let ay = 0
          try {
            const c = centerOf(node)
            ax = c.x
            ay = c.y
          } catch (e) {}
          return { node, ax, ay, dx: 0, dy: 0, tx: 0, ty: 0 }
        }).filter(Boolean)
        const X_MIN = 0
        const X_MAX = 394
        const Y_MIN = 0
        const Y_MAX = 928
        const retarget = (m) => {
          const curX = m.ax + m.dx
          const curY = m.ay + m.dy
          if (Math.random() < 0.5) {
            const dir = Math.random() < 0.5 ? -1 : 1
            const steps = Math.random() < 0.75 ? 1 : 2
            let ny = curY + dir * STEP * steps
            ny = Math.max(Y_MIN, Math.min(Y_MAX, ny))
            if (ny === curY) ny = Math.max(Y_MIN, Math.min(Y_MAX, curY - dir * STEP))
            m.tx = m.dx
            m.ty = ny - m.ay
          } else {
            const dir = Math.random() < 0.5 ? -1 : 1
            const steps = Math.random() < 0.75 ? 1 : 2
            let nx = curX + dir * STEP * steps
            nx = Math.max(X_MIN, Math.min(X_MAX, nx))
            if (nx === curX) nx = Math.max(X_MIN, Math.min(X_MAX, curX - dir * STEP))
            m.tx = nx - m.ax
            m.ty = m.dy
          }
        }
        movers.forEach(retarget)
        let last = performance.now()
        const glide = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const move = SPEED * dt
          movers.forEach((m) => {
            const rx = m.tx - m.dx
            const ry = m.ty - m.dy
            const dist = Math.hypot(rx, ry)
            if (dist <= move) {
              m.dx = m.tx
              m.dy = m.ty
              retarget(m)
            } else {
              m.dx += (rx / dist) * move
              m.dy += (ry / dist) * move
            }
            m.node.style.transform = 'translate(' + m.dx + 'px,' + m.dy + 'px)'
          })
          rafBox = requestAnimationFrame(glide)
        }
        rafBox = requestAnimationFrame(glide)

        /* ============ 2) main-tile cinematic loop ============ */
        const tiles = {
          intake: q('Intake Tile'),
          intel: q('Intelligence Tile'),
          decision: q('Decision Tile'),
          outcome: q('Outcome Tile'),
        }
        const tileBox = {}
        Object.entries(tiles).forEach(([k, g]) => {
          if (!g) return
          g.style.transition = 'transform .65s cubic-bezier(.22,1,.36,1), filter .65s ease'
          g.style.transformBox = 'fill-box'
          g.style.transformOrigin = 'center'
          try {
            tileBox[k] = centerOf(g)
          } catch (e) {}
        })
        const C = (k, fb) => tileBox[k] || fb
        const intakeC = C('intake', { x: 197, y: 140, w: 65, h: 65 })
        const intelC = C('intel', { x: 107, y: 107, w: 65, h: 65 })
        const decisionC = C('decision', { x: 304, y: 632, w: 65, h: 65 })
        const outcomeC = C('outcome', { x: 133, y: 700, w: 40, h: 40 })

        // track border elements ONCE so highlights never get stuck
        const borderEls = new Map()
        const borderBase = new Map()
        Object.values(tiles).forEach((g) => {
          if (!g) return
          const list = Array.from(g.querySelectorAll('[stroke]')).filter((el) => {
            const s = (el.getAttribute('stroke') || '').toLowerCase()
            return s && s !== 'none' && s !== 'white' && s !== '#ffffff'
          })
          list.forEach((el) => {
            el.style.transition = 'stroke .45s ease'
            if (!borderBase.has(el)) borderBase.set(el, el.getAttribute('stroke'))
          })
          borderEls.set(g, list)
        })
        const setBorder = (tile, on) => {
          if (!tile) return
          const list = borderEls.get(tile)
          if (list) {
            list.forEach((el) => {
              try {
                el.setAttribute('stroke', on ? '#d9d9e0' : borderBase.get(el))
              } catch (e) {}
            })
          }
        }
        const elevate = (g, on) => {
          if (!g) return
          g.style.transform = on ? 'translateY(-7px)' : ''
          g.style.filter = on ? 'drop-shadow(0 10px 20px rgba(235,235,245,0.22))' : ''
          setBorder(g, on)
        }

        // overlay status texts sized from their tiles — decode-scramble in
        const mkText = (cx, y, size) => {
          const t = mk('text')
          t.setAttribute('x', String(cx))
          t.setAttribute('y', String(y))
          t.setAttribute('text-anchor', 'middle')
          t.setAttribute('font-size', String(size))
          t.setAttribute('letter-spacing', '1.5')
          t.setAttribute('font-weight', '500')
          t.setAttribute('font-family', "'Space Grotesk',sans-serif")
          t.setAttribute('fill', '#ffffff')
          t.textContent = ''
          t.style.transition = 'opacity .45s'
          t.style.opacity = '0'
          svg.appendChild(t)
          return t
        }
        const labelSize = 8
        const intakeText = mkText(intakeC.x, intakeC.y + intakeC.h / 2 - 8, labelSize)
        const intelText = mkText(intelC.x, intelC.y + intelC.h / 2 - 8, labelSize)
        const verdictText = mkText(decisionC.x, decisionC.y - decisionC.h / 2 - 10, labelSize)
        const scrambleTo = (el, str, dur) => {
          dur = dur || 850
          return new Promise((resolve) => {
            const start = performance.now()
            const tickScr = (now) => {
              if (!alive) return resolve()
              const p = Math.min((now - start) / dur, 1)
              const lock = Math.floor(p * str.length)
              let s = ''
              for (let i = 0; i < str.length; i++) {
                const ch = str[i]
                s += i < lock || ch === ' ' || ch === '…' || ch === '/' ? ch : SCRAMBLE_CHARS[(Math.random() * SCRAMBLE_CHARS.length) | 0]
              }
              el.textContent = s
              if (p < 1) requestAnimationFrame(tickScr)
              else {
                el.textContent = str
                resolve()
              }
            }
            requestAnimationFrame(tickScr)
          })
        }
        const tileLabel = (g) => {
          // exact match only: a loose prefix selector catches the
          // decorative "Label Marker" slashes and the real label never
          // hides (double text) — same class of bug as the border query
          try {
            if (!g) return null
            const all = Array.from(g.querySelectorAll('path[id]'))
            return all.find((p) => /^Label(_\d+)?$/.test(p.getAttribute('id'))) || null
          } catch (e) {
            return null
          }
        }
        const showScramble = async (tile, overlay, str) => {
          // park the overlay exactly on the hidden original (measured
          // live, like the metric twin) so size + baseline always match
          const orig = tileLabel(tile)
          if (orig) {
            try {
              const b = orig.getBBox()
              overlay.setAttribute('x', (b.x + b.width / 2).toFixed(1))
              overlay.setAttribute('y', (b.y + b.height).toFixed(1))
              overlay.setAttribute('font-size', Math.max(6, b.height / 0.7).toFixed(1))
              overlay.setAttribute('letter-spacing', '1')
            } catch (e) {}
            orig.style.transition = 'opacity .45s'
            orig.style.opacity = '0'
          }
          overlay.style.opacity = '0.56'
          await scrambleTo(overlay, str)
        }
        const hideScramble = (tile, overlay) => {
          overlay.style.opacity = '0'
          const orig = tileLabel(tile)
          if (orig) orig.style.opacity = ''
        }

        // intelligence icons spin in place, always landing on identity
        const intelIconEls = ['Icon', 'Icon_2', 'Icon_3', 'Icon Detail', 'Icon Detail_2', 'Icon Detail_3', 'Icon Detail_4', 'Icon Detail_5', 'Icon Detail_6', 'Icon Detail_7']
          .map((id) => q(id))
          .filter(Boolean)
          .slice(0, 6)
        intelIconEls.forEach((el) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        const spinIcons = () => {
          if (!alive) return Promise.resolve()
          const ds = [1050, 1250, 900, 1400, 1150, 1000]
          return Promise.all(
            intelIconEls.map((el, i) =>
              el
                .animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(1080deg)' }], {
                  duration: ds[i % ds.length],
                  iterations: 3,
                  easing: 'linear',
                })
                .finished.catch(() => {})
            )
          ).then(() => {})
        }

        // verdict tick/cross at the decision user icon — pop scale runs on
        // an INNER group so placement on the outer group is never overridden
        const verdictOuter = mk('g')
        const verdict = mk('g')
        const userSpot = (() => {
          const u = q('User Icon')
          if (u) {
            try {
              return centerOf(u)
            } catch (e) {}
          }
          return { x: decisionC.x, y: decisionC.y }
        })()
        verdictOuter.setAttribute('transform', 'translate(' + userSpot.x.toFixed(1) + ',' + userSpot.y.toFixed(1) + ') scale(0.65)')
        verdict.innerHTML =
          '<path d="M -7 1 L -2 6 L 8 -7" stroke="#00D46B" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>' +
          '<g stroke="#ff5a5a" stroke-width="4" stroke-linecap="round" style="display:none"><line x1="-6" y1="-6" x2="6" y2="6"/><line x1="6" y1="-6" x2="-6" y2="6"/></g>'
        verdict.firstElementChild.style.display = ''
        verdict.style.display = 'none'
        verdict.style.transformBox = 'fill-box'
        verdict.style.transformOrigin = 'center'
        verdictOuter.appendChild(verdict)
        svg.appendChild(verdictOuter)

        // dots layer (always on top)
        const dots = mk('g')
        svg.appendChild(dots)

        const prepScale = (el) => {
          if (!el) return
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        }
        const pulse = (el, dur, delay) => {
          dur = dur || 420
          delay = delay || 0
          if (!el || !alive) return Promise.resolve()
          return el
            .animate(
              [
                { transform: 'scale(.35)', opacity: 0.45 },
                { transform: 'scale(1.1)', opacity: 1, offset: 0.7 },
                { transform: 'scale(1)', opacity: 1 },
              ],
              { duration: dur, delay, easing: 'ease-out' }
            )
            .finished.catch(() => {})
        }
        const wobble = (el) => {
          if (!el || !alive) return Promise.resolve()
          return el
            .animate(
              [
                { transform: 'rotate(0deg)' },
                { transform: 'rotate(-10deg)' },
                { transform: 'rotate(10deg)' },
                { transform: 'rotate(-8deg)' },
                { transform: 'rotate(8deg)' },
                { transform: 'rotate(0deg)' },
              ],
              { duration: 720, easing: 'ease-in-out' }
            )
            .finished.catch(() => {})
        }

        // fly muted diamond packets along waypoint paths, alternating
        // routes so packets approach tiles from different directions
        const fly = (paths, tint, speed, stagger, n) => {
          const jobs = []
          for (let k = 0; k < n; k++) {
            const wps = paths[k % paths.length]
            const segs = [0]
            let total = 0
            for (let i = 1; i < wps.length; i++) {
              total += Math.hypot(wps[i][0] - wps[i - 1][0], wps[i][1] - wps[i - 1][1])
              segs.push(total)
            }
            if (total <= 0) continue
            const dur = (total / speed) * 1000
            const g = mk('g')
            g.innerHTML =
              '<rect x="-2.4" y="-2.4" width="4.8" height="4.8" rx="1.2" fill="' + tint + '" opacity="0.9" transform="rotate(45)"/>' +
              '<circle r="0.8" fill="#e9eef3"/>'
            dots.appendChild(g)
            const kf = wps.map(([x, y], i) => ({
              transform: 'translate(' + x + 'px,' + y + 'px)',
              opacity: i === 0 ? 0 : 1,
              offset: segs[i] / total,
            }))
            kf.push({ transform: 'translate(' + wps[wps.length - 1][0] + 'px,' + wps[wps.length - 1][1] + 'px)', opacity: 0, offset: 1 })
            const a = g.animate(kf, { duration: dur, delay: k * stagger, easing: 'linear', fill: 'both' })
            jobs.push(
              a.finished
                .then(() => sleep(200))
                .then(() => g.remove())
                .catch(() => {})
            )
          }
          return Promise.all(jobs).then(() => sleep(150))
        }

        const ping = (cx, cy, delay) => {
          delay = delay || 0
          const c = mk('circle')
          c.setAttribute('cx', String(cx))
          c.setAttribute('cy', String(cy))
          c.setAttribute('r', '8')
          c.setAttribute('fill', 'none')
          c.setAttribute('stroke', '#ffffff')
          c.setAttribute('stroke-width', '1.2')
          c.style.transformBox = 'fill-box'
          c.style.transformOrigin = 'center'
          dots.appendChild(c)
          return c
            .animate(
              [
                { transform: 'scale(1)', opacity: 0.8 },
                { transform: 'scale(3.2)', opacity: 0 },
              ],
              { duration: 900, delay, easing: 'ease-out' }
            )
            .finished.then(() => c.remove())
            .catch(() => {})
        }

        // packet routes derived from the measured tile geometry
        const elbow = (x0, y0, x1, y1) => {
          const pts = [
            [x0, y0],
            [x0, y1],
            [x1, y1],
          ]
          return pts.filter(([x, y], i) => i === 0 || Math.hypot(x - pts[i - 1][0], y - pts[i - 1][1]) > 1)
        }
        const GREEN_PATH = elbow(intakeC.x, intakeC.y + intakeC.h / 2, intelC.x, intelC.y - intelC.h / 2)
        const GREEN_ALT = elbow(intakeC.x - intakeC.w / 2, intakeC.y, intelC.x, intelC.y)
        const BLUE_PATH = elbow(intelC.x, intelC.y + intelC.h / 2, decisionC.x, decisionC.y - decisionC.h / 2)
        const BLUE_ALT = elbow(intelC.x + intelC.w / 2, intelC.y, decisionC.x, decisionC.y)
        const VERDICT_PATH = elbow(decisionC.x, decisionC.y + decisionC.h / 2, outcomeC.x, outcomeC.y - outcomeC.h / 2)
        const VERDICT_ALT = elbow(decisionC.x - decisionC.w / 2, decisionC.y, outcomeC.x, outcomeC.y)
        const WHITE_PATH = elbow(outcomeC.x, outcomeC.y - outcomeC.h / 2, intakeC.x, intakeC.y + intakeC.h / 2)
        const WHITE_ALT = elbow(outcomeC.x + outcomeC.w / 2, outcomeC.y, intakeC.x + intakeC.w / 2, intakeC.y)

        const intakeIcon = q('Icon')
        const intakeDot = q('Icon Detail')
        const userIcon = q('User Icon')
        const outcomeDot = q('Icon Detail_2')
        ;[intakeIcon, intakeDot, userIcon, outcomeDot].forEach(prepScale)

        /* ---- Metrics Tile live counter (same twin-text technique) ---- */
        const METRIC_START = 500
        const METRIC_TARGET = 10000
        const metricOrig = q('Metric')
        let metricText = null
        let metricValue = METRIC_START
        const fmtMetric = (n) => n.toLocaleString('en-US')
        if (metricOrig && metricOrig.parentNode) {
          try {
            const bb = metricOrig.getBBox()
            const t = mk('text')
            t.setAttribute('x', String(bb.x))
            t.setAttribute('y', String(bb.y + bb.height))
            t.setAttribute('font-family', "'Space Grotesk',sans-serif")
            t.setAttribute('font-size', String(bb.height / 0.7))
            t.setAttribute('fill', '#ffffff')
            t.style.opacity = '0.44'
            t.style.fontVariantNumeric = 'tabular-nums'
            t.textContent = fmtMetric(metricValue)
            metricOrig.parentNode.insertBefore(t, metricOrig.nextSibling)
            metricOrig.style.opacity = '0'
            metricText = t
          } catch (e) {
            metricText = null
          }
        }
        metricTimer = setInterval(() => {
          if (!alive) return
          if (metricText) {
            metricValue = metricValue >= METRIC_TARGET ? METRIC_START : metricValue + 1
            metricText.textContent = fmtMetric(metricValue)
          }
        }, 1000)

        const run = async () => {
          await sleep(1200)
          while (alive) {
            /* ---- INTAKE: elevate, icon x3, INTAKING..., green packets out ---- */
            elevate(tiles.intake, true)
            await showScramble(tiles.intake, intakeText, 'INTAKING…')
            for (let k = 0; k < 3 && alive; k++) {
              await Promise.all([pulse(intakeDot, 380), pulse(intakeIcon, 380, 120)])
              await sleep(120)
            }
            await fly([GREEN_PATH, GREEN_ALT], '#5f8a6f', 200, 150, 6)
            elevate(tiles.intake, false)
            hideScramble(tiles.intake, intakeText)
            if (!alive) return

            /* ---- INTELLIGENCE: elevate, WORKING..., icons rotate, packets ---- */
            elevate(tiles.intel, true)
            await showScramble(tiles.intel, intelText, 'WORKING…')
            const spin = spinIcons()
            await sleep(1200)
            if (!alive) return
            await fly([BLUE_PATH, BLUE_ALT], '#5b7ea6', 260, 150, 6)
            await spin
            elevate(tiles.intel, false)
            hideScramble(tiles.intel, intelText)
            if (!alive) return

            /* ---- DECISION: elevate, thinking, morph, verdict, colored dots ---- */
            elevate(tiles.decision, true)
            for (let k = 0; k < 2 && alive; k++) await wobble(userIcon)
            if (!alive) return
            const approved = Math.random() < 0.65
            if (userIcon) {
              userIcon.style.transition = 'opacity .4s'
              userIcon.style.opacity = '0.12'
            }
            const tick = verdict.firstElementChild
            const cross = verdict.lastElementChild
            tick.style.display = approved ? '' : 'none'
            cross.style.display = approved ? 'none' : ''
            verdict.style.display = ''
            verdict.animate(
              [
                { transform: 'scale(.3)', opacity: 0 },
                { transform: 'scale(1.15)', opacity: 1, offset: 0.6 },
                { transform: 'scale(1)', opacity: 1 },
              ],
              { duration: 500, easing: 'cubic-bezier(.2,1.4,.4,1)' }
            )
            await showScramble(tiles.decision, verdictText, approved ? 'APPROVED' : 'REJECTED')
            await sleep(1000)
            if (!alive) return
            await fly([VERDICT_PATH, VERDICT_ALT], approved ? '#5f8a6d' : '#a05f5f', 230, 150, 6)
            verdict.style.display = 'none'
            if (userIcon) userIcon.style.opacity = ''
            elevate(tiles.decision, false)
            hideScramble(tiles.decision, verdictText)
            if (!alive) return

            /* ---- OUTCOME: elevate, circle pings, white dots home ---- */
            elevate(tiles.outcome, true)
            await Promise.all([ping(outcomeC.x, outcomeC.y, 0), ping(outcomeC.x, outcomeC.y, 350), ping(outcomeC.x, outcomeC.y, 700)])
            if (!alive) return
            await pulse(outcomeDot, 420)
            await fly([WHITE_PATH, WHITE_ALT], '#9aa5b1', 330, 150, 6)
            elevate(tiles.outcome, false)
          }
        }
        run()
      })
      .catch(() => {})

    return () => {
      alive = false
      cancelAnimationFrame(rafBox)
      if (metricTimer) clearInterval(metricTimer)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="w-full h-full" aria-hidden />
}
