import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence, useScroll, useReducedMotion, useTransform } from 'framer-motion'
import StepVisual from './StepVisual.jsx'
import ChooseApproachLoop from './ChooseApproachLoop.jsx'
import IntegrateLoop from './IntegrateLoop.jsx'
import PerformLoop from './PerformLoop.jsx'
import LearnLoop from './LearnLoop.jsx'
import GovernLoop from './GovernLoop.jsx'
import IntroLoop from './IntroLoop.jsx'



import visMapData from '../asset/map your data story.svg'
import visChoose from '../asset/Choose the right approach for each problem.svg'
import visIntegrate from '../asset/Integrate into your existing operations.svg'
import visPerform from '../asset/See how it performs in the real world.svg'
import visLearn from '../asset/Design systems that learn automatically.svg'
import visGovern from '../asset/Govern.svg'

/* ------------------------------------------------------------------
   HOW WE BUILD — scroll-driven pinned stepper (7 slots over 700vh):
   slot 0 = heading fixes at viewport, then scrolls off as
   slots 1..6 reveal ("N OF 6" + copy + visual) one by one while the
   6-segment progress bar fills per step. Desktop pins; mobile stacks.
   Copy + artwork reuse the existing site assets (no new content).
------------------------------------------------------------------- */

const EASE = [0.16, 1, 0.3, 1]
const SLOTS = 7 // intro + 6 steps

const INTRO_LEADS = [
  'A capable model provides the reasoning. We build the systems that turn it into business outcomes.',
  'Our agentic harness gives models what they need to do real work: clear instructions, the right business context, and tools to act. It carries tasks across many steps, checks its own results along the way, and brings in people where judgment matters. The result is AI you can rely on, not just demo.',
]

const STEPS = [
  {
    n: 'Map your data',
    d: ['We connect your data, software, knowledge and operational systems where they already live. The goal isn\u2019t to move everything into a new platform. It\u2019s to structure the information AI needs to understand your business.'],
    proof: { tag: 'FAMETN', text: 'We brought MSME profiles, buyer requirements and sector data into one structured CRM, so matchmaking draws on capability and intent rather than directory listings.' },
    img: visMapData,
  },
  {
    n: 'Choose the right tool',
    d: ['Not everything is an AI problem. We use AI where it creates real leverage: pattern recognition, personalisation, complex routing and reasoning over unstructured information. Where rules, traditional ML or deterministic logic are clearer, faster and easier to maintain, we use those instead, and save model calls for work that needs them.'],
    img: visChoose,
  },
  {
    n: 'Integrate into operations',
    d: ['We design applications, agents and workflows around how your organisation actually works. The harness connects model reasoning to the tools that do the work, carries context across steps, and runs each cycle through to completion or a human handoff.'],
    proof: { tag: 'StartupTN', text: 'Four specialised agents for application evaluation, investor matchmaking, inclusive fund applications and ecosystem intelligence, built on no-code workflows that programme teams adjust as their programmes change.' },
    img: visIntegrate,
  },
  {
    n: 'Observe in production',
    d: ['Reliable AI needs continuous visibility once it\u2019s live. We combine automated evaluations, telemetry, trace-level monitoring and human review to measure performance and catch failures early.'],
    proof: { tag: 'StartupTN', text: 'Leadership sees application volumes, processing stages and bottlenecks in real time, so problems surface during a programme cycle, not after it.' },
    img: visPerform,
  },
  {
    n: 'Improve from feedback',
    d: ['Real-world usage becomes a learning signal. We capture human corrections, system behaviour and operational outcomes and feed them back into the system, so it gets more useful the longer it runs.'],
    proof: { tag: 'StartupTN', text: 'Reviewer corrections and committee decisions shape how applications are screened in the next cycle.' },
    img: visLearn,
  },
  {
    n: 'Govern throughout',
    d: ['Governance runs through every stage. We build in human oversight, audit trails, access controls and traceability, so teams can see what the AI did, why, and where to step in.'],
    proof: { tag: 'Government grievance redressal', text: 'Every petition keeps a traceable record of how it was classified, routed and handled. That matters when decisions affect citizens.' },
    coda: 'Built for real operations. Engineered for production.',
    img: visGovern,
  },
]

function SegFill({ progress, from }) {
  const fill = useTransform(progress, [from, from + 1 / SLOTS], [0, 1])
  return (
    <motion.span
      className="block h-full w-full origin-left bg-white"
      style={{ scaleX: fill }}
    />
  )
}

export default function HowWeBuildScroll() {
  const trackRef = useRef(null)
  const [phase, setPhase] = useState(0)
  const [entered, setEntered] = useState(false)
  const [cover, setCover] = useState(false)
  const [art, setArt] = useState('intro')
  const firstRun = useRef(true)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ['start start', 'end end'] })
  const D = (d) => (reduce ? 0 : d)

  useEffect(() => {
    let cur = 0
    // synchronous: content tracks scroll frame-by-frame like the progress
    // bar does. Hysteresis (no timer) still guards slot-edge strobing.
    const unsub = scrollYProgress.on('change', (v) => {
      const raw = Math.min(1, Math.max(0, v)) * SLOTS
      let p = Math.min(SLOTS - 1, Math.max(0, Math.floor(raw)))
      if (p > cur && raw < cur + 1 + 0.04) p = cur
      if (p < cur && raw > cur - 0.04) p = cur
      if (p !== cur) {
        cur = p
        setPhase(p)
      }
    })
    return () => unsub()
  }, [scrollYProgress])

  /* form the mosaic once when the track first scrolls into view */
  useEffect(() => {
    const el = trackRef.current
    if (!el) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setEntered(true)
      return
    }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setEntered(true)
        io.disconnect()
      }
    }, { threshold: 0.12 })
    io.observe(el)
    return () => io.disconnect()
  }, [])

  /* cover → swap art unseen → reveal, on every step change */
  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false
      return
    }
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setArt(phase === 0 ? 'intro' : phase === 1 ? 'map' : 'img' + phase)
      return
    }
    setCover(true)
    const t1 = setTimeout(() => {
      setArt(phase === 0 ? 'intro' : phase === 1 ? 'map' : 'img' + phase)
    }, 180)
    const t2 = setTimeout(() => setCover(false), 400)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [phase])

  const jumpTo = (slot) => {
    const el = trackRef.current
    if (!el) return
    const top = el.getBoundingClientRect().top + window.scrollY
    const y = top + ((slot + 0.5) / SLOTS) * el.offsetHeight - window.innerHeight / 2
    const lenis = typeof window !== 'undefined' ? window.__lenis : null
    if (lenis) {
      try {
        lenis.scrollTo(y)
        return
      } catch (e) {}
    }
    window.scrollTo({ top: y, behavior: reduce ? 'auto' : 'smooth' })
  }

  return (
    <>
      {/* ---------- desktop: pinned scroll stepper ---------- */}
      {!reduce && (
      <div ref={trackRef} className="relative hidden lg:block" style={{ height: '700vh' }}>
        <div className="sticky top-0 flex h-screen items-center overflow-hidden bg-black">
          <div className="mx-auto flex w-full max-w-[1720px] flex-col justify-center gap-8 px-[clamp(20px,5vw,100px)]">
          <div className="grid grid-cols-[minmax(0,480px)_1fr] items-center gap-12">
            <div className="flex min-h-[320px] flex-col gap-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={phase}
                  initial={{ y: 16, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -16, opacity: 0 }}
                  transition={{ duration: D(0.25), ease: EASE }}
                  className="flex flex-col gap-6"
                >
                  {phase === 0 ? (
                    <>
                      <span className="sec-label">/ WHAT AI-NATIVE AND RELIABILITY ACTUALLY MEANS</span>
                      <h2 className="h2 max-w-[480px]">How we build AI-native, reliable systems</h2>
                      {INTRO_LEADS.map((p, i) => (
                        <p key={i} className="lead max-w-[440px]" style={{ fontSize: 16 }}>{p}</p>
                      ))}
                    </>
                  ) : (
                    <>
                      <div className="inline-flex items-center border border-[var(--line-1)] px-4 py-2 text-[13px] text-white/50 self-start">
                        <span>{phase} OF 6</span>
                      </div>
                      <h3 className="max-w-[420px] font-outfit text-[clamp(1.5rem,0.0002rem+2.0831vw,3.3331rem)] font-medium leading-[1.05]">{STEPS[phase - 1].n}</h3>
                      <div className="flex flex-col gap-4">
                        {STEPS[phase - 1].d.map((p, i) => (
                          <motion.p
                            key={`${phase}-${i}`}
                            initial={{ y: 14, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ duration: D(0.3), ease: EASE, delay: 0.08 + i * 0.09 }}
                            className="max-w-[440px] font-grotesk text-[16px] leading-[140%] tracking-[-0.02em] text-white/60"
                          >{p}</motion.p>
                        ))}
                        {STEPS[phase - 1].proof && (
                          <motion.p
                            key={`${phase}-proof`}
                            initial={{ y: 14, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ duration: D(0.3), ease: EASE, delay: 0.08 + STEPS[phase - 1].d.length * 0.09 }}
                            className="max-w-[440px] font-grotesk text-[16px] leading-[140%] tracking-[-0.02em] text-white/60 border-l-2 pl-4"
                            style={{ borderColor: '#00D46B' }}
                          ><span style={{ color: '#00D46B' }}>{STEPS[phase - 1].proof.tag}: </span>{STEPS[phase - 1].proof.text}</motion.p>
                        )}
                        {STEPS[phase - 1].coda && (
                          <motion.p
                            key={`${phase}-coda`}
                            initial={{ y: 14, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ duration: D(0.3), ease: EASE, delay: 0.17 + STEPS[phase - 1].d.length * 0.09 }}
                            className="max-w-[440px] font-grotesk text-[16px] leading-[140%] tracking-[-0.02em] font-medium"
                            style={{ color: '#00D46B' }}
                          >{STEPS[phase - 1].coda}</motion.p>
                        )}
                      </div>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="relative flex h-[440px] items-center justify-center lg:h-[520px]">
              {/* intro artwork (always mounted, shown per art state) */}
              <div
                className="absolute inset-0 flex items-center justify-center"
                style={{ opacity: art === 'intro' ? 1 : 0 }}
              >
                <IntroLoop />
              </div>
              {/* map artwork (always mounted, shown per art state) */}
              <div
                className="absolute inset-0 flex items-center justify-center"
                style={{ opacity: art === 'map' ? 1 : 0 }}
              >
                <StepVisual />
              </div>
              {/* step illustrations (always mounted, shown per art state) */}
              {[2, 3, 4, 5, 6].map((k) => (
                <div
                  key={k}
                  className="absolute inset-0 flex items-center justify-center"
                  style={{ opacity: art === 'img' + k ? 1 : 0 }}
                >
                  {k === 2 ? (
                    <ChooseApproachLoop />
                  ) : k === 3 ? (
                    <IntegrateLoop />
                  ) : k === 4 ? (
                    <PerformLoop />
                  ) : k === 5 ? (
                    <LearnLoop />
                  ) : k === 6 ? (
                    <GovernLoop />
                  ) : (
                    <img src={STEPS[k - 1].img} alt={STEPS[k - 1].n} className="w-auto" style={{ maxHeight: 300, maxWidth: '100%' }} />
                  )}
                </div>
              ))}
              {/* grid tiles: formed at rest, close over to hide swaps, reopen */}
              <div className="absolute inset-0 flex items-center justify-center" style={{ pointerEvents: 'none' }}>
                <div className="grid w-full max-w-[300px] grid-cols-4 gap-[4px] opacity-70" aria-hidden>
                  {Array.from({ length: 16 }, (_, i) => {
                    // mosaic is now transition cover only (phase 0 shows the
                    // harness loop); tiles close over swaps, then reopen
                    const formed = cover
                    const forming = false
                    return (
                      <motion.div
                        key={i}
                        className="mosaic-tile aspect-square rounded-[6px] border border-[var(--line-1)] bg-black"
                        initial={false}
                        animate={{
                          opacity: !entered ? 0 : formed ? 0.4 + (i % 3) * 0.3 : 0,
                          scale: !entered ? 0.5 : formed ? 1 : 0.6,
                        }}
                        transition={{
                          duration: D(forming ? 0.6 : 0.3),
                          ease: EASE,
                          delay: !entered ? 0 : forming ? i * 0.045 : i * (cover ? 0.015 : 0.02),
                        }}
                        style={{ animationDelay: `${(i * 0.28).toFixed(2)}s` }}
                      />
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <button onClick={() => jumpTo(Math.max(0, phase - 1))} disabled={phase === 0} aria-label="Previous step" className="h-10 w-10 border border-[var(--line-1)] text-white/60 transition hover:text-white disabled:cursor-not-allowed disabled:opacity-30">&lt;</button>
              <button onClick={() => jumpTo(Math.min(SLOTS - 1, phase + 1))} disabled={phase === SLOTS - 1} aria-label="Next step" className="h-10 w-10 border border-[var(--line-1)] text-white transition hover:bg-white hover:text-black disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-white">&gt;</button>
              <span className="ml-2 text-[12px] tracking-widest text-white/30">SCROLL TO EXPLORE</span>
            </div>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5, 6].map((k) => (
                <button key={k} onClick={() => jumpTo(k)} aria-label={`Go to step ${k}`} className="h-[3px] flex-1 bg-white/15">
                  <SegFill progress={scrollYProgress} from={k / SLOTS} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      </div>
      )}

      {/* ---------- mobile + reduced-motion: static stacked cards ---------- */}
      <div className={reduce ? '' : 'lg:hidden'}>
        <section className="section">
          <div className="wrap flex flex-col gap-8">
            <span className="sec-label">/ WHAT AI-NATIVE AND RELIABILITY ACTUALLY MEANS</span>
            <h2 className="h2">How we build AI-native, reliable systems</h2>
            {INTRO_LEADS.map((p, i) => (
              <p key={i} className="font-grotesk text-[var(--tt-s)] leading-[120%] tracking-[-0.02em] text-white/60 max-w-[640px]">{p}</p>
            ))}
            <IntroLoop />
          </div>
        </section>
        {STEPS.map((s, i) => (
          <section key={s.n} className="section">
            <div className="wrap flex flex-col gap-6">
              <div className="inline-flex items-center border border-[var(--line-1)] px-4 py-2 text-[13px] text-white/50 self-start">
                <span>{i + 1} OF 6</span>
              </div>
              <h3 className="font-outfit text-3xl font-medium leading-[1.05]" data-split>{s.n}</h3>
              <div className="flex flex-col gap-4">
                {s.d.map((p, j) => (
                  <p key={j} className="font-grotesk text-[var(--tt-s)] leading-[120%] tracking-[-0.02em] text-white/60">{p}</p>
                ))}
                {s.proof && (
                  <p className="font-grotesk text-[var(--tt-s)] leading-[140%] tracking-[-0.02em] text-white/60 border-l-2 pl-4" style={{ borderColor: '#00D46B' }}>
                    <span style={{ color: '#00D46B' }}>{s.proof.tag}: </span>{s.proof.text}
                  </p>
                )}
                {s.coda && (
                  <p className="font-grotesk text-[var(--tt-s)] leading-[120%] tracking-[-0.02em] font-medium" style={{ color: '#00D46B' }}>{s.coda}</p>
                )}
              </div>
              {i === 1 ? (
                <ChooseApproachLoop />
              ) : i === 2 ? (
                <IntegrateLoop />
              ) : i === 3 ? (
                <PerformLoop />
              ) : i === 4 ? (
                <LearnLoop />
              ) : i === 5 ? (
                <GovernLoop />
              ) : (
                <img src={s.img} alt={s.n} className="w-full object-contain" />
              )}
            </div>
          </section>
        ))}
      </div>
    </>
  )
}
