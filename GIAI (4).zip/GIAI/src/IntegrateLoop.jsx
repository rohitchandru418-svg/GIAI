import { useEffect, useRef } from 'react'
import integrateUrl from '../asset/Integrate into your existing operations.svg'

/* ------------------------------------------------------------------
   Integrate into your existing operations — continuous loop, in place.
   No redraw, no viewBox change. Only transforms / opacity / stroke /
   fill on EXISTING nodes (+ clones of existing diamonds).

   Loop story (free-running single clock, soft pulses — icons tint,
   borders stay authored):
     1. White diamonds (Decoration..5) rain from the top tile down
        into the INTEGRATE card, staggered, fading as absorbed.
     2. INTEGRATE card softly lifts on each landing; its label
        brightens.
     3. Packets travel three lanes: left vertical (x61) down into the
        AGENT tile, middle vertical (x303) down into the WORKFLOW
        card, horizontal (y303) right into the WORKFLOW card.
     4. WORKFLOW nodes activate in sequence; status checks pop in AND
        out on their own random clocks like the raining diamonds —
        both tint white->green on activation (icons, not borders).
        AGENT icon cluster + labels breathe with arrivals.
     5. Green featured tile roams freely behind the tile grid.
     6. Handoff stage: a green diamond drops down x182 into the HUMAN
        HANDOFF card (Capability Card_2), which flares with its
        List-Checked icon; white/green diamonds leave via the bottom
        connectors (Vector 91_3 left-up into AGENT, Vector 91_4
        right-up), and all three wires drift.
------------------------------------------------------------------- */

const FALL_PERIOD = 2.4
const LANE_PERIOD = 2.8
const HORIZ_PERIOD = 3.0
const NODE_PERIOD = 4.0
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

const GREEN = [0, 212, 107]
const BLUE = [59, 130, 246]
const mixWhite = (target, k) => {
  const c = Math.max(0, Math.min(1, k))
  const r = Math.round(255 + (target[0] - 255) * c)
  const g = Math.round(255 + (target[1] - 255) * c)
  const b = Math.round(255 + (target[2] - 255) * c)
  return 'rgb(' + r + ',' + g + ',' + b + ')'
}

export default function IntegrateLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(integrateUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const NS = 'http://www.w3.org/2000/svg'

        const integrateCard = byId('Capability Tile_6')
        const integrateLabel = byId('Label')
        const agentTile = byId('Intelligence Tile')
        const agentIcon = byId('Icon')
        const agentLabel = byId('Label_2')
        const agentDetails = ['Icon Detail', 'Icon Detail_2', 'Icon Detail_3', 'Icon Detail_4', 'Icon Detail_5']
          .map(byId)
          .filter(Boolean)
          .map((el, i) => {
            const v = parseFloat(el.getAttribute('opacity'))
            return { el, base: Number.isFinite(v) ? v : 1, i }
          })
        const workflowCard = byId('Capability Card')
        const workflowIcon = byId('Workflow Icon')
        const workflowLabel = byId('Capability Name')
        const featured = byId('Featured Capability')
        const wireL = byId('Vector 91')
        const wireM = byId('Vector 91_2')
        const wireH = byId('Vector 91_3')
        const wireV = byId('Vector 92')
        const wireH4 = byId('Vector 91_4')
        const card2Tile = byId('Capability Card_2')
        const card2Label = byId('Capability Name_2')
        const listIcon = byId('List-Checked--Streamline-Carbon')

        const nodeIds = ['Workflow Node', 'Workflow Node_2', 'Workflow Node_3', 'Workflow Node_4']
        const nodes = nodeIds
          .map(byId)
          .filter(Boolean)
          .map((el, i) => {
            const strokes = Array.from(el.querySelectorAll('rect[stroke]'))
            return { el, strokes, i }
          })
        const statusIds = ['Status Indicator', 'Status Indicator_2', 'Status Indicator_3']
        const statuses = statusIds
          .map(byId)
          .filter(Boolean)
          .map((el, i) => {
            const v = parseFloat(el.getAttribute('opacity'))
            const circle = el.querySelector('circle')
            return { el, circle, base: Number.isFinite(v) ? v : 1, i }
          })

        ;[integrateCard, agentTile, workflowCard, card2Tile].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        ;[agentIcon, workflowIcon, featured, listIcon].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        agentDetails.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        nodes.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        statuses.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })

        const agentIconRect = agentIcon ? agentIcon.querySelector('rect') : null
        const agentDetailRects = agentDetails.flatMap(({ el }) => Array.from(el.querySelectorAll('rect')))
        const workflowIconRect = workflowIcon ? workflowIcon.querySelector('rect') : null

        const integrateLabelBase = integrateLabel ? parseFloat(integrateLabel.getAttribute('opacity')) || 0.56 : 0.56
        const agentLabelBase = agentLabel ? parseFloat(agentLabel.getAttribute('opacity')) || 0.56 : 0.56
        const workflowLabelBase = workflowLabel ? parseFloat(workflowLabel.getAttribute('opacity')) || 0.56 : 0.56
        const card2LabelBase = card2Label ? parseFloat(card2Label.getAttribute('opacity')) || 0.56 : 0.56

        if (REDUCED) return

        /* ---- falling whites: escape the clipped top tile ---- */
        const overlay = document.createElementNS(NS, 'g')
        overlay.setAttribute('id', 'integrate-loop-overlay')
        svg.appendChild(overlay)

        const fallIds = ['Decoration', 'Decoration_2', 'Decoration_3', 'Decoration_4', 'Decoration_5']
        const fallers = []
        fallIds.forEach((id, i) => {
          const el = byId(id)
          if (!el) return
          const wrap = document.createElementNS(NS, 'g')
          if (el.parentNode) el.parentNode.insertBefore(wrap, el)
          wrap.appendChild(el)
          overlay.appendChild(wrap)
          let baseOp = parseFloat(el.getAttribute('opacity'))
          if (!Number.isFinite(baseOp)) baseOp = 1
          fallers.push({ wrap, el, baseOp, off: i / fallIds.length, prev: 0 })
        })

        /* ---- lane packets: small white diamonds cloned from a faller ---- */
        const seed = fallers.length ? fallers[fallers.length - 1].el : null
        const mkPacket = () => {
          const r = document.createElementNS(NS, 'rect')
          r.setAttribute('width', '6')
          r.setAttribute('height', '6')
          r.setAttribute('fill', 'white')
          r.setAttribute('opacity', '0.9')
          overlay.appendChild(r)
          return r
        }
        void seed
        // arc-length follower for L-shaped bottom connectors
        const follower = (pts) => {
          const segs = [0]
          let total = 0
          for (let i = 1; i < pts.length; i++) {
            total += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
            segs.push(total)
          }
          return (t) => {
            if (total <= 0) return { x: pts[0][0], y: pts[0][1] }
            const d = ((((t % 1) + 1) % 1) + 1) % 1 * total
            for (let i = 1; i < pts.length; i++) {
              if (d <= segs[i]) {
                const span = segs[i] - segs[i - 1] || 1
                const k = (d - segs[i - 1]) / span
                return { x: pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * k, y: pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * k }
              }
            }
            const l = pts[pts.length - 1]
            return { x: l[0], y: l[1] }
          }
        }
        const laneL = [mkPacket(), mkPacket()]
        const laneM = [mkPacket(), mkPacket()]
        const laneH = [mkPacket(), mkPacket()]
        const laneD = [mkPacket(), mkPacket()]
        const laneB3 = [mkPacket(), mkPacket()]
        const laneB4 = [mkPacket(), mkPacket()]
        const lanes = [
          ...laneL.map((el, k) => ({ el, kind: 'L', off: k / 2, prev: 0 })),
          ...laneM.map((el, k) => ({ el, kind: 'M', off: k / 2, prev: 0 })),
          ...laneH.map((el, k) => ({ el, kind: 'H', off: k / 2, prev: 0 })),
          ...laneD.map((el, k) => ({ el, kind: 'D', off: k / 2, prev: 0, fn: follower([[182, 244], [182, 363]]) })),
          ...laneB3.map((el, k) => ({ el, kind: 'B3', off: k / 2, prev: 0, fn: follower([[121, 424], [61, 424], [61, 365]]) })),
          ...laneB4.map((el, k) => ({ el, kind: 'B4', off: (k / 2 + 0.25) % 1, prev: 0, fn: follower([[243, 424], [303, 424], [303, 365]]) })),
        ]
        laneB4.forEach((o) => {
          try {
            o.el.setAttribute('fill', '#00D46B')
          } catch (e) {}
        })

        const lanePos = (kind, t) => {
          if (kind === 'L') return { x: 61, y: 122 + t * 120 }
          if (kind === 'M') return { x: 303, y: 122 + t * 120 }
          return { x: 122 + t * 121, y: 303 }
        }

        /* ---- dashed flow overlays (authored wires are gradient fills) ---- */
        const mkFlow = (d, color) => {
          try {
            const p = document.createElementNS(NS, 'path')
            p.setAttribute('d', d)
            p.setAttribute('fill', 'none')
            p.setAttribute('stroke', color)
            p.setAttribute('stroke-width', '1.2')
            p.setAttribute('stroke-dasharray', '4 8')
            p.setAttribute('stroke-linecap', 'round')
            p.setAttribute('opacity', '0.35')
            p.setAttribute('pointer-events', 'none')
            overlay.appendChild(p)
            return p
          } catch (e) {
            return null
          }
        }
        const flowL = mkFlow('M61 122 V242', '#FFFFFF')
        const flowM = mkFlow('M303 122 V242', '#FFFFFF')
        const flowH = mkFlow('M122 303 H243', '#00D46B')

        let integratePulse = 0
        let agentPulse = 0
        let workflowPulse = 0
        let handPulse = 0
        let dash = 0
        let last = performance.now()
        const t0 = last

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const t = (now - t0) / 1000

          /* falling whites -> INTEGRATE */
          fallers.forEach((f) => {
            const ph = (((t / FALL_PERIOD + f.off) % 1) + 1) % 1
            if (ph < f.prev && f.prev - ph > 0.5) integratePulse = Math.min(integratePulse + 0.9, 1.5)
            f.prev = ph
            const dy = -60 + ph * 165
            f.wrap.setAttribute('transform', 'translate(0 ' + dy.toFixed(1) + ')')
            let op = f.baseOp
            if (ph < 0.14) op *= ph / 0.14
            else if (ph > 0.72) op *= Math.max(0, 1 - (ph - 0.72) / 0.28)
            f.el.setAttribute('opacity', op.toFixed(3))
          })

          /* lane packets -> AGENT / WORKFLOW */
          lanes.forEach((o) => {
            const period = o.kind === 'H' ? HORIZ_PERIOD : o.kind === 'D' ? 2.4 : o.kind === 'B3' || o.kind === 'B4' ? 3.4 : LANE_PERIOD
            const ph = (((t / period + o.off) % 1) + 1) % 1
            if (ph < o.prev && o.prev - ph > 0.5) {
              if (o.kind === 'L') agentPulse = Math.min(agentPulse + 1, 1.5)
              else if (o.kind === 'D') handPulse = Math.min(handPulse + 0.7, 1.5)
              else if (o.kind === 'B3') agentPulse = Math.min(agentPulse + 0.4, 1.5)
              else if (o.kind === 'B4') handPulse = Math.min(handPulse + 0.5, 1.5)
              else workflowPulse = Math.min(workflowPulse + 0.8, 1.5)
            }
            o.prev = ph
            const p = o.fn ? o.fn(ph) : lanePos(o.kind, ph)
            o.el.setAttribute('x', p.x.toFixed(1))
            o.el.setAttribute('y', p.y.toFixed(1))
            o.el.setAttribute('transform', 'rotate(45 ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ')')
            let op = 1
            if (ph < 0.1) op = ph / 0.1
            else if (ph > 0.85) op = Math.max(0, 1 - (ph - 0.85) / 0.15)
            o.el.setAttribute('opacity', (0.3 + 0.7 * op).toFixed(3))
          })

          dash -= dt * 24
          ;[flowL, flowM, flowH].forEach((f) => {
            if (f) f.setAttribute('stroke-dashoffset', dash.toFixed(1))
          })
          ;[wireL, wireM, wireH, wireV, wireH4].forEach((w, i) => {
            if (!w) return
            w.setAttribute('opacity', (0.18 + 0.1 * (0.5 + 0.5 * Math.sin(t * 2.0 + i * 1.2))).toFixed(3))
            try {
              w.setAttribute('stroke-dashoffset', (dash * 1.4).toFixed(1))
            } catch (e) {}
          })

          integratePulse *= Math.pow(0.06, dt)
          agentPulse *= Math.pow(0.06, dt)
          workflowPulse *= Math.pow(0.06, dt)
          handPulse *= Math.pow(0.06, dt)

          /* ---- INTEGRATE card: soft lift + label glow ---- */
          if (integrateCard) {
            const s = 1 + Math.min(integratePulse, 1) * 0.012 + Math.sin(t * 2.4) * 0.003
            integrateCard.style.transform = 'scale(' + s.toFixed(4) + ')'
          }
          if (integrateLabel) {
            const glow = Math.min(integratePulse, 1) * 0.18 + (0.5 + 0.5 * Math.sin(t * 2.1)) * 0.06
            integrateLabel.setAttribute('opacity', Math.min(1, integrateLabelBase + glow).toFixed(3))
          }
          if (featured) {
            // green tile roams freely behind the tile grid (tiles stay
            // put — green light drifts through the gaps between them)
            const fx = 120 + 120 * Math.sin(t * 0.33 + 0.4) + 38 * Math.sin(t * 0.81 + 1.2)
            const fy = 130 + 105 * Math.sin(t * 0.45 + 0.9) + 30 * Math.sin(t * 0.89 + 0.3)
            featured.setAttribute('x', Math.max(0, Math.min(363, fx)).toFixed(1))
            featured.setAttribute('y', Math.max(0, Math.min(363, fy)).toFixed(1))
            featured.setAttribute('opacity', (0.8 + Math.sin(t * 1.8) * 0.12 + Math.min(integratePulse, 1) * 0.08).toFixed(3))
          }

          /* ---- AGENT cluster ---- */
          if (agentTile) {
            agentTile.style.transform = 'scale(' + (1 + Math.min(agentPulse, 1) * 0.012).toFixed(4) + ')'
          }
          if (agentIcon) {
            agentIcon.style.transform =
              'rotate(' + ((t * 12) % 360).toFixed(1) + 'deg) scale(' + (1 + Math.sin(t * 2.4) * 0.025 + Math.min(agentPulse, 1) * 0.04).toFixed(3) + ')'
          }
          if (agentIconRect) {
            try {
              agentIconRect.setAttribute('stroke', mixWhite(BLUE, Math.min(agentPulse, 1) * 0.9))
            } catch (e) {}
          }
          agentDetails.forEach(({ el, base, i }) => {
            const w = 0.5 + 0.5 * Math.sin(t * 2.6 + i * 1.1)
            el.style.transform = 'scale(' + (1 + w * 0.1 + Math.min(agentPulse, 1) * 0.08).toFixed(3) + ')'
            el.setAttribute('opacity', Math.min(1, base * (0.85 + w * 0.3) + Math.min(agentPulse, 1) * 0.15).toFixed(3))
          })
          if (agentDetailRects.length) {
            const col = mixWhite(BLUE, Math.min(agentPulse, 1) * 0.9)
            agentDetailRects.forEach((r) => {
              try {
                if (r.getAttribute('fill') !== null) r.setAttribute('fill', col)
                else r.setAttribute('stroke', col)
              } catch (e) {}
            })
          }
          if (agentLabel) {
            const glow = (0.5 + 0.5 * Math.sin(t * 2.6 + 0.8)) * 0.07 + Math.min(agentPulse, 1) * 0.18
            agentLabel.setAttribute('opacity', Math.min(1, agentLabelBase + glow).toFixed(3))
          }

          /* ---- WORKFLOW card: nodes sequence, icon + label breathe ---- */
          if (workflowCard) {
            workflowCard.style.transform = 'scale(' + (1 + Math.min(workflowPulse, 1) * 0.012 + Math.sin(t * 2.2) * 0.003).toFixed(4) + ')'
          }
          const nodePh = (t % NODE_PERIOD) / NODE_PERIOD
          const activeNode = Math.floor(nodePh * nodes.length) % nodes.length
          nodes.forEach(({ el, strokes, i }) => {
            const on = i === activeNode
            const trail = i === (activeNode + nodes.length - 1) % nodes.length
            const k = on ? 1 : trail ? 0.35 : 0
            el.style.transform = 'scale(' + (1 + k * 0.14).toFixed(3) + ')'
            strokes.forEach((s) => {
              try {
                s.setAttribute('stroke', mixWhite(GREEN, k * 0.95))
                s.setAttribute('stroke-opacity', (on ? 1 : 0.6).toFixed(2))
              } catch (e) {}
            })
          })
          if (workflowIcon) {
            workflowIcon.style.transform = 'scale(' + (1 + Math.sin(t * 2.3) * 0.03 + Math.min(workflowPulse, 1) * 0.05).toFixed(3) + ')'
            workflowIcon.setAttribute('opacity', (0.43 + (0.5 + 0.5 * Math.sin(t * 2.3)) * 0.12 + Math.min(workflowPulse, 1) * 0.2).toFixed(3))
          }
          if (workflowIconRect) {
            try {
              workflowIconRect.setAttribute('stroke', mixWhite(GREEN, Math.min(workflowPulse, 1) * 0.85))
            } catch (e) {}
          }
          if (workflowLabel) {
            const glow = (0.5 + 0.5 * Math.sin(t * 2.5)) * 0.07 + Math.min(workflowPulse, 1) * 0.18
            workflowLabel.setAttribute('opacity', Math.min(1, workflowLabelBase + glow).toFixed(3))
          }

          /* ---- status checks: random rain-like pop in AND out ---- */
          statuses.forEach(({ el, circle, i }) => {
            // independent clock per check: differing periods + offsets so
            // pops desync, overlap and feel random like the diamond rain
            const period = 2.4 + i * 0.83 + (i % 2) * 0.37
            const off = (i * 0.41 + 0.17) % 1
            const pp = (((t / period + off) % 1) + 1) % 1
            let k
            if (pp < 0.15) {
              const q = pp / 0.15
              k = 1 - Math.pow(1 - q, 3)
            } else if (pp < 0.45) k = 1
            else if (pp < 0.65) k = 1 - (pp - 0.45) / 0.2
            else k = 0
            k = Math.max(0, Math.min(1, k))
            // in-place pop only — no drift, so checks stay pinned to
            // their home spots on the right tile (never slide from workflow)
            el.style.transform = 'scale(' + (0.8 + 0.36 * k).toFixed(3) + ')'
            el.setAttribute('opacity', k.toFixed(3))
            if (circle) {
              try {
                circle.setAttribute('fill', mixWhite(GREEN, Math.min(1, k * 1.1) * 0.95))
              } catch (e) {}
            }
          })

          /* ---- HUMAN HANDOFF card: flares on arrivals + dispatches ---- */
          if (card2Tile) {
            card2Tile.style.transform = 'scale(' + (1 + Math.min(handPulse, 1) * 0.014).toFixed(4) + ')'
          }
          if (card2Label) {
            card2Label.setAttribute('opacity', Math.min(1, card2LabelBase + Math.min(handPulse, 1) * 0.2 + 0.05).toFixed(3))
          }
          if (listIcon) {
            listIcon.style.transform = 'scale(' + (1 + Math.min(handPulse, 1) * 0.12).toFixed(3) + ')'
            try {
              listIcon.querySelectorAll('[stroke]').forEach((s) => {
                const c = (s.getAttribute('stroke') || '').toLowerCase()
                if (c === 'white' || c === '#ffffff') s.setAttribute('stroke', mixWhite(GREEN, Math.min(handPulse, 1) * 0.85))
              })
              listIcon.querySelectorAll('[fill]').forEach((s) => {
                const c = (s.getAttribute('fill') || '').toLowerCase()
                if (c === 'white' || c === '#ffffff') s.setAttribute('fill', mixWhite(GREEN, Math.min(handPulse, 1) * 0.85))
              })
            } catch (e) {}
          }

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = integrateUrl
        img.alt = 'Integrate into your existing operations'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
