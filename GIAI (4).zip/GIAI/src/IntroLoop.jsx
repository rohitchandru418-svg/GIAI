import { useEffect, useRef } from 'react'
import introUrl from '../asset/Intro.svg'

/* ------------------------------------------------------------------
   Intro — the How-We-Build opener, in place. No redraw, no viewBox
   change. Only transforms / opacity / stroke / fill on EXISTING nodes
   (+ clones of existing diamonds + rain diamonds for continuity).

   Loop story (free-running 7.2s narrative clock — soft pulses, icons
   tint, borders stay authored):
     - FEED [0-2s]: white diamonds rain/stream into AGENT (raw work:
       instructions, context, tools).
     - CARRY [2-3.6s]: a hero diamond is carried AGENT -> SELF-CHECK.
     - VERIFY [3.6-4.6s]: it holds at SELF-CHECK while the card flashes
       white — the harness checking its own results.
     - DELIVER [4.6-6.2s]: verified, it turns GREEN and travels to
       OUTCOME, whose badge pops — AI you can rely on.
   White = unverified work; green = verified, reliable. Ambient lanes,
   icon life and label glows run underneath throughout.
------------------------------------------------------------------- */

const FALL_PERIOD = 2.4
const LANE_PERIOD = 3.0
const BUS_PERIOD = 2.8
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

const BLUE = '#3B82F6'
const GREEN = '#00D46B'

// arc-length follower over waypoint polyline
const follower = (pts) => {
  const segs = [0]
  let total = 0
  for (let i = 1; i < pts.length; i++) {
    total += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
    segs.push(total)
  }
  return (t) => {
    if (total <= 0) return { x: pts[0][0], y: pts[0][1] }
    const d = ((((t % 1) + 1) % 1) + 1) % 1 * total
    for (let i = 1; i < pts.length; i++) {
      if (d <= segs[i]) {
        const span = segs[i] - segs[i - 1] || 1
        const k = (d - segs[i - 1]) / span
        return { x: pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * k, y: pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * k }
      }
    }
    const l = pts[pts.length - 1]
    return { x: l[0], y: l[1] }
  }
}

const LANES = {
  feed: { pts: [[122, 61], [61, 61], [61, 242]], period: LANE_PERIOD }, // top -> intelligence
  bus: { pts: [[303, 61], [303, 303], [363, 303]], period: BUS_PERIOD }, // top -> check card
  lowL: { pts: [[61, 364], [61, 424], [121, 424]], period: LANE_PERIOD }, // intelligence -> workflow
  lowM: { pts: [[121, 303], [182, 303], [182, 363]], period: BUS_PERIOD }, // intelligence -> workflow
}

// hero journey waypoints (art units): held at SELF-CHECK, then delivered
// along authored ink — down through the card, out its right edge, up the
// Vector 92 bus (243,423)->(303,423)->(303,303) and right into OUTCOME
const CYCLE = 7.2
const HOLD_PT = { x: 182, y: 363 }
const DELIVER_PTS = [[182, 363], [182, 423], [243, 423], [303, 423], [303, 303], [363, 303]]

export default function IntroLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(introUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = '300px'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const NS = 'http://www.w3.org/2000/svg'

        const routeTile = byId('Intelligence Tile_3')
        const checkCard = byId('Capability Card')
        const flowCard = byId('Capability Card_2')
        const checkBadge = byId('Check-Badge--Streamline-Ultimate')
        const featBar = byId('Featured Capability')
        const wires = ['Vector 91', 'Vector 91_2', 'Vector 92', 'Vector 92_2'].map(byId).filter(Boolean)

        const collect = (root) => {
          if (!root) return { icons: [], labels: [], base: [] }
          const icons = Array.from(root.querySelectorAll('g[id*="Icon"]')).filter((el) => !el.getAttribute('transform'))
          icons.forEach((el) => {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          })
          const labels = Array.from(root.querySelectorAll('path[id^="Label"]')).map((el) => {
            const v = parseFloat(el.getAttribute('opacity'))
            return { el, base: Number.isFinite(v) ? v : 1 }
          })
          return { icons, labels }
        }
        const routeFx = collect(routeTile)
        const checkFx = collect(checkCard)
        const flowFx = collect(flowCard)

        ;[routeTile, checkCard, flowCard].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        if (checkBadge) {
          checkBadge.style.transformBox = 'fill-box'
          checkBadge.style.transformOrigin = 'center'
        }

        // ambient icon movers: wrapper-guarded so CSS motion never
        // overrides an authored transform attribute on these groups
        const prepMover = (el) => {
          if (!el) return null
          if (el.getAttribute('transform')) {
            const wrap = document.createElementNS(NS, 'g')
            if (el.parentNode) el.parentNode.insertBefore(wrap, el)
            wrap.appendChild(el)
            wrap.style.transformBox = 'fill-box'
            wrap.style.transformOrigin = 'center'
            return wrap
          }
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
          return el
        }
        const topDoc = prepMover(byId('New-File--Streamline-Flex'))
        const topGears = prepMover(byId('Gears--Streamline-Carbon'))
        const flowIcon = prepMover(byId('List-Checked--Streamline-Carbon'))

        if (REDUCED) return

        const overlay = document.createElementNS(NS, 'g')
        overlay.setAttribute('id', 'intro-loop-overlay')
        svg.appendChild(overlay)

        const mkDiamond = (size, fill) => {
          const r = document.createElementNS(NS, 'rect')
          r.setAttribute('width', String(size))
          r.setAttribute('height', String(size))
          r.setAttribute('fill', fill)
          overlay.appendChild(r)
          return r
        }
        const drive = (el, p, op) => {
          el.setAttribute('x', p.x.toFixed(1))
          el.setAttribute('y', p.y.toFixed(1))
          el.setAttribute('transform', 'rotate(45 ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ')')
          el.setAttribute('opacity', op.toFixed(3))
        }
        const endFade = (ph) => {
          if (ph < 0.08) return ph / 0.08
          if (ph > 0.86) return Math.max(0, 1 - (ph - 0.86) / 0.14)
          return 1
        }

        /* ---- rain into INTELLIGENCE ---- */
        const RAIN_X = [45, 56, 66, 77]
        const RAIN_F = ['white', 'white', 'white', BLUE]
        const rain = RAIN_X.map((x, i) => ({
          el: mkDiamond(5 + (i % 2), RAIN_F[i]),
          x,
          off: i / RAIN_X.length,
          prev: 0,
        }))

        /* ---- lane travellers (authored markers lead their lanes) ---- */
        const prep = (el) => {
          if (!el) return null
          el.removeAttribute('transform')
          return el
        }
        const lane = (key, headId, fills) => {
          const out = []
          const head = headId ? prep(byId(headId)) : null
          if (head) {
            try {
              overlay.appendChild(head)
            } catch (e) {}
            out.push({ el: head, off: 0 })
          }
          const total = (head ? 1 : 0) + fills.length
          fills.forEach((fill, k) => {
            let c
            if (head) {
              c = head.cloneNode(true)
              c.removeAttribute('id')
              if (fill) {
                try {
                  c.setAttribute('fill', fill)
                } catch (e) {}
              }
            } else {
              c = mkDiamond(5, fill || 'white')
            }
            overlay.appendChild(c)
            out.push({ el: c, off: out.length / total })
          })
          out.forEach((o) => {
            o.prev = 0
            o.fn = follower(LANES[key].pts)
            o.period = LANES[key].period
          })
          return out
        }
        const feedLane = lane('feed', 'Capability Marker', ['white', 'white'])
        const busLane = lane('bus', null, ['white', 'white', 'white'])
        const lowLLane = lane('lowL', 'Capability Marker_2', [BLUE, BLUE])
        const lowMLane = lane('lowM', 'Capability Marker_3', ['white', 'white'])
        const heroFn = follower(DELIVER_PTS)
        const carryFn = follower(LANES.lowM.pts)
        const hero = mkDiamond(7, 'white')

        let routePulse = 0
        let checkPulse = 0
        let flowPulse = 0
        let winHeat = 0
        let selfV = 0
        let won = false
        const dashRef = { v: 0 }
        let last = performance.now()
        const t0 = last

        const runLane = (t, list, onArrive) => {
          list.forEach((o) => {
            const ph = (((t / o.period + o.off) % 1) + 1) % 1
            if (ph < o.prev && o.prev - ph > 0.5 && onArrive) onArrive()
            o.prev = ph
            drive(o.el, o.fn(ph), 0.35 + 0.65 * endFade(ph))
          })
        }

        const glow = (fx, pulse, t, tint) => {
          fx.labels.forEach(({ el, base }) => {
            el.setAttribute('opacity', Math.min(1, base + pulse * 0.4 + (0.5 + 0.5 * Math.sin(t * 2.2)) * 0.06).toFixed(3))
          })
          const tintShapes = (root) => {
            try {
              const shapes = root.querySelectorAll('rect[fill], circle[fill], path[fill]')
              shapes.forEach((s) => {
                if ((s.getAttribute('fill') || '').toLowerCase() === 'white') s.setAttribute('fill', pulse > 0.2 ? tint : 'white')
              })
            } catch (e) {}
          }
          fx.icons.forEach((el) => tintShapes(el))
        }

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          const t = (now - t0) / 1000
          const cycleT = (((t % CYCLE) + CYCLE) % CYCLE)

          /* rain -> INTELLIGENCE */
          rain.forEach((f) => {
            const ph = (((t / FALL_PERIOD + f.off) % 1) + 1) % 1
            if (ph < f.prev && f.prev - ph > 0.5) routePulse = Math.min(routePulse + 0.9, 1.5)
            f.prev = ph
            const y = 120 + ph * 125
            drive(f.el, { x: f.x, y }, 0.3 + 0.7 * endFade(ph))
          })

          runLane(t, feedLane, () => {
            routePulse = Math.min(routePulse + 0.5, 1.5)
          })
          runLane(t, busLane, () => {
            checkPulse = Math.min(checkPulse + 0.4, 1.5)
          })
          runLane(t, lowLLane, () => {
            flowPulse = Math.min(flowPulse + 0.8, 1.5)
          })
          runLane(t, lowMLane, () => {
            flowPulse = Math.min(flowPulse + 0.8, 1.5)
          })

          /* hero diamond: carried -> verified -> delivered, once per cycle */
          if (cycleT < 1.0) {
            won = false
          }
          if (cycleT >= 2.0 && cycleT < 3.6) {
            const hp = (cycleT - 2.0) / 1.6
            hero.setAttribute('fill', 'white')
            drive(hero, carryFn(hp), 0.9 * endFade(hp))
          } else if (cycleT >= 3.6 && cycleT < 4.6) {
            hero.setAttribute('fill', 'white')
            drive(hero, HOLD_PT, 0.95)
          } else if (cycleT >= 4.6 && cycleT < 6.2) {
            const hp = (cycleT - 4.6) / 1.6
            hero.setAttribute('fill', GREEN)
            drive(hero, heroFn(hp), 0.95 * endFade(hp))
            if (!won) {
              won = true
              winHeat = 1
            }
          } else {
            hero.setAttribute('opacity', '0')
          }

          wires.forEach((w, i) => {
            w.setAttribute('opacity', (0.2 + 0.08 * (0.5 + 0.5 * Math.sin(t * 2.2 + i * 1.3))).toFixed(3))
            w.setAttribute('stroke-dashoffset', dashRef.v.toFixed(1))
          })
          if (featBar) {
            // green backing bar roams freely behind the tile grid —
            // it reads through seams and tile gaps as shifting green light
            const fx = 60 + 90 * Math.sin(t * 0.33 + 0.4) + 30 * Math.sin(t * 0.81 + 1.2)
            const fy = 200 + 80 * Math.sin(t * 0.45 + 0.9) + 25 * Math.sin(t * 0.89 + 0.3)
            featBar.setAttribute('x', Math.max(0, Math.min(307, fx)).toFixed(1))
            featBar.setAttribute('y', Math.max(0, Math.min(307, fy)).toFixed(1))
            featBar.setAttribute('opacity', (0.75 + 0.2 * (0.5 + 0.5 * Math.sin(t * 1.8))).toFixed(3))
          }

          routePulse *= Math.pow(0.06, dt)
          checkPulse *= Math.pow(0.06, dt)
          flowPulse *= Math.pow(0.06, dt)
          winHeat *= Math.pow(0.55, dt)
          dashRef.v -= dt * 24
          const rp = Math.min(routePulse, 1)
          const cp = Math.min(checkPulse, 1)
          const fp = Math.min(flowPulse, 1)
          const wp = Math.min(winHeat, 1)

          if (routeTile) {
            routeTile.style.transform = 'scale(' + (1 + rp * 0.016 + Math.sin(t * 2.4) * 0.003).toFixed(4) + ')'
          }
          glow(routeFx, rp, t, BLUE)
          if (checkCard) {
            checkCard.style.transform = 'scale(' + (1 + wp * 0.016).toFixed(4) + ')'
          }
          glow(checkFx, cp, t, GREEN)
          if (checkBadge) {
            checkBadge.style.transform = 'scale(' + ((1 + wp * 0.18) * (1 + 0.03 * Math.sin(t * 2.2))).toFixed(3) + ')'
            checkBadge.setAttribute('opacity', (0.35 + 0.65 * wp).toFixed(3))
          }
          if (flowCard) {
            flowCard.style.transform = 'scale(' + (1 + fp * 0.012).toFixed(4) + ')'
          }
          glow(flowFx, fp, t, GREEN)
          selfV += ((((cycleT >= 3.6 && cycleT < 4.6) ? 1 : 0)) - selfV) * Math.min(1, dt * 5)
          if (flowCard && selfV > 0.02) {
            flowCard.style.filter = 'drop-shadow(0 0 ' + (14 * selfV).toFixed(1) + 'px rgba(255,255,255,' + (0.3 * selfV).toFixed(3) + '))'
          } else if (flowCard) {
            flowCard.style.filter = ''
          }

          /* ambient icon life — continuous motion between arrivals */
          if (routeFx.icons[0]) {
            routeFx.icons[0].style.transform =
              'rotate(' + (((t * 20) % 360).toFixed(1)) + 'deg) scale(' + (1 + rp * 0.08).toFixed(3) + ')'
          }
          routeFx.icons.slice(1).forEach((el, i) => {
            el.style.transform = 'scale(' + (1 + (0.5 + 0.5 * Math.sin(t * 2.6 + i * 1.1)) * 0.09 + rp * 0.05).toFixed(3) + ')'
          })
          if (topDoc) topDoc.style.transform = 'translateY(' + (Math.sin(t * 1.8) * 2.5).toFixed(2) + 'px)'
          if (topGears) topGears.style.transform = 'rotate(' + (((t * 15) % 360).toFixed(1) + 'deg)')
          if (flowIcon) {
            flowIcon.style.transform =
              'rotate(' + (Math.sin(t * 1.6) * 4).toFixed(2) + 'deg) scale(' + (1 + fp * 0.05).toFixed(3) + ')'
          }

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = introUrl
        img.alt = 'Intro'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
