import { useEffect, useRef } from 'react'
import learnUrl from '../asset/Design systems that learn automatically.svg'

/* ------------------------------------------------------------------
   Design systems that learn automatically — a learning loop, in place.
   No redraw, no viewBox change. Only transforms / opacity / stroke /
   fill on EXISTING nodes.

   Loop story (single clock — borders tint green here by request):
     1. The green tile runs a loop INTELLIGENCE -> DECISION ->
        FEEDBACK -> WORKFLOW -> back to INTELLIGENCE, dwelling briefly
        on each card; each border tints green as green passes over it.
     2. The active card softly lifts while its icons tint white->green
        and its label brightens (all driven by green's proximity).
     3. Workflow grid points fire in sequence; intelligence symbols
        breathe/rotate; feedback core pulses; decision user icon floats.
------------------------------------------------------------------- */

const GREEN = [0, 212, 107]
const mixWhite = (target, k) => {
  const c = Math.max(0, Math.min(1, k))
  const r = Math.round(255 + (target[0] - 255) * c)
  const g = Math.round(255 + (target[1] - 255) * c)
  const b = Math.round(255 + (target[2] - 255) * c)
  return 'rgb(' + r + ',' + g + ',' + b + ')'
}
const NODE_PERIOD = 4
// green circuit through the card centers (counterclockwise):
// intelligence -> decision -> feedback -> workflow -> intelligence
const LOOP_WPTS = [[424, 182], [303, 424], [61, 303], [182, 61]]
const LOOP_TRAVEL = 7
const LOOP_DWELL = 0.5
const LOOP_PERIOD = LOOP_TRAVEL + LOOP_DWELL * 4
const SEG_TOTAL = (() => {
  let L = 0
  for (let i = 0; i < LOOP_WPTS.length; i++) {
    const a = LOOP_WPTS[i]
    const b = LOOP_WPTS[(i + 1) % LOOP_WPTS.length]
    L += Math.hypot(b[0] - a[0], b[1] - a[1])
  }
  return L
})()
// position on the circuit for a loop phase ph in [0,1)
function loopPos(ph) {
  let tt = ph * LOOP_PERIOD
  for (let i = 0; i < LOOP_WPTS.length; i++) {
    const a = LOOP_WPTS[i]
    const b = LOOP_WPTS[(i + 1) % LOOP_WPTS.length]
    const segLen = Math.hypot(b[0] - a[0], b[1] - a[1])
    const dur = (segLen / SEG_TOTAL) * LOOP_TRAVEL
    if (tt < dur) {
      const k = dur === 0 ? 0 : tt / dur
      return { x: a[0] + (b[0] - a[0]) * k, y: a[1] + (b[1] - a[1]) * k }
    }
    tt -= dur
    if (tt < LOOP_DWELL) return { x: b[0], y: b[1] }
    tt -= LOOP_DWELL
  }
  return { x: LOOP_WPTS[0][0], y: LOOP_WPTS[0][1] }
}
const proxTo = (cx, cy, p) => Math.max(0, 1 - Math.hypot(p.x - cx, p.y - cy) / 150)
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

export default function LearnLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(learnUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }

        const workflow = byId('Workflow')
        const intel = byId('Intelligence')
        const feedback = byId('Feedback')
        const decision = byId('Decision')
        const featured = byId('Featured Capability')
        const grid = byId('Grid')
        const gridRect = grid ? grid.querySelector('rect') : null
        const workLabel = byId('Label')
        const intelLabel = byId('Label_2')
        const feedLabel = byId('Label_3')
        const decLabel = byId('Label_4')
        const intelSymbols = ['Symbol', 'Symbol_2', 'Symbol_3', 'Symbol_4', 'Symbol_5', 'Symbol_6']
          .map(byId)
          .filter(Boolean)
          .map((el, i) => {
            const v = parseFloat(el.getAttribute('opacity'))
            return { el, base: Number.isFinite(v) ? v : 1, i }
          })
        const feedOuter = byId('Symbol_7')
        const feedCore = byId('Symbol_8')
        const userIcon = byId('User-Circle-Single--Streamline-Flex')
        const userPaths = userIcon ? Array.from(userIcon.querySelectorAll('path')) : []

        const nodeIds = ['Grid Point', 'Grid Point_2', 'Grid Point_3', 'Grid Point_4']
        const nodes = nodeIds
          .map(byId)
          .filter(Boolean)
          .map((el) => ({ el, strokes: Array.from(el.querySelectorAll('rect[stroke]')) }))

        ;[workflow, intel, feedback, decision].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        ;[grid, feedOuter, feedCore, userIcon].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        intelSymbols.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })
        nodes.forEach(({ el }) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })

        const labelBase = (el) => {
          const v = el ? parseFloat(el.getAttribute('opacity')) : NaN
          return Number.isFinite(v) ? v : 0.56
        }
        const workLabelBase = labelBase(workLabel)
        const intelLabelBase = labelBase(intelLabel)
        const feedLabelBase = labelBase(feedLabel)
        const decLabelBase = labelBase(decLabel)

        if (REDUCED) return

        // tile borders: intelligence is authored green — normalize it to
        // the dark idle so it only lights while green passes over it
        const tileBgs = [
          { el: byId('Tile Background_2'), base: null }, // workflow
          { el: byId('Tile Background_8'), base: null }, // intelligence
          { el: byId('Tile Background_9'), base: null }, // feedback
          { el: byId('Tile Background_15'), base: null }, // decision
        ]
        tileBgs.forEach((o, i) => {
          const v = o.el ? o.el.getAttribute('stroke') : null
          o.base = i === 1 ? '#2D2D2D' : v || '#2D2D2D'
          if (i === 1 && o.el) {
            try {
              o.el.setAttribute('stroke', o.base)
            } catch (e) {}
          }
        })
        const setBorder = (i, p) => {
          const o = tileBgs[i]
          if (!o || !o.el) return
          try {
            o.el.setAttribute('stroke', p > 0.4 ? '#00D46B' : o.base)
          } catch (e) {}
        }

        let last = performance.now()
        const t0 = last

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          void dt
          const t = (now - t0) / 1000

          /* green circuit: intel -> decision -> feedback -> workflow */
          const lp = loopPos((((t / LOOP_PERIOD) % 1) + 1) % 1)
          if (featured) {
            featured.setAttribute('x', (lp.x - 50).toFixed(1))
            featured.setAttribute('y', (lp.y - 50).toFixed(1))
            featured.setAttribute('opacity', (0.8 + Math.sin(t * 1.8 + 0.7) * 0.12).toFixed(3))
          }
          const wProx = proxTo(182, 61, lp)
          const iProx = proxTo(424, 182, lp)
          const fProx = proxTo(61, 303, lp)
          const dProx = proxTo(303, 424, lp)

          if (workflow) workflow.style.transform = 'scale(' + (1 + wProx * 0.012).toFixed(4) + ')'
          if (intel) intel.style.transform = 'scale(' + (1 + iProx * 0.012).toFixed(4) + ')'
          if (feedback) feedback.style.transform = 'scale(' + (1 + fProx * 0.012).toFixed(4) + ')'
          if (decision) decision.style.transform = 'scale(' + (1 + dProx * 0.012).toFixed(4) + ')'
          setBorder(0, wProx)
          setBorder(1, iProx)
          setBorder(2, fProx)
          setBorder(3, dProx)

          const glowLabel = (el, base, k, ph) => {
            if (el) {
              const glow = k * 0.12 + (0.5 + 0.5 * Math.sin(t * 2.2 + ph)) * 0.05
              el.setAttribute('opacity', Math.min(1, base + glow).toFixed(3))
            }
          }
          glowLabel(workLabel, workLabelBase, wProx, 0)
          glowLabel(intelLabel, intelLabelBase, iProx, 1.5)
          glowLabel(feedLabel, feedLabelBase, fProx, 3)
          glowLabel(decLabel, decLabelBase, dProx, 4.5)
          /* ---- workflow grid points fire in sequence ---- */
          const nodePh = (t % NODE_PERIOD) / NODE_PERIOD
          const activeNode = Math.floor(nodePh * Math.max(1, nodes.length)) % Math.max(1, nodes.length)
          nodes.forEach(({ el, strokes }, i) => {
            const on = i === activeNode
            const k = Math.max(wProx, on ? 0.9 : 0.15)
            el.style.transform = 'scale(' + (1 + k * 0.06).toFixed(3) + ')'
            strokes.forEach((s) => {
              try {
                s.setAttribute('stroke', mixWhite(GREEN, k * 0.6))
              } catch (e) {}
            })
          })
          if (grid) {
            grid.style.transform = 'scale(' + (1 + Math.sin(t * 2.3) * 0.02 + wProx * 0.03).toFixed(3) + ')'
          }
          if (gridRect) {
            try {
              gridRect.setAttribute('stroke', mixWhite(GREEN, wProx * 0.6))
            } catch (e) {}
          }

          /* ---- intelligence symbols breathe + rotate ---- */
          intelSymbols.forEach(({ el, base, i }) => {
            const w = 0.5 + 0.5 * Math.sin(t * 2.5 + i * 1.2)
            const spin = i % 2 === 0 ? t * 10 : -t * 8
            el.style.transform =
              'rotate(' + spin.toFixed(1) + 'deg) scale(' + (1 + w * 0.05 + iProx * 0.04).toFixed(3) + ')'
            el.setAttribute('opacity', Math.min(1, base * (0.88 + w * 0.22) + iProx * 0.1).toFixed(3))
            const shape = el.querySelector('rect')
            if (shape) {
              try {
                if (shape.getAttribute('fill') !== null) shape.setAttribute('fill', mixWhite(GREEN, iProx * 0.6))
                else shape.setAttribute('stroke', mixWhite(GREEN, iProx * 0.6))
              } catch (e) {}
            }
          })

          /* ---- feedback loop: outer ring turns, core pulses ---- */
          if (feedOuter) {
            feedOuter.style.transform = 'rotate(' + (-((t * 14) % 360)).toFixed(1) + 'deg)'
          }
          if (feedCore) {
            const w = 0.5 + 0.5 * Math.sin(t * 2.8)
            feedCore.style.transform = 'scale(' + (1 + w * 0.07 + fProx * 0.05).toFixed(3) + ')'
            feedCore.setAttribute('opacity', Math.min(1, 0.67 * (0.85 + w * 0.25) + fProx * 0.12).toFixed(3))
            const coreRect = feedCore.querySelector('rect')
            if (coreRect) {
              try {
                coreRect.setAttribute('fill', mixWhite(GREEN, fProx * 0.6))
              } catch (e) {}
            }
          }

          /* ---- decision user icon floats ---- */
          if (userIcon) {
            userIcon.style.transform =
              'scale(' + (1 + Math.sin(t * 2.0) * 0.015 + dProx * 0.03).toFixed(3) + ') rotate(' + (Math.sin(t * 1.5) * 3).toFixed(2) + 'deg)'
            userIcon.setAttribute('opacity', Math.min(1, 0.43 + (0.5 + 0.5 * Math.sin(t * 2.0)) * 0.08 + dProx * 0.12).toFixed(3))
          }
          if (userPaths.length) {
            const col = mixWhite(GREEN, dProx * 0.6)
            userPaths.forEach((p) => {
              try {
                p.setAttribute('stroke', col)
              } catch (e) {}
            })
          }

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = learnUrl
        img.alt = 'Design systems that learn automatically'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
