import { useEffect, useRef } from 'react'
import performUrl from '../asset/See how it performs in the real world.svg'

/* ------------------------------------------------------------------
   See how it performs in the real world — continuous telemetry loop.
   In place: only transforms / opacity / fill on EXISTING nodes
   (+ one travelling trend dot + dashed flow helpers).

   Loop story (single clock, soft pulses — icons tint, borders stay):
     1. Decision bar chart: each bar grows/shrinks dynamically from
        the baseline on its own live voice (fills stay authored).
     2. Live-status dot heartbeats (white->green); top-right value
        breathes.
     3. Latency pie: green slice share grows/shrinks like live data;
        latency value + delta breathe.
     4. Reliability dot heartbeats green; reliability counter climbs
        0.00% -> 99.98% in a loop (live <text> over hidden outlines).
     5. Throughput trend: brightness wave runs left->right under a
        travelling pulse dot; peak + volume labels breathe.
     6. 28-day grid: a lit wave sweeps day to day (white->green).
     7. Green featured tile roams freely behind the tile grid.
------------------------------------------------------------------- */

const GREEN = [0, 212, 107]
const COUNT_PERIOD = 6 // reliability counter loop: 0.00% -> 99.98%
const mixWhite = (target, k) => {
  const c = Math.max(0, Math.min(1, k))
  const r = Math.round(255 + (target[0] - 255) * c)
  const g = Math.round(255 + (target[1] - 255) * c)
  const b = Math.round(255 + (target[2] - 255) * c)
  return 'rgb(' + r + ',' + g + ',' + b + ')'
}
const REDUCED =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

// throughput polyline (bright-line joints, left -> right)
const TREND = [
  [377.9, 297.3], [390.9, 295.3], [403.9, 291.3], [417.1, 292.8],
  [429.8, 287.3], [443.0, 288.3], [455.7, 283.3], [469.9, 279.2],
]
const TREND_LEN = (() => {
  let L = 0
  for (let i = 1; i < TREND.length; i++) {
    L += Math.hypot(TREND[i][0] - TREND[i - 1][0], TREND[i][1] - TREND[i - 1][1])
  }
  return L
})()
function trendPos(t) {
  let d = t * TREND_LEN
  for (let i = 1; i < TREND.length; i++) {
    const seg = Math.hypot(TREND[i][0] - TREND[i - 1][0], TREND[i][1] - TREND[i - 1][1])
    if (d <= seg) {
      const k = seg === 0 ? 0 : d / seg
      return { x: TREND[i - 1][0] + (TREND[i][0] - TREND[i - 1][0]) * k, y: TREND[i - 1][1] + (TREND[i][1] - TREND[i - 1][1]) * k }
    }
    d -= seg
  }
  return { x: TREND[TREND.length - 1][0], y: TREND[TREND.length - 1][1] }
}

// latency pie geometry (from the authored ring: center + radii)
const PIE_CX = 303
const PIE_CY = 182
const PIE_R = 27
const PIE_r = 21.6
// donut sector for a live share f (0..1), starting at 12 o'clock
function pieSector(f) {
  const frac = Math.max(0.05, Math.min(0.97, f))
  const a0 = -Math.PI / 2
  const a1 = a0 + frac * Math.PI * 2
  const laf = frac > 0.5 ? 1 : 0
  const n = (v) => v.toFixed(2)
  const ox0 = PIE_CX + PIE_R * Math.cos(a0)
  const oy0 = PIE_CY + PIE_R * Math.sin(a0)
  const ox1 = PIE_CX + PIE_R * Math.cos(a1)
  const oy1 = PIE_CY + PIE_R * Math.sin(a1)
  const ix1 = PIE_CX + PIE_r * Math.cos(a1)
  const iy1 = PIE_CY + PIE_r * Math.sin(a1)
  const ix0 = PIE_CX + PIE_r * Math.cos(a0)
  const iy0 = PIE_CY + PIE_r * Math.sin(a0)
  return (
    'M' + n(ox0) + ' ' + n(oy0) +
    ' A' + PIE_R + ' ' + PIE_R + ' 0 ' + laf + ' 1 ' + n(ox1) + ' ' + n(oy1) +
    ' L' + n(ix1) + ' ' + n(iy1) +
    ' A' + PIE_r + ' ' + PIE_r + ' 0 ' + laf + ' 0 ' + n(ix0) + ' ' + n(iy0) + ' Z'
  )
}

export default function PerformLoop() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    fetch(performUrl)
      .then((r) => r.text())
      .then((text) => {
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(text, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.style.overflow = 'visible'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        const byId = (id) => {
          try {
            return svg.querySelector('[id="' + id + '"]')
          } catch (e) {
            return null
          }
        }
        const NS = 'http://www.w3.org/2000/svg'

        const decision = byId('Decision')
        const intel = byId('Intelligence')
        const relTile = byId('Capability Tile_7')
        const thruTile = byId('Capability Tile_10')
        const upTile = byId('Capability Tile_12')
        const featured = byId('Featured Capability')
        const bars = ['Bar', 'Bar_2', 'Bar_3', 'Bar_4'].map(byId).filter(Boolean)
          .map((el, i) => ({
            el,
            // live-chart voice per bar: distinct speed + phase
            sp: [1.1, 1.5, 0.9, 1.3][i % 4],
            ph: [0, 1.7, 3.1, 4.4][i % 4],
          }))
        const liveDot = byId('Live Status_2')
        const liveValue = byId('Value')
        const donut = byId('Ellipse_2')
        const latValue = byId('Average Latency Value')
        const latDelta = byId('Latency Delta')
        const relValue = byId('Value_2')
        const relDot = byId('Ellipse_3')
        const relStatus = byId('Status_2')
        const trendBright = ['Line_8', 'Line_9', 'Line_10', 'Line_11', 'Line_12', 'Line_13', 'Line_14']
          .map(byId).filter(Boolean)
        const peak = byId('Peak')
        const thruValue = byId('Value_3')
        const labels = ['Label', 'Label_2', 'Label_3', 'Label_4', 'Label_5']
          .map(byId).filter(Boolean)
          .map((el) => ({ el, base: parseFloat(el.getAttribute('opacity')) || 0.56 }))
        let days = []
        try {
          days = Array.from(svg.querySelectorAll('[id="28-Day Availability"] rect'))
        } catch (e) {
          days = []
        }

        ;[decision, intel, relTile, thruTile, upTile].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        ;[liveDot, donut, relDot].forEach((el) => {
          if (el) {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          }
        })
        // bars carry a baked rotate(-90) attribute, and a CSS transform
        // would override it (bars would lie flat) — so animate a wrapper
        // <g> per bar instead. The wrapper's fill-box is the upright bar,
        // origin pinned to its bottom so heights grow from the baseline.
        bars.forEach((b) => {
          const wrap = document.createElementNS(NS, 'g')
          if (b.el.parentNode) b.el.parentNode.insertBefore(wrap, b.el)
          wrap.appendChild(b.el)
          wrap.style.transformBox = 'fill-box'
          wrap.style.transformOrigin = 'center bottom'
          b.wrap = wrap
        })
        days.forEach((el) => {
          el.style.transformBox = 'fill-box'
          el.style.transformOrigin = 'center'
        })

        if (REDUCED) return

        const overlay = document.createElementNS(NS, 'g')
        overlay.setAttribute('id', 'perform-loop-overlay')
        svg.appendChild(overlay)
        const dot = document.createElementNS(NS, 'circle')
        dot.setAttribute('r', '3.2')
        dot.setAttribute('fill', '#00D46B')
        dot.setAttribute('opacity', '0.95')
        dot.setAttribute('pointer-events', 'none')
        overlay.appendChild(dot)
        const halo = document.createElementNS(NS, 'circle')
        halo.setAttribute('r', '6.5')
        halo.setAttribute('fill', 'none')
        halo.setAttribute('stroke', '#00D46B')
        halo.setAttribute('stroke-width', '1.2')
        halo.setAttribute('opacity', '0.5')
        halo.setAttribute('pointer-events', 'none')
        overlay.appendChild(halo)

        // live reliability counter: the authored 99.98% is text outlines,
        // so hide it and drive a real <text> node 0.00% -> 99.98% in place
        const relCounter = document.createElementNS(NS, 'text')
        let relCounterOn = false
        if (relValue) {
          try {
            const b = relValue.getBBox()
            relValue.setAttribute('display', 'none')
            relCounter.setAttribute('x', b.x.toFixed(1))
            relCounter.setAttribute('y', (b.y + b.height).toFixed(1))
            relCounter.setAttribute('fill', 'white')
            relCounter.setAttribute('font-family', "'Space Grotesk', Outfit, sans-serif")
            relCounter.setAttribute('font-weight', '500')
            relCounter.setAttribute('font-size', (b.height * 1.4).toFixed(1))
            relCounter.setAttribute('letter-spacing', '-0.02em')
            relCounter.setAttribute('opacity', '0.95')
            relCounter.textContent = '0.00%'
            if (relValue.parentNode) relValue.parentNode.insertBefore(relCounter, relValue.nextSibling)
            relCounterOn = true
          } catch (e) {
            relCounterOn = false
          }
        }

        let last = performance.now()
        const t0 = last

        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - last) / 1000, 0.05)
          last = now
          void dt
          const t = (now - t0) / 1000

          /* ---- decision BAR CHART: each bar grows dynamically from the baseline ---- */
          bars.forEach((b) => {
            // each bar's value oscillates on its own live voice, anchored
            // at the baseline so tops rise/fall like a chart; fills stay authored
            const v = 0.5 + 0.5 * Math.sin(t * b.sp + b.ph)
            if (b.wrap) b.wrap.style.transform = 'scaleY(' + (0.45 + v * 0.55).toFixed(3) + ')'
          })
          if (decision) decision.style.transform = 'scale(' + (1 + Math.sin(t * 2.2) * 0.003).toFixed(4) + ')'

          /* ---- live dot heartbeat ---- */
          const beat = 0.5 + 0.5 * Math.sin((t / 2) * Math.PI * 2)
          if (liveDot) {
            liveDot.style.transform = 'scale(' + (1 + beat * 0.5).toFixed(3) + ')'
            try {
              liveDot.setAttribute('fill', mixWhite(GREEN, beat * 0.9))
              liveDot.setAttribute('fill-opacity', (0.55 + beat * 0.45).toFixed(3))
            } catch (e) {}
          }
          if (liveValue) liveValue.setAttribute('opacity', (0.75 + (0.5 + 0.5 * Math.sin(t * 2.4)) * 0.25).toFixed(3))

          /* ---- latency PIE: slice share grows/shrinks like live data ---- */
          if (donut) {
            donut.style.transform = 'none'
            const share = 0.68 + 0.16 * Math.sin(t * 0.7) + 0.06 * Math.sin(t * 1.7 + 1)
            try {
              donut.setAttribute('d', pieSector(share))
            } catch (e) {}
          }
          if (intel) intel.style.transform = 'scale(' + (1 + Math.sin(t * 2.0) * 0.003).toFixed(4) + ')'
          if (latValue) latValue.setAttribute('opacity', (0.8 + (0.5 + 0.5 * Math.sin(t * 2.6)) * 0.2).toFixed(3))
          if (latDelta) latDelta.setAttribute('opacity', (0.8 + (0.5 + 0.5 * Math.sin(t * 2.6 + 1.2)) * 0.2).toFixed(3))

          /* ---- reliability heartbeat ---- */
          const rbeat = 0.5 + 0.5 * Math.sin((t / 2.4) * Math.PI * 2 + 1)
          if (relDot) {
            relDot.style.transform = 'scale(' + (1 + rbeat * 0.4).toFixed(3) + ')'
            try {
              relDot.setAttribute('fill', mixWhite(GREEN, rbeat * 0.9))
            } catch (e) {}
          }
          if (relCounterOn) {
            // climb 0 -> 99.98 with an ease-out settle, hold, quick dip to hide the wrap
            const cph = (((t / COUNT_PERIOD) % 1) + 1) % 1
            const ck = cph < 0.7 ? 1 - Math.pow(1 - cph / 0.7, 3) : 1
            const cval = (99.98 * ck).toFixed(2) + '%'
            if (relCounter.textContent !== cval) relCounter.textContent = cval
            let fade = 1
            if (cph > 0.93) fade = Math.max(0, 1 - (cph - 0.93) / 0.07)
            else if (cph < 0.05) fade = cph / 0.05
            relCounter.setAttribute('opacity', (fade * (0.8 + (0.5 + 0.5 * Math.sin(t * 2.2 + 0.5)) * 0.2)).toFixed(3))
          }
          if (relStatus) relStatus.setAttribute('opacity', (0.8 + rbeat * 0.2).toFixed(3))
          if (relTile) relTile.style.transform = 'scale(' + (1 + Math.sin(t * 2.1 + 2) * 0.003).toFixed(4) + ')'

          /* ---- throughput trend wave + travelling dot ---- */
          const tph = ((t / 2.8) % 1 + 1) % 1
          trendBright.forEach((el, i) => {
            const c = i / Math.max(1, trendBright.length - 1)
            let d = Math.abs(tph - c)
            d = Math.min(d, 1 - d)
            const glow = Math.max(0, 1 - d * 5)
            el.setAttribute('stroke-opacity', (0.35 + glow * 0.55).toFixed(3))
            try {
              el.setAttribute('stroke', glow > 0.5 ? mixWhite(GREEN, 0.8) : 'white')
            } catch (e) {}
          })
          const p = trendPos(tph)
          dot.setAttribute('cx', p.x.toFixed(1))
          dot.setAttribute('cy', p.y.toFixed(1))
          dot.setAttribute('opacity', (tph > 0.02 && tph < 0.98 ? 0.95 : 0).toFixed(2))
          halo.setAttribute('cx', p.x.toFixed(1))
          halo.setAttribute('cy', p.y.toFixed(1))
          halo.setAttribute('opacity', (0.25 + 0.3 * (0.5 + 0.5 * Math.sin(t * 6))).toFixed(3))
          if (peak) peak.setAttribute('opacity', (0.8 + tph * 0.2).toFixed(3))
          if (thruValue) thruValue.setAttribute('opacity', (0.8 + (0.5 + 0.5 * Math.sin(t * 2.5 + 2)) * 0.2).toFixed(3))
          if (thruTile) thruTile.style.transform = 'scale(' + (1 + Math.sin(t * 2.3 + 1) * 0.003).toFixed(4) + ')'

          /* ---- 28-day wave: lit cell sweeps, trail cools to white ---- */
          if (days.length) {
            const step = Math.floor(t / 0.2) % days.length
            days.forEach((el, i) => {
              let dist = (step - i) % days.length
              if (dist < 0) dist += days.length
              const lit = dist === 0
              const trail = dist > 0 && dist <= 3 ? 1 - dist / 4 : 0
              const k = lit ? 1 : trail * 0.55
              try {
                el.setAttribute('fill', k > 0.05 ? mixWhite(GREEN, Math.min(1, k) * 0.9) : 'white')
                const base = i === days.length - 1 ? 0.9 : 0.2
                el.setAttribute('fill-opacity', Math.min(1, base + k * 0.8).toFixed(3))
              } catch (e) {}
              el.style.transform = 'scale(' + (lit ? 1.25 : 1).toFixed(3) + ')'
            })
          }
          if (upTile) upTile.style.transform = 'scale(' + (1 + Math.sin(t * 2.0 + 3) * 0.003).toFixed(4) + ')'

          if (featured) {
            // green tile roams freely behind the tile grid (tiles stay
            // put — green light drifts through the gaps between them)
            const fx = 140 + 130 * Math.sin(t * 0.35) + 40 * Math.sin(t * 0.83 + 1)
            const fy = 140 + 110 * Math.sin(t * 0.47 + 0.5) + 30 * Math.sin(t * 0.91)
            featured.setAttribute('x', Math.max(0, Math.min(385, fx)).toFixed(1))
            featured.setAttribute('y', Math.max(0, Math.min(385, fy)).toFixed(1))
            featured.setAttribute('opacity', (0.8 + Math.sin(t * 1.8) * 0.12).toFixed(3))
          }
          labels.forEach(({ el, base }, i) => {
            el.setAttribute('opacity', Math.min(1, base + (0.5 + 0.5 * Math.sin(t * 2.2 + i)) * 0.1).toFixed(3))
          })

          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      })
      .catch(() => {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = performUrl
        img.alt = 'See how it performs in the real world'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      })

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
