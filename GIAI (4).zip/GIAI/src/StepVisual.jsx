import { useEffect, useRef } from 'react'
import mapUrl from '../asset/map your data story.svg'

/* ------------------------------------------------------------------
   The ORIGINAL "Map your data story first" artwork, whole and
   untouched (viewBox / layout / positions intact), with an ambient
   loop on its EXISTING nodes only. Cards crossfade in place; the
   green featured tile roams freely behind them.
------------------------------------------------------------------- */

const TAU = Math.PI * 2
let cached = null

export default function StepVisual() {
  const ref = useRef(null)

  useEffect(() => {
    let alive = true
    let raf = 0

    const run = async () => {
      try {
        if (!cached) {
          const r = await fetch(mapUrl)
          cached = await r.text()
        }
        if (!alive || !ref.current) return
        const doc = new DOMParser().parseFromString(cached, 'image/svg+xml')
        const svg = doc.documentElement
        if (!svg || svg.tagName.toLowerCase() !== 'svg') return
        svg.style.height = 'min(300px, 68vw)'
        svg.style.width = 'auto'
        svg.style.maxWidth = '100%'
        svg.style.display = 'block'
        svg.setAttribute('aria-hidden', 'true')
        svg.removeAttribute('width')
        svg.removeAttribute('height')
        ref.current.appendChild(svg)

        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

        const byId = (id) => {
          try { return svg.querySelector('[id="' + id + '"]') } catch (e) { return null }
        }
        const baseOp = (el) => {
          const v = parseFloat(el.getAttribute('opacity'))
          return Number.isFinite(v) ? v : 1
        }
        const featured = byId('Featured Capability')
        if (featured) {
          featured.style.transformBox = 'fill-box'
          featured.style.transformOrigin = 'center'
        }
        const breathers = Array.from(svg.querySelectorAll('g g[opacity]')).map((el, i) => ({ el, base: baseOp(el), i }))
        // No repositioning at all: every card stays exactly where the
        // file authored it. Cards only fade out/in in place on dice
        // loops, so the 1px seams can never break.
        const cardEls = Array.from(svg.querySelectorAll('g[id^="Capability Card"]'))
        const NS2 = 'http://www.w3.org/2000/svg'
        const blanks = document.createElementNS(NS2, 'g')
        cardEls.forEach((el) => {
          let bx = 0
          let by = 0
          let bw = 110
          let bh = 110
          try {
            const b = el.getBBox()
            bx = b.x
            by = b.y
            bw = b.width || 110
            bh = b.height || 110
          } catch (e) {}
          const r = document.createElementNS(NS2, 'rect')
          r.setAttribute('x', bx.toFixed(1))
          r.setAttribute('y', by.toFixed(1))
          r.setAttribute('width', bw.toFixed(1))
          r.setAttribute('height', bh.toFixed(1))
          r.setAttribute('rx', '18')
          r.setAttribute('fill', '#000000')
          r.setAttribute('stroke', '#1a1a1a')
          r.setAttribute('stroke-width', '1')
          blanks.appendChild(r)
        })
        if (cardEls[0] && cardEls[0].parentNode) {
          cardEls[0].parentNode.insertBefore(blanks, cardEls[0])
        }
        const cards = cardEls.map((el) => {
          const show = Math.random() < 0.6
          return { el, show, op: show ? 1 : 0 }
        })
        cards.forEach((c) => { c.el.style.opacity = String(c.op) })
        // per-card mapping extras: home center, text labels, icon groups
        const NS3 = 'http://www.w3.org/2000/svg'
        cards.forEach((c) => {
          try {
            const b = c.el.getBBox()
            c.hx = b.x + b.width / 2
            c.hy = b.y + b.height / 2
          } catch (e) {
            c.hx = 240
            c.hy = 240
          }
          c.labels = Array.from(c.el.querySelectorAll('path[id^="Capability Name"]')).map((el) => {
            const v = parseFloat(el.getAttribute('opacity'))
            return { el, base: Number.isFinite(v) ? v : 1 }
          })
          c.icons = Array.from(c.el.querySelectorAll('g[id*="Icon"]')).filter((el) => !el.getAttribute('transform'))
          c.icons.forEach((el) => {
            el.style.transformBox = 'fill-box'
            el.style.transformOrigin = 'center'
          })
          c.h = 0
        })
        // green featured tile roams slot to slot behind the cards, choosing
        // the random visible cards as its anchors — connecting sources
        const green = byId('Featured Capability')
        const greenMover = document.createElementNS(NS3, 'g')
        if (green && green.parentNode) {
          green.parentNode.insertBefore(greenMover, green)
          greenMover.appendChild(green)
        }
        let greenSlot = -1
        let greenWait = 1.2
        let greenGX = 0
        let greenGY = 0

        const t0 = performance.now()
        let beatT = 1.2
        const frame = (now) => {
          if (!alive) return
          const dt = Math.min((now - (frame.l || now)) / 1000, 0.05)
          frame.l = now
          const t = (now - t0) / 1000
          // paired swap: one visible card trades places with one hidden
          // card — simultaneous crossfade, nothing ever moves
          beatT -= dt
          if (beatT <= 0) {
            beatT = 1.6 + Math.random() * 1.2
            const vis = cards.filter((c) => c.show)
            const hid = cards.filter((c) => !c.show)
            if (vis.length && hid.length) {
              const a = vis[(Math.random() * vis.length) | 0]
              const b = hid[(Math.random() * hid.length) | 0]
              a.show = false
              b.show = true
            }
          }
          cards.forEach((c) => {
            c.op += ((c.show ? 1 : 0) - c.op) * Math.min(1, dt * 6)
            c.el.style.opacity = c.op.toFixed(3)
          })
          // green tile roams freely behind the cards: it eases toward a
          // random visible card, then drifts off on its own between picks
          greenWait -= dt
          if (greenWait <= 0) {
            greenWait = 1.6 + Math.random() * 1.2
            const vis = cards.filter((c) => c.show && c.op > 0.5)
            const next = vis.length ? cards.indexOf(vis[(Math.random() * vis.length) | 0]) : -1
            greenSlot = next === greenSlot ? -1 : next
          }
          let tgx = 130 * Math.sin(t * 0.5) + 45 * Math.sin(t * 1.13 + 1)
          let tgy = 115 * Math.sin(t * 0.42 + 0.6) + 40 * Math.sin(t * 0.97)
          if (greenSlot >= 0 && cards[greenSlot]) {
            const c = cards[greenSlot]
            const dx = c.hx - 243
            const dy = c.hy - 242
            if (Math.abs(dx) <= 400 && Math.abs(dy) <= 400) {
              tgx = dx
              tgy = dy
            }
          }
          greenGX += (tgx - greenGX) * Math.min(1, dt * 2.2)
          greenGY += (tgy - greenGY) * Math.min(1, dt * 2.2)
          if (greenMover) {
            greenMover.setAttribute('transform', `translate(${greenGX.toFixed(1)},${greenGY.toFixed(1)})`)
          }
          cards.forEach((c, i) => {
            const isMap = i === greenSlot && c.show && c.op > 0.5
            c.h += ((isMap ? 1 : 0) - c.h) * Math.min(1, dt * 4)
            const h = c.h
            c.labels.forEach(({ el, base }) => {
              el.style.opacity = (base * (1 + 0.3 * h)).toFixed(3)
            })
            c.icons.forEach((el) => {
              el.style.transform = `scale(${(1 + 0.06 * h).toFixed(3)})`
            })
          })
          if (featured) {
            featured.style.opacity = (0.78 + 0.22 * (0.5 + 0.5 * Math.sin((t / 3.2) * TAU + 1))).toFixed(3)
          }
          breathers.forEach(({ el, base, i }) => {
            el.style.opacity = (base * (0.94 + 0.06 * Math.sin((t / 2.8) * TAU + i * 0.9))).toFixed(3)
          })
          raf = requestAnimationFrame(frame)
        }
        raf = requestAnimationFrame(frame)
      } catch (e) {
        if (!alive || !ref.current) return
        const img = document.createElement('img')
        img.src = mapUrl
        img.alt = 'Map your data story first'
        img.style.maxHeight = '300px'
        img.style.maxWidth = '100%'
        ref.current.appendChild(img)
      }
    }
    run()

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      if (ref.current) ref.current.innerHTML = ''
    }
  }, [])

  return <div ref={ref} className="flex items-center justify-center" aria-hidden />
}
