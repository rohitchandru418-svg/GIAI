/* Ported from the tech team's typography.tsx.
   Their `!text-s / !text-m / !text-xl` are Tailwind v4 theme sizes; this
   project runs Tailwind v3, so variants resolve to the identical rem
   formulas via the --tt-* tokens in tokens.css (no new dependencies).
   API matches the original: as / variant / className + rest props. */

const VARIANTS = {
  base: 'text-[var(--tt-s)]',
  s3: 'font-grotesk text-[var(--tt-m)] leading-[120%] tracking-[-0.02em]',
  s5: 'font-grotesk text-[var(--tt-s)] leading-[120%] tracking-[-0.02em]',
  b1: 'font-grotesk text-[var(--tt-m)] leading-[120%] tracking-[-0.02em] font-medium',
  s2: 'font-grotesk text-[var(--tt-xl)] leading-[120%] tracking-[-0.02em] font-medium',
}

function cn(...parts) {
  return parts.filter(Boolean).join(' ')
}

export default function Typography({ className, variant = 'base', as: Comp = 'p', ...props }) {
  return <Comp className={cn(VARIANTS[variant] || VARIANTS.base, className)} {...props} />
}

export { VARIANTS as typographyVariants }
