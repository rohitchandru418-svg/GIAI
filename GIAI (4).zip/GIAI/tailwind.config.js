/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        minsky: '#00D46B',
        ink: '#0a0a0a',
        panel: '#111111',
        line: '#1A1A1A',
        muted: '#777777'
      },
      fontFamily: {
        grotesk: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        outfit: ['Outfit', '"Space Grotesk"', 'sans-serif']
      }
    }
  },
  plugins: []
}
